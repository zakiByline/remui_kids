<?php
/**
 * Emulators & Plugins Page for Teacher Dashboard
 * 
 * This page showcases available emulators and educational plugins
 * available in the system.
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// Security checks
require_login();
$context = context_system::instance();

// Restrict to teachers/admins
if (!has_capability('moodle/course:update', $context) && !has_capability('moodle/site:config', $context)) {
    throw new moodle_exception('nopermissions', 'error', '', 'access emulators page');
}

// Page setup
$PAGE->set_context($context);
$PAGE->set_url('/theme/remui_kids/teacher/emulators.php');
$PAGE->set_title('Emulators & Educational Tools');
$PAGE->set_heading('Available Emulators & Tools');

echo $OUTPUT->header();
?>

<style>
/* Hide Moodle's default main content area */
#region-main,
[role="main"] {
    background: transparent !important;
    box-shadow: none !important;
    border: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
}

/* Teacher Dashboard Styles */
.teacher-css-wrapper {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
    min-height: 100vh;
}

.teacher-dashboard-wrapper {
    display: flex;
    min-height: 100vh;
}

.teacher-sidebar {
    width: 280px;
    background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
    color: white;
    padding: 0;
    overflow-y: auto;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    position: fixed;
    height: 100vh;
    z-index: 1000;
}

.teacher-sidebar.collapsed {
    width: 60px;
}

.sidebar-header {
    padding: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    text-align: center;
}

.sidebar-logo {
    font-size: 24px;
    font-weight: bold;
    color: #ecf0f1;
    margin-bottom: 10px;
}

.sidebar-toggle {
    display: none;
    background: #3498db;
    color: white;
    border: none;
    padding: 10px;
    border-radius: 5px;
    cursor: pointer;
    margin-bottom: 20px;
}

.sidebar-section {
    margin-bottom: 30px;
}

.sidebar-category {
    color: #bdc3c7;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 0 20px 10px;
    margin: 0;
}

.sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar-item {
    margin: 0;
}

.sidebar-link {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    color: #ecf0f1;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-link:hover {
    background-color: rgba(255,255,255,0.1);
    border-left-color: #3498db;
    color: white;
}

.sidebar-item.active .sidebar-link {
    background-color: rgba(52, 152, 219, 0.2);
    border-left-color: #3498db;
    color: #3498db;
}

.sidebar-icon {
    width: 20px;
    margin-right: 12px;
    text-align: center;
    font-size: 16px;
}

.sidebar-text {
    font-size: 14px;
    font-weight: 500;
}

.teacher-main-content {
    flex: 1;
    margin-left: 280px;
    padding: 30px;
    transition: margin-left 0.3s ease;
}

.teacher-sidebar.collapsed + .teacher-main-content {
    margin-left: 60px;
}

/* Emulators Page Specific Styles */
.emulators-header {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.emulators-title {
    font-size: 28px;
    font-weight: 700;
    color: #2c3e50;
    margin: 0 0 10px 0;
}

.emulators-subtitle {
    color: #7f8c8d;
    font-size: 16px;
    margin: 0;
}

.emulators-grid {
    display: flex;
    gap: 30px;
    margin-bottom: 40px;
    flex-wrap: wrap;
}

.emulator-block {
    width: 150px;
    height: 150px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
    text-decoration: none;
    transition: all 0.3s ease;
    cursor: pointer;
    border: 2px solid transparent;
    position: relative;
}

.emulator-block:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.15);
    border-color: #667eea;
    text-decoration: none;
}

.emulator-block i {
    font-size: 50px;
    color: #667eea;
    transition: all 0.3s ease;
}

.emulator-block:hover i {
    transform: scale(1.1);
    color: #764ba2;
}

.emulator-label {
    font-size: 14px;
    font-weight: 600;
    color: #2c3e50;
    text-align: center;
}

.emulator-block:hover .emulator-label {
    color: #667eea;
}

.emulator-block.available {
    cursor: default;
}

.emulator-block.available:hover {
    transform: none;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    border-color: transparent;
}

.emulator-block.available:hover i {
    transform: none;
}

.emulator-block.available:hover .emulator-label {
    color: #2c3e50;
}

.emulator-block.active {
    cursor: pointer;
}

.emulator-block.selected {
    border-color: #667eea;
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.05), rgba(118, 75, 162, 0.05));
}

/* Emulator Viewer */
.emulator-viewer {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    margin-bottom: 30px;
    overflow: hidden;
}

.viewer-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 20px 30px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    color: white;
}

.viewer-title {
    font-size: 20px;
    font-weight: 600;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.btn-close-viewer {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-close-viewer:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
}

.viewer-iframe-container {
    height: calc(100vh - 200px);
    min-height: 800px;
    position: relative;
    background: #f8f9fa;
}

.emulator-iframe {
    width: 100%;
    height: 100%;
    border: none;
}

.loading-spinner {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
}

.spinner {
    width: 50px;
    height: 50px;
    border: 4px solid #e5e7eb;
    border-top-color: #667eea;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.loading-text {
    color: #6b7280;
    font-size: 0.9rem;
}

.info-section {
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-top: 30px;
}

.info-section h3 {
    color: #2c3e50;
    font-size: 22px;
    font-weight: 700;
    margin: 0 0 20px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-section h3 i {
    color: #667eea;
}

.info-section p {
    color: #5d6d7e;
    font-size: 15px;
    line-height: 1.7;
    margin: 0 0 15px 0;
}

.info-section ul {
    color: #5d6d7e;
    font-size: 15px;
    line-height: 1.7;
    margin: 0 0 15px 0;
    padding-left: 20px;
}

.info-section ul li {
    margin-bottom: 10px;
}

@media (max-width: 768px) {
    .teacher-sidebar {
        transform: translateX(-100%);
    }
    
    .teacher-sidebar.open {
        transform: translateX(0);
    }
    
    .teacher-main-content {
        margin-left: 0;
        padding: 20px;
    }
    
    .sidebar-toggle {
        display: block;
    }
    
    .emulators-grid {
        justify-content: center;
    }
    
    .emulator-block {
        width: 130px;
        height: 130px;
    }
    
    .emulator-block i {
        font-size: 40px;
    }
    
    .emulator-label {
        font-size: 12px;
    }
    
    .viewer-iframe-container {
        height: calc(100vh - 250px);
        min-height: 600px;
    }
    
    .viewer-header {
        padding: 15px 20px;
    }
    
    .viewer-title {
        font-size: 16px;
    }
    
    .btn-close-viewer {
        padding: 8px 16px;
        font-size: 12px;
    }
}
</style>

<div class="teacher-css-wrapper">
    <div class="teacher-dashboard-wrapper">
        <!-- Sidebar Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleTeacherSidebar()">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Teacher Sidebar -->
        <div class="teacher-sidebar" id="teacherSidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo"></div>
            </div>

            <div class="sidebar-section">
                <h3 class="sidebar-category">DASHBOARD</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/my/" class="sidebar-link"><i class="fa fa-th-large sidebar-icon"></i><span class="sidebar-text">Teacher Dashboard</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/teacher_courses.php" class="sidebar-link"><i class="fa fa-book sidebar-icon"></i><span class="sidebar-text">My Courses</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/view_course.php" class="sidebar-link"><i class="fa fa-folder-open sidebar-icon"></i><span class="sidebar-text">Teacher Resources</span></a></li>
                </ul>
            </div>

            <!-- Students Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">STUDENTS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/students.php" class="sidebar-link"><i class="fa fa-users sidebar-icon"></i><span class="sidebar-text">All Students</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/enroll_students.php" class="sidebar-link"><i class="fa fa-user-plus sidebar-icon"></i><span class="sidebar-text">Enroll Students</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Reports</span></a></li>
                </ul>
            </div>

            <!-- Assessments Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">ASSESSMENTS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/assignments.php" class="sidebar-link"><i class="fa fa-tasks sidebar-icon"></i><span class="sidebar-text">Assignments</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/quizzes.php" class="sidebar-link"><i class="fa fa-question-circle sidebar-icon"></i><span class="sidebar-text">Quizzes</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/competencies.php" class="sidebar-link"><i class="fa fa-sitemap sidebar-icon"></i><span class="sidebar-text">Competencies</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/rubrics.php" class="sidebar-link"><i class="fa fa-list-alt sidebar-icon"></i><span class="sidebar-text">Rubrics</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/gradebook.php" class="sidebar-link"><i class="fa fa-star sidebar-icon"></i><span class="sidebar-text">Gradebook</span></a></li>
                </ul>
            </div>

            <!-- Questions Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">QUESTIONS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/pages/questions_unified.php" class="sidebar-link"><i class="fa fa-question-circle sidebar-icon"></i><span class="sidebar-text">Questions Management</span></a></li>
                </ul>
            </div>

            <!-- Emulators Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">TOOLS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item active"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/emulators.php" class="sidebar-link"><i class="fa fa-laptop-code sidebar-icon"></i><span class="sidebar-text">Emulators</span></a></li>
                </ul>
            </div>

            <!-- Reports Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">REPORTS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/log/index.php" class="sidebar-link"><i class="fa fa-chart-bar sidebar-icon"></i><span class="sidebar-text">Activity Logs</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/outline/index.php" class="sidebar-link"><i class="fa fa-file-alt sidebar-icon"></i><span class="sidebar-text">Course Reports</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Tracking</span></a></li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="teacher-main-content">


            <!-- Emulators Grid -->
            <div class="emulators-grid">
                <!-- Code Editor Block -->
                <div class="emulator-block active" onclick="loadEmulator('<?php echo $CFG->wwwroot; ?>/theme/remui_kids/code_editor.php', 'Code Editor')" title="Click to open Code Editor">
                    <i class="fa fa-code"></i>
                    <span class="emulator-label">Code Editor</span>
                </div>

                <!-- Scratch Emulator Block -->
                <div class="emulator-block active" onclick="loadEmulator('<?php echo $CFG->wwwroot; ?>/theme/remui_kids/scratch_simple.php', 'Scratch Emulator')" title="Click to open Scratch">
                    <i class="fa fa-puzzle-piece"></i>
                    <span class="emulator-label">Scratch Emulator</span>
                </div>

                <!--Remix IDE Block -->
                <div class="emulator-block active" onclick="loadEmulator('<?php echo $CFG->wwwroot; ?>/theme/remui_kids/remix.php', 'Remix IDE')" title="Click to open Remix IDE">
                    <i class="fa fa-microchip"></i>
                    <span class="emulator-label">Remix IDE</span>
                </div>

                <!-- Photopea Block -->
                <div class="emulator-block available" title="Available as Activity">
                    <i class="fa fa-image"></i>
                    <span class="emulator-label">Photopea</span>
                </div>

                <!-- SQL Block -->
                <div class="emulator-block available" title="Available as Activity">
                    <i class="fa fa-database"></i>
                    <span class="emulator-label">SQL</span>
                </div>

                <!-- WebDev Block -->
                <div class="emulator-block available" title="Available as Activity">
                    <i class="fa fa-globe"></i>
                    <span class="emulator-label">WebDev</span>
                </div>

                <!-- Wick Block -->
                <div class="emulator-block available" title="Available as Activity">
                    <i class="fa fa-film"></i>
                    <span class="emulator-label">Wick</span>
                </div>

                <!-- Wokwi Block -->
                <div class="emulator-block available" title="Available as Activity">
                    <i class="fa fa-sitemap"></i>
                    <span class="emulator-label">Wokwi</span>
                </div>
            </div>

            <!-- Emulator Viewer (Hidden by default) -->
            <div id="emulatorViewer" class="emulator-viewer" style="display: none;">
                <div class="viewer-header">
                    <h3 id="emulatorTitle" class="viewer-title">
                        <i class="fa fa-laptop-code"></i>
                        <span></span>
                    </h3>
                    <button class="btn-close-viewer" onclick="closeEmulator()">
                        <i class="fa fa-times"></i> Close
                    </button>
                </div>
                <div class="viewer-iframe-container">
                    <div class="loading-spinner" id="emulatorLoading">
                        <div class="spinner"></div>
                        <div class="loading-text">Loading emulator...</div>
                    </div>
                    <iframe id="emulatorFrame" class="emulator-iframe" style="display: none;"></iframe>
                </div>
            </div>

            <!-- How to Use Section -->
            <div class="info-section" id="infoSection">
                <h3><i class="fa fa-question-circle"></i> How to Use These Tools</h3>
                <p>These emulators are seamlessly integrated into your teaching workflow:</p>
                <ul>
                    <li><strong>Assign Activities:</strong> Create assignments using these emulators and track student submissions</li>
                    <li><strong>Live Demonstrations:</strong> Use during class to demonstrate coding concepts in real-time</li>
                    <li><strong>Student Practice:</strong> Students can access these tools from their course pages to practice</li>
                    <li><strong>Progress Tracking:</strong> Monitor student work and provide feedback directly in the platform</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
function toggleTeacherSidebar() {
    const sidebar = document.getElementById('teacherSidebar');
    sidebar.classList.toggle('collapsed');
}

// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('teacherSidebar');
    
    if (window.innerWidth <= 768) {
        sidebar.classList.add('collapsed');
    }
    
    window.addEventListener('resize', function() {
        if (window.innerWidth <= 768) {
            sidebar.classList.add('collapsed');
        } else {
            sidebar.classList.remove('collapsed');
        }
    });
});

// Emulator Loading Functions
function loadEmulator(url, title) {
    const viewer = document.getElementById('emulatorViewer');
    const iframe = document.getElementById('emulatorFrame');
    const loading = document.getElementById('emulatorLoading');
    const titleElement = document.getElementById('emulatorTitle').querySelector('span');
    const infoSection = document.getElementById('infoSection');
    
    // Update title
    titleElement.textContent = title;
    
    // Show viewer, hide info section
    viewer.style.display = 'block';
    infoSection.style.display = 'none';
    
    // Show loading spinner
    loading.style.display = 'flex';
    iframe.style.display = 'none';
    
    // Load iframe
    iframe.src = url;
    
    // Remove previous selection
    document.querySelectorAll('.emulator-block.selected').forEach(block => {
        block.classList.remove('selected');
    });
    
    // Mark current block as selected
    event.currentTarget.classList.add('selected');
    
    // Hide loading when iframe loads
    iframe.onload = function() {
        loading.style.display = 'none';
        iframe.style.display = 'block';
    };
    
    // Fallback to show iframe after 3 seconds even if onload doesn't fire
    setTimeout(function() {
        loading.style.display = 'none';
        iframe.style.display = 'block';
    }, 3000);
    
    // Smooth scroll to viewer
    viewer.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function closeEmulator() {
    const viewer = document.getElementById('emulatorViewer');
    const iframe = document.getElementById('emulatorFrame');
    const infoSection = document.getElementById('infoSection');
    
    // Hide viewer, show info section
    viewer.style.display = 'none';
    infoSection.style.display = 'block';
    
    // Clear iframe source to stop any running content
    iframe.src = '';
    
    // Remove selection from blocks
    document.querySelectorAll('.emulator-block.selected').forEach(block => {
        block.classList.remove('selected');
    });
    
    // Scroll to top of emulators grid
    document.querySelector('.emulators-grid').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
</script>

<?php
echo $OUTPUT->footer();
?>

