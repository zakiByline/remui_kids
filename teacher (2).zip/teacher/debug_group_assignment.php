<?php
/**
 * Debug Group Assignment Access
 * Check if a student is in a group and if they should see an assignment
 */

require_once(__DIR__ . '/../../../config.php');
require_login();

// Set page context
$PAGE->set_context(context_system::instance());
$PAGE->set_url('/theme/remui_kids/teacher/debug_group_assignment.php');
$PAGE->set_title('Debug Group Assignment');

echo $OUTPUT->header();

// Get parameters (you can hardcode these for testing)
$userid = optional_param('userid', $USER->id, PARAM_INT); // Default to current user
$courseid = optional_param('courseid', 0, PARAM_INT);
$cmid = optional_param('cmid', 0, PARAM_INT); // Course module ID

?>
<style>
    .debug-container {
        max-width: 1200px;
        margin: 20px auto;
        padding: 20px;
    }
    .debug-section {
        background: white;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
    }
    .debug-section h3 {
        color: #495057;
        margin-top: 0;
        border-bottom: 2px solid #007bff;
        padding-bottom: 10px;
    }
    .debug-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }
    .debug-table th,
    .debug-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #dee2e6;
    }
    .debug-table th {
        background: #f8f9fa;
        font-weight: 600;
    }
    .status-yes {
        color: #28a745;
        font-weight: 600;
    }
    .status-no {
        color: #dc3545;
        font-weight: 600;
    }
    .code-block {
        background: #f4f4f4;
        padding: 10px;
        border-radius: 4px;
        font-family: monospace;
        overflow-x: auto;
        margin: 10px 0;
    }
    .form-section {
        background: #e9ecef;
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 20px;
    }
    .form-section label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
    }
    .form-section input,
    .form-section select {
        padding: 8px;
        border: 1px solid #ced4da;
        border-radius: 4px;
        margin-right: 10px;
    }
    .btn-check {
        background: #007bff;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: 500;
    }
    .btn-check:hover {
        background: #0056b3;
    }
</style>

<div class="debug-container">
    <h2>🔍 Debug Group Assignment Access</h2>
    
    <div class="form-section">
        <form method="get" action="">
            <label>User ID (Student):</label>
            <input type="number" name="userid" value="<?php echo $userid; ?>" required>
            
            <label>Course ID:</label>
            <input type="number" name="courseid" value="<?php echo $courseid; ?>" required>
            
            <label>Course Module ID (Assignment):</label>
            <input type="number" name="cmid" value="<?php echo $cmid; ?>" required>
            
            <button type="submit" class="btn-check">Check Access</button>
        </form>
    </div>

    <?php if ($userid && $courseid && $cmid): ?>
        
        <?php
        // Get user info
        $user = $DB->get_record('user', ['id' => $userid], 'id, username, firstname, lastname, email');
        
        // Get course info
        $course = $DB->get_record('course', ['id' => $courseid], 'id, fullname, shortname');
        
        // Get course module and assignment info
        $cm = $DB->get_record('course_modules', ['id' => $cmid], '*');
        $assignment = null;
        $assignname = 'Unknown';
        
        if ($cm) {
            $assignment = $DB->get_record('assign', ['id' => $cm->instance], 'id, name, course');
            $assignname = $assignment ? $assignment->name : 'Unknown';
        }
        ?>
        
        <!-- User Info -->
        <div class="debug-section">
            <h3>👤 User Information</h3>
            <table class="debug-table">
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Email</th>
                </tr>
                <tr>
                    <td><?php echo $user->id; ?></td>
                    <td><?php echo $user->username; ?></td>
                    <td><?php echo fullname($user); ?></td>
                    <td><?php echo $user->email; ?></td>
                </tr>
            </table>
        </div>
        
        <!-- Course Info -->
        <div class="debug-section">
            <h3>📚 Course Information</h3>
            <table class="debug-table">
                <tr>
                    <th>ID</th>
                    <th>Short Name</th>
                    <th>Full Name</th>
                </tr>
                <tr>
                    <td><?php echo $course->id; ?></td>
                    <td><?php echo $course->shortname; ?></td>
                    <td><?php echo $course->fullname; ?></td>
                </tr>
            </table>
        </div>
        
        <!-- Assignment Info -->
        <div class="debug-section">
            <h3>📝 Assignment Information</h3>
            <table class="debug-table">
                <tr>
                    <th>Course Module ID</th>
                    <th>Assignment ID</th>
                    <th>Assignment Name</th>
                    <th>Visible</th>
                    <th>Availability</th>
                </tr>
                <tr>
                    <td><?php echo $cmid; ?></td>
                    <td><?php echo $cm ? $cm->instance : 'N/A'; ?></td>
                    <td><?php echo $assignname; ?></td>
                    <td><?php echo $cm && $cm->visible ? '<span class="status-yes">✓ Yes</span>' : '<span class="status-no">✗ No</span>'; ?></td>
                    <td><?php echo $cm && $cm->availability ? 'Restricted' : 'Open to all'; ?></td>
                </tr>
            </table>
            
            <?php if ($cm && $cm->availability): ?>
                <h4>Availability JSON:</h4>
                <div class="code-block">
                    <?php echo htmlspecialchars($cm->availability); ?>
                </div>
                <h4>Parsed Availability:</h4>
                <div class="code-block">
                    <pre><?php print_r(json_decode($cm->availability, true)); ?></pre>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Check Group Membership -->
        <div class="debug-section">
            <h3>👥 Group Membership Check</h3>
            <?php
            // Get all groups in this course
            $sql = "SELECT g.id, g.name, g.description,
                           CASE WHEN gm.userid IS NOT NULL THEN 1 ELSE 0 END as is_member,
                           gm.timeadded
                    FROM {groups} g
                    LEFT JOIN {groups_members} gm ON g.id = gm.groupid AND gm.userid = :userid
                    WHERE g.courseid = :courseid
                    ORDER BY g.name";
            
            $groups = $DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]);
            ?>
            
            <?php if ($groups): ?>
                <table class="debug-table">
                    <tr>
                        <th>Group ID</th>
                        <th>Group Name</th>
                        <th>Is Member?</th>
                        <th>Date Added</th>
                    </tr>
                    <?php foreach ($groups as $group): ?>
                        <tr>
                            <td><?php echo $group->id; ?></td>
                            <td><?php echo $group->name; ?></td>
                            <td>
                                <?php if ($group->is_member): ?>
                                    <span class="status-yes">✓ YES</span>
                                <?php else: ?>
                                    <span class="status-no">✗ NO</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $group->timeadded ? userdate($group->timeadded) : 'N/A'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <p class="status-no">No groups found in this course.</p>
            <?php endif; ?>
        </div>
        
        <!-- Check Required Groups -->
        <?php if ($cm && $cm->availability): ?>
            <div class="debug-section">
                <h3>🔒 Required Groups for This Assignment</h3>
                <?php
                $availability_data = json_decode($cm->availability, true);
                $required_groups = [];
                
                if (isset($availability_data['c'])) {
                    foreach ($availability_data['c'] as $condition) {
                        if ($condition['type'] === 'group') {
                            $required_groups[] = $condition['id'];
                        }
                    }
                }
                
                if (!empty($required_groups)):
                    $placeholders = implode(',', array_fill(0, count($required_groups), '?'));
                    $sql = "SELECT g.id, g.name,
                                   CASE WHEN gm.userid IS NOT NULL THEN 1 ELSE 0 END as user_is_member
                            FROM {groups} g
                            LEFT JOIN {groups_members} gm ON g.id = gm.groupid AND gm.userid = ?
                            WHERE g.id IN ($placeholders)";
                    
                    $params = array_merge([$userid], $required_groups);
                    $required_group_data = $DB->get_records_sql($sql, $params);
                    ?>
                    
                    <table class="debug-table">
                        <tr>
                            <th>Group ID</th>
                            <th>Group Name</th>
                            <th>User is Member?</th>
                        </tr>
                        <?php foreach ($required_group_data as $rg): ?>
                            <tr>
                                <td><?php echo $rg->id; ?></td>
                                <td><?php echo $rg->name; ?></td>
                                <td>
                                    <?php if ($rg->user_is_member): ?>
                                        <span class="status-yes">✓ YES - User CAN see assignment</span>
                                    <?php else: ?>
                                        <span class="status-no">✗ NO - User CANNOT see assignment</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                    
                    <?php
                    // Check if user is in ANY of the required groups
                    $user_has_access = false;
                    foreach ($required_group_data as $rg) {
                        if ($rg->user_is_member) {
                            $user_has_access = true;
                            break;
                        }
                    }
                    ?>
                    
                    <h4>Final Result:</h4>
                    <?php if ($user_has_access): ?>
                        <p class="status-yes" style="font-size: 18px;">✓ User SHOULD be able to see this assignment!</p>
                    <?php else: ?>
                        <p class="status-no" style="font-size: 18px;">✗ User CANNOT see this assignment (not in any required group)</p>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <p>No group restrictions found. Assignment should be visible to all.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <!-- SQL Queries for Manual Checking -->
        <div class="debug-section">
            <h3>🔧 SQL Queries for Manual Debugging</h3>
            
            <h4>Check if user is in a specific group:</h4>
            <div class="code-block">
SELECT u.id, u.username, u.firstname, u.lastname, g.name as groupname, gm.timeadded
FROM mdl_groups_members gm
JOIN mdl_users u ON u.id = gm.userid
JOIN mdl_groups g ON g.id = gm.groupid
WHERE gm.userid = <?php echo $userid; ?>
  AND g.courseid = <?php echo $courseid; ?>;
            </div>
            
            <h4>Check assignment availability restrictions:</h4>
            <div class="code-block">
SELECT cm.id, cm.instance, cm.visible, cm.availability, a.name
FROM mdl_course_modules cm
JOIN mdl_assign a ON a.id = cm.instance
WHERE cm.id = <?php echo $cmid; ?>;
            </div>
            
            <h4>Check all members of all groups in course:</h4>
            <div class="code-block">
SELECT g.id as group_id, g.name as group_name, 
       u.id as user_id, u.username, u.firstname, u.lastname
FROM mdl_groups g
LEFT JOIN mdl_groups_members gm ON g.id = gm.groupid
LEFT JOIN mdl_user u ON u.id = gm.userid
WHERE g.courseid = <?php echo $courseid; ?>
ORDER BY g.name, u.lastname;
            </div>
        </div>
        
    <?php else: ?>
        <div class="debug-section">
            <p>Please enter User ID, Course ID, and Course Module ID above to debug.</p>
        </div>
    <?php endif; ?>
</div>

<?php
echo $OUTPUT->footer();
?>




