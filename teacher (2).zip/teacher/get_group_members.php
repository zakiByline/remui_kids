<?php
/**
 * API endpoint to get group members for assignments
 */

define('AJAX_SCRIPT', true);

require_once(__DIR__ . '/../../../config.php');

// Set JSON header
header('Content-Type: application/json');

// Security checks
require_login();
$context = context_system::instance();

// Restrict to teachers/admins
if (!has_capability('moodle/course:update', $context) && !is_siteadmin()) {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

try {
    // Get group IDs from URL parameter
    $groupids_json = required_param('groupids', PARAM_RAW);
    $groupids = json_decode($groupids_json, true);
    
    if (!is_array($groupids) || empty($groupids)) {
        throw new Exception('Invalid group IDs');
    }
    
    $groups_data = [];
    
    foreach ($groupids as $groupid) {
        // Get group details
        $group = $DB->get_record('groups', ['id' => $groupid]);
        
        if (!$group) {
            continue; // Skip if group doesn't exist
        }
        
        // Get group members
        $members_sql = "
            SELECT u.id, u.firstname, u.lastname, u.email,
                   CONCAT(u.firstname, ' ', u.lastname) as fullname
            FROM {user} u
            JOIN {groups_members} gm ON gm.userid = u.id
            WHERE gm.groupid = ?
            AND u.deleted = 0
            ORDER BY u.lastname ASC, u.firstname ASC
        ";
        
        $members = $DB->get_records_sql($members_sql, [$groupid]);
        
        // Convert to array
        $members_array = [];
        foreach ($members as $member) {
            $members_array[] = [
                'id' => $member->id,
                'fullname' => $member->fullname,
                'firstname' => $member->firstname,
                'lastname' => $member->lastname,
                'email' => $member->email
            ];
        }
        
        $groups_data[] = [
            'id' => $group->id,
            'name' => format_string($group->name),
            'description' => format_string($group->description),
            'members' => $members_array
        ];
    }
    
    echo json_encode([
        'success' => true,
        'groups' => $groups_data
    ]);
    
} catch (Exception $e) {
    error_log('Error in get_group_members.php: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error loading group members: ' . $e->getMessage()
    ]);
}
