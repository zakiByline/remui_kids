<?php
/**
 * Teacher Resources Page
 * Displays all teacher resources (activities and materials hidden from students)
 * Includes course selector dropdown to switch between courses
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->dirroot . '/course/lib.php');

// Security checks
require_login();
$context = context_system::instance();

// Get all courses where user is a teacher
$userid = $USER->id;
$sql = "SELECT DISTINCT c.id, c.fullname, c.shortname
        FROM {course} c
        JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = 50
        JOIN {role_assignments} ra ON ra.contextid = ctx.id
        JOIN {role} r ON r.id = ra.roleid
        WHERE ra.userid = :userid 
        AND r.archetype = 'editingteacher'
        AND c.id != 1
        ORDER BY c.fullname ASC";
$teacher_courses = $DB->get_records_sql($sql, ['userid' => $userid]);

// If no courses found, show error
if (empty($teacher_courses)) {
    print_error('You are not assigned as a teacher in any courses.');
}

// Get course ID (optional - default to first course if not provided)
$courseid = optional_param('id', 0, PARAM_INT);

// If no course selected, default to first available course
if ($courseid == 0) {
    $first_course = reset($teacher_courses);
    $courseid = $first_course->id;
}

// Get course
$course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
$coursecontext = context_course::instance($courseid);

// Verify user is a teacher in this course
require_capability('moodle/course:update', $coursecontext);

// Page setup
$PAGE->set_context($coursecontext);
$PAGE->set_url('/theme/remui_kids/teacher/view_course.php', ['id' => $courseid]);
$PAGE->set_pagelayout('base'); // Use base layout to minimize Moodle UI
$PAGE->set_title(format_string($course->fullname));
$PAGE->set_heading(''); // Remove default heading

// Get course sections
$sections = $DB->get_records('course_sections', ['course' => $courseid], 'section ASC');

// Get modinfo for the course
$modinfo = get_fast_modinfo($courseid);

// Get ALL activities/resources that are hidden from students
$teacher_resources = []; // Activities hidden from students

foreach ($sections as $section) {
    // Skip section 0 (general section)
    if ($section->section == 0) {
        continue;
    }
    
    // Skip sections that ARE subsections themselves (component = 'mod_subsection')
    if ($section->component === 'mod_subsection') {
        continue;
    }
    
    // Check if section is hidden from students
    $section_hidden = ($section->visible == 0);
    
    // If section is hidden OR named "Teacher Resources", check its activities
    if ($section_hidden || 
        stripos($section->name, 'teacher resource') !== false || 
        stripos($section->name, 'teacher material') !== false ||
        stripos($section->name, 'instructor resource') !== false) {
        
        // Get all activities in this section
        if (!empty($section->sequence)) {
            $module_ids = explode(',', $section->sequence);
            foreach ($module_ids as $module_id) {
                try {
                    $cm = $modinfo->get_cm($module_id);
                    if (!$cm) continue;
                    
                    // If it's a subsection, look inside it for activities
                    if ($cm->modname === 'subsection') {
                        // Get the subsection's actual section
                        $subsection = $DB->get_record('course_sections', [
                            'component' => 'mod_subsection',
                            'itemid' => $cm->instance
                        ]);
                        
                        if ($subsection && !empty($subsection->sequence)) {
                            $sub_module_ids = explode(',', $subsection->sequence);
                            foreach ($sub_module_ids as $sub_module_id) {
                                try {
                                    $sub_cm = $modinfo->get_cm($sub_module_id);
                                    if ($sub_cm && $sub_cm->modname !== 'subsection') {
                                        // Add activities from inside subsection
                                        $teacher_resources[] = [
                                            'cm' => $sub_cm,
                                            'section_name' => $section->name . ' > ' . $subsection->name
                                        ];
                                    }
                                } catch (Exception $e) {
                                    continue;
                                }
                            }
                        }
                    } else {
                        // Regular activity (not a subsection)
                        $teacher_resources[] = [
                            'cm' => $cm,
                            'section_name' => $section->name
                        ];
                    }
                } catch (Exception $e) {
                    // Skip invalid modules
                    continue;
                }
            }
        }
    }
    
    // Also check for individual hidden activities in visible sections
    if (!$section_hidden && !empty($section->sequence)) {
        $module_ids = explode(',', $section->sequence);
        foreach ($module_ids as $module_id) {
            try {
                $cm = $modinfo->get_cm($module_id);
                if ($cm && $cm->visible == 0 && $cm->modname !== 'subsection') {
                    // This activity is hidden from students in a visible section
                    $teacher_resources[] = [
                        'cm' => $cm,
                        'section_name' => $section->name
                    ];
                }
            } catch (Exception $e) {
                continue;
            }
        }
    }
}

echo $OUTPUT->header();
?>

<style>
/* Hide ALL Moodle navigation and UI elements */
#region-main,
[role="main"] {
    background: transparent !important;
    box-shadow: none !important;
    border: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
}

/* Remove ALL gaps and spacing from page wrapper */
#page {
    margin: 0 !important;
    padding: 0 !important;
}

#page-content {
    padding: 0 !important;
    margin: 0 !important;
}

#region-main-box {
    padding: 0 !important;
    margin: 0 !important;
}

.drawers {
    margin: 0 !important;
    padding: 0 !important;
}

/* Hide Moodle navigation bars (but keep top navbar) */
.secondary-navigation,
.tertiary-navigation,
.breadcrumb,
#page-header,
.page-context-header,
.activity-navigation,
[data-region="drawer"],
.drawer-toggles {
    display: none !important;
}

/* Hide page header title area */
#page-header {
    display: none !important;
}

/* Teacher Course View Wrapper */
.teacher-course-view-wrapper {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
    min-height: 100vh;
}

.teacher-dashboard-wrapper {
    display: flex;
    min-height: 100vh;
}

.teacher-main-content {
    flex: 1;
    padding: 0;
    width: 100%;
}

.content-wrapper {
    margin: 0 auto;
    padding: 0 15px 30px 15px;
}

/* Course Header - Simple Pastel Design */
.course-view-header {
    background: linear-gradient(135deg,rgb(211, 211, 211) 0%,rgb(228, 227, 227) 100%);
    padding: 32px 40px;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 30px;
    margin-bottom: 20px;
    margin-top: -20px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 20px;
    flex: 1;
}

.header-icon {
    width: 56px;
    height: 56px;
    background: #e3f2fd;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: #5b9bd5;
    flex-shrink: 0;
}

.course-header-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.course-view-title {
    font-size: 24px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
    line-height: 1.3;
}

.course-view-subtitle {
    color: #6c757d;
    font-size: 13px;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 6px;
}

.course-view-subtitle i {
    font-size: 12px;
    color: #5b9bd5;
}

.header-right {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

/* Course Selector Dropdown - Simple */
.course-selector-wrapper {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.selector-label {
    color: #6c757d;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    gap: 6px;
    margin: 0;
}

.selector-label i {
    font-size: 10px;
    color: #5b9bd5;
}

.course-selector {
    padding: 11px 18px;
    font-size: 14px;
    font-weight: 500;
    color: #2c3e50;
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    min-width: 280px;
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%236c757d' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    padding-right: 40px;
}

.course-selector:hover {
    border-color: #5b9bd5;
    box-shadow: 0 2px 8px rgba(91, 155, 213, 0.15);
}

.course-selector:focus {
    outline: none;
    border-color: #5b9bd5;
    box-shadow: 0 0 0 3px rgba(91, 155, 213, 0.1);
}

/* Teacher Resources View - Kanban Style */
.teacher-resources-container {
    background: transparent;
    border-radius: 0;
    box-shadow: none;
    overflow: visible;
    border: none;
}

.resources-header {
    background: white;
    color: #2c3e50;
    padding: 24px 30px;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    margin-bottom: 24px;
    border: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 24px;
}

.resources-header-left {
    flex: 1;
}

.resources-header-right {
    display: flex;
    flex-direction: column;
    gap: 8px;
    align-items: flex-end;
}

.resources-header h2 {
    margin: 0 0 8px 0;
    font-size: 20px;
    font-weight: 600;
    color: #2c3e50;
}

.resources-header h2 i {
    color: #ffa726;
    margin-right: 8px;
}

.resources-header p {
    margin: 0;
    color: #6c757d;
    font-size: 13px;
}

.filter-label {
    font-size: 11px;
    font-weight: 600;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    gap: 6px;
    margin: 0;
}

.filter-label i {
    color: #5b9bd5;
    font-size: 10px;
}

.resource-type-filter {
    padding: 10px 16px;
    font-size: 14px;
    font-weight: 500;
    color: #2c3e50;
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    min-width: 200px;
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%236c757d' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    padding-right: 36px;
}

.resource-type-filter:hover {
    border-color: #5b9bd5;
    box-shadow: 0 2px 8px rgba(91, 155, 213, 0.15);
}

.resource-type-filter:focus {
    outline: none;
    border-color: #5b9bd5;
    box-shadow: 0 0 0 3px rgba(91, 155, 213, 0.1);
}

/* Kanban Board */
.resources-content {
    padding: 0;
}

.kanban-board {
    display: flex;
    gap: 20px;
    overflow-x: auto;
    padding-bottom: 20px;
}

/* Kanban Column */
.kanban-column {
    flex: 0 0 320px;
    min-width: 320px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
    display: flex;
    flex-direction: column;
    max-height: 75vh;
}

.kanban-column-header {
    padding: 20px;
    border-bottom: 2px solid #e9ecef;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 12px 12px 0 0;
}

.kanban-column-title {
    font-size: 16px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0 0 8px 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.kanban-column-title i {
    color: #5b9bd5;
    font-size: 18px;
}

.folder-info-btn {
    background: transparent;
    border: none;
    color: #5b9bd5;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 4px;
    transition: all 0.2s ease;
    font-size: 14px;
    margin-left: 4px;
}

.folder-info-btn:hover {
    background: rgba(91, 155, 213, 0.1);
    color: #4a8bc2;
}

.folder-info-btn i {
    font-size: 14px;
}

.kanban-column-count {
    font-size: 12px;
    color: #6c757d;
    font-weight: 500;
}

.kanban-column-body {
    padding: 16px;
    overflow-y: auto;
    flex: 1;
}

/* Resource Card */
.resource-card {
    background: white;
    border: 1px solid #e9ecef;
    border-radius: 12px;
    padding: 0;
    margin-bottom: 12px;
    transition: all 0.2s ease;
    cursor: pointer;
    box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    overflow: hidden;
}

.resource-card:hover {
    border-color: #5b9bd5;
    box-shadow: 0 4px 12px rgba(91, 155, 213, 0.15);
    transform: translateY(-2px);
}

.resource-card:last-child {
    margin-bottom: 0;
}

.resource-card-image {
    width: 100%;
    height: 120px;
    object-fit: cover;
    display: block;
    background: #f8f9fa;
}

.resource-card-header {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 12px 16px 0 16px;
}

.resource-card-icon {
    width: 32px;
    height: 32px;
    background: #e3f2fd;
    color: #5b9bd5;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    flex-shrink: 0;
}

.resource-card-info {
    flex: 1;
    min-width: 0;
}

.resource-card-title {
    font-size: 13px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
    word-wrap: break-word;
    line-height: 1.4;
}

.resource-card-footer {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 8px;
    padding: 12px 16px 16px 16px;
    border-top: 1px solid #f0f0f0;
    margin-top: 8px;
}

.resource-card-type {
    font-size: 10px;
    color: #5b9bd5;
    background: #e3f2fd;
    padding: 4px 10px;
    border-radius: 12px;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 0.5px;
}

.resource-card-type:nth-child(2) {
    color: #6c757d;
    background: #f8f9fa;
}

.no-resources {
    text-align: center;
    padding: 60px 20px;
    color: #6c757d;
    background: white;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
}

/* Scrollbar Styling */
.kanban-board::-webkit-scrollbar {
    height: 8px;
}

.kanban-board::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.kanban-board::-webkit-scrollbar-thumb {
    background: #5b9bd5;
    border-radius: 10px;
}

.kanban-board::-webkit-scrollbar-thumb:hover {
    background: #4a8bc2;
}

.kanban-column-body::-webkit-scrollbar {
    width: 6px;
}

.kanban-column-body::-webkit-scrollbar-track {
    background: #f8f9fa;
}

.kanban-column-body::-webkit-scrollbar-thumb {
    background: #dee2e6;
    border-radius: 10px;
}

.kanban-column-body::-webkit-scrollbar-thumb:hover {
    background: #5b9bd5;
}

.no-resources i {
    font-size: 64px;
    color: #dee2e6;
    margin-bottom: 20px;
}

/* Folder Description Modal */
.folder-description-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 9998;
    padding: 20px;
}

.folder-description-modal.active {
    display: flex;
    align-items: center;
    justify-content: center;
}

.folder-description-content {
    background: white;
    border-radius: 12px;
    width: 100%;
    max-width: 800px;
    max-height: 80vh;
    display: flex;
    flex-direction: column;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
}

.folder-description-header {
    padding: 20px 24px;
    background: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
    border-radius: 12px 12px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.folder-description-title {
    font-size: 20px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
}

.folder-description-close {
    background: none;
    border: none;
    font-size: 32px;
    color: #6c757d;
    cursor: pointer;
    padding: 0;
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
    transition: all 0.2s ease;
    line-height: 1;
}

.folder-description-close:hover {
    background: #e9ecef;
    color: #2c3e50;
}

.folder-description-body {
    padding: 24px;
    overflow-y: auto;
    flex: 1;
    color: #2c3e50;
    line-height: 1.6;
}

.folder-description-body img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 12px 0;
}

.folder-description-body a {
    color: #5b9bd5;
    text-decoration: none;
}

.folder-description-body a:hover {
    text-decoration: underline;
}

.folder-description-body p {
    margin: 0 0 12px 0;
}

.folder-description-body ul,
.folder-description-body ol {
    margin: 12px 0;
    padding-left: 24px;
}

.folder-description-body h1,
.folder-description-body h2,
.folder-description-body h3,
.folder-description-body h4 {
    margin: 16px 0 12px 0;
    color: #2c3e50;
}

/* PPT Player Modal */
.ppt-player-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.9);
    z-index: 9999;
    padding: 20px;
}

.ppt-player-modal.active {
    display: flex;
    align-items: center;
    justify-content: center;
}

.ppt-player-content {
    background: white;
    border-radius: 12px;
    width: 100%;
    max-width: 1200px;
    height: 90vh;
    display: flex;
    flex-direction: column;
}

.ppt-player-header {
    padding: 20px 30px;
    background: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
    border-radius: 12px 12px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.ppt-player-title {
    font-size: 20px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
}

.ppt-player-close {
    background: none;
    border: none;
    font-size: 28px;
    color: #6c757d;
    cursor: pointer;
    padding: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    transition: all 0.2s ease;
}

.ppt-player-close:hover {
    background: #e9ecef;
    color: #212529;
}

.ppt-player-body {
    flex: 1;
    padding: 20px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}

.ppt-player-iframe {
    width: 100%;
    height: 100%;
    border: none;
    border-radius: 8px;
}

/* Responsive */
@media (max-width: 768px) {
    .teacher-main-content {
        padding: 0;
    }
    
    .course-view-header {
        flex-direction: column;
        align-items: flex-start;
        padding: 20px;
        gap: 20px;
    }
    
    .header-left {
        width: 100%;
    }
    
    .header-icon {
        width: 48px;
        height: 48px;
        font-size: 20px;
    }
    
    .header-right {
        width: 100%;
    }
    
    .course-selector {
        width: 100%;
        min-width: unset;
    }
    
    .resources-header {
        padding: 20px;
        flex-direction: column;
        align-items: flex-start;
        gap: 16px;
    }
    
    .resources-header-right {
        width: 100%;
        align-items: stretch;
    }
    
    .resources-header h2 {
        font-size: 18px;
    }
    
    .resource-type-filter {
        width: 100%;
        min-width: unset;
    }
    
    .kanban-board {
        gap: 16px;
        padding-bottom: 16px;
    }
    
    .kanban-column {
        flex: 0 0 280px;
        min-width: 280px;
    }
    
    .kanban-column-header {
        padding: 16px;
    }
    
    .kanban-column-title {
        font-size: 14px;
    }
    
    .kanban-column-body {
        padding: 12px;
    }
    
    .resource-card-image {
        height: 100px;
    }
    
    .resource-card-header {
        padding: 10px 12px 0 12px;
    }
    
    .resource-card-icon {
        width: 28px;
        height: 28px;
        font-size: 14px;
    }
    
    .resource-card-title {
        font-size: 12px;
    }
    
    .resource-card-footer {
        padding: 10px 12px 12px 12px;
    }
    
    .folder-description-modal {
        padding: 10px;
    }
    
    .folder-description-content {
        max-height: 90vh;
    }
    
    .folder-description-header {
        padding: 16px 20px;
    }
    
    .folder-description-title {
        font-size: 18px;
    }
    
    .folder-description-body {
        padding: 20px;
    }
}
</style>

<div class="teacher-course-view-wrapper">
    <div class="teacher-dashboard-wrapper">
        <!-- Mobile Sidebar Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleTeacherSidebar()">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Teacher Sidebar Navigation -->
        <div class="teacher-sidebar">
            <div class="sidebar-content">
                <!-- DASHBOARD Section -->
                <div class="sidebar-section">
                    <h3 class="sidebar-category">DASHBOARD</h3>
                    <ul class="sidebar-menu">
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/my/" class="sidebar-link">
                                <i class="fa fa-th-large sidebar-icon"></i>
                                <span class="sidebar-text">Teacher Dashboard</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/teacher_courses.php" class="sidebar-link">
                                <i class="fa fa-book sidebar-icon"></i>
                                <span class="sidebar-text">My Courses</span>
                            </a>
                        </li>
                        <li class="sidebar-item active">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/view_course.php" class="sidebar-link">
                                 <i class="fa fa-folder-open sidebar-icon"></i>
                                 <span class="sidebar-text">Teacher Resources</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- STUDENTS Section -->
                <div class="sidebar-section">
                    <h3 class="sidebar-category">STUDENTS</h3>
                    <ul class="sidebar-menu">
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/students.php" class="sidebar-link">
                                <i class="fa fa-users sidebar-icon"></i>
                                <span class="sidebar-text">All Students</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/enroll_students.php" class="sidebar-link">
                                <i class="fa fa-user-plus sidebar-icon"></i>
                                <span class="sidebar-text">Enroll Students</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/report/progress/index.php" class="sidebar-link">
                                <i class="fa fa-chart-line sidebar-icon"></i>
                                <span class="sidebar-text">Progress Reports</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- ASSESSMENTS Section -->
                <div class="sidebar-section">
                    <h3 class="sidebar-category">ASSESSMENTS</h3>
                    <ul class="sidebar-menu">
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/assignments.php" class="sidebar-link">
                                <i class="fa fa-tasks sidebar-icon"></i>
                                <span class="sidebar-text">Assignments</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/quizzes.php" class="sidebar-link">
                                <i class="fa fa-question-circle sidebar-icon"></i>
                                <span class="sidebar-text">Quizzes</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/competencies.php" class="sidebar-link">
                                <i class="fa fa-sitemap sidebar-icon"></i>
                                <span class="sidebar-text">Competencies</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/rubrics.php" class="sidebar-link">
                                <i class="fa fa-list-alt sidebar-icon"></i>
                                <span class="sidebar-text">Rubrics</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/gradebook.php" class="sidebar-link">
                                <i class="fa fa-star sidebar-icon"></i>
                                <span class="sidebar-text">Gradebook</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- QUESTIONS Section -->
                <div class="sidebar-section">
                    <h3 class="sidebar-category">QUESTIONS</h3>
                    <ul class="sidebar-menu">
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/pages/questions_unified.php" class="sidebar-link">
                                <i class="fa fa-question-circle sidebar-icon"></i>
                                <span class="sidebar-text">Questions Management</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- REPORTS Section -->
                <div class="sidebar-section">
                    <h3 class="sidebar-category">REPORTS</h3>
                    <ul class="sidebar-menu">
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/report/log/index.php" class="sidebar-link">
                                <i class="fa fa-chart-bar sidebar-icon"></i>
                                <span class="sidebar-text">Activity Logs</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/report/outline/index.php" class="sidebar-link">
                                <i class="fa fa-file-alt sidebar-icon"></i>
                                <span class="sidebar-text">Course Reports</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="<?php echo $CFG->wwwroot; ?>/report/progress/index.php" class="sidebar-link">
                                <i class="fa fa-chart-line sidebar-icon"></i>
                                <span class="sidebar-text">Progress Tracking</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Main Content with Sidebar -->
        <div class="teacher-main-content">
            <!-- Header - Improved Design -->
            <div class="course-view-header">
                <div class="header-left">
                    <div class="header-icon">
                        <i class="fa fa-folder-open"></i>
                    </div>
                    <div class="course-header-info">
                        <h1 class="course-view-title"><?php echo format_string($course->fullname); ?></h1>
                        <p class="course-view-subtitle">
                            <i class="fa fa-folder-open"></i>
                            Teacher Resources
                        </p>
                    </div>
                </div>  
                <div class="header-right">
                    <div class="course-selector-wrapper">
                        <label class="selector-label">
                            <i class="fa fa-book"></i>
                            Select Course
                        </label>
                        <select class="course-selector" id="courseSelector" onchange="changeCourse(this.value)">
                            <?php foreach ($teacher_courses as $tc): ?>
                                <option value="<?php echo $tc->id; ?>" <?php echo ($tc->id == $courseid) ? 'selected' : ''; ?>>
                                    <?php echo format_string($tc->fullname); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Content Wrapper for max-width constraint -->
            <div class="content-wrapper">
            <!-- Teacher Resources View -->
                <div class="teacher-resources-container">
                    <div class="resources-header">
                        <div class="resources-header-left">
                            <div>
                                <h2><i class="fa fa-folder-open"></i> Teacher Resources</h2>
                                <p>Materials and resources for teaching this course</p>
                            </div>
                        </div>
                        <div class="resources-header-right" id="resourcesFilterWrapper" style="display: none;">
                            <label class="filter-label">
                                <i class="fa fa-filter"></i>
                                Filter by Type
                            </label>
                            <select id="resourceTypeFilter" class="resource-type-filter" onchange="filterResourcesByType()">
                                <option value="all">All Types</option>
                            </select>
                        </div>
                    </div>
                    <div class="resources-content">
                        <?php
                        if (!empty($teacher_resources)) {
                            // Find all folders and organize files by folder
                            $folders = [];
                            $standalone_files = []; // Files not in folders
                            $available_file_types = []; // Track unique file types
                            
                            foreach ($teacher_resources as $resource) {
                                $cm = $resource['cm'];
                                
                                // If it's a folder, prepare it as a column
                                if ($cm->modname === 'folder') {
                                    $folder_name = $cm->name;
                                    
                                    // Get files inside this folder
                                    $fs = get_file_storage();
                                    $context = context_module::instance($cm->id);
                                    $files = $fs->get_area_files($context->id, 'mod_folder', 'content', 0, 'sortorder, filepath, filename', false);
                                    
                                    // Collect file types
                                    foreach ($files as $file) {
                                        $file_ext = strtoupper(pathinfo($file->get_filename(), PATHINFO_EXTENSION));
                                        if (!empty($file_ext) && !in_array($file_ext, $available_file_types)) {
                                            $available_file_types[] = $file_ext;
                                        }
                                    }
                                    
                                    $folders[$folder_name] = [
                                        'cm' => $cm,
                                        'files' => $files,
                                        'section' => $resource['section_name']
                                    ];
                                } else {
                                    // It's a standalone file/resource
                                    $standalone_files[] = $resource;
                                    
                                    // Collect resource type
                                    $resource_type = strtoupper($cm->modname);
                                    if (!in_array($resource_type, $available_file_types)) {
                                        $available_file_types[] = $resource_type;
                                    }
                                }
                            }
                            
                            // Sort file types alphabetically
                            sort($available_file_types);
                            
                            // Output JavaScript to populate filter dropdown
                            if (!empty($available_file_types)) {
                                echo '<script>';
                                echo 'document.addEventListener("DOMContentLoaded", function() {';
                                echo 'const filterSelect = document.getElementById("resourceTypeFilter");';
                                echo 'const filterWrapper = document.getElementById("resourcesFilterWrapper");';
                                echo 'if (filterSelect && filterWrapper) {';
                                foreach ($available_file_types as $file_type) {
                                    echo 'const option' . preg_replace('/[^A-Za-z0-9]/', '', $file_type) . ' = document.createElement("option");';
                                    echo 'option' . preg_replace('/[^A-Za-z0-9]/', '', $file_type) . '.value = "' . addslashes($file_type) . '";';
                                    echo 'option' . preg_replace('/[^A-Za-z0-9]/', '', $file_type) . '.textContent = "' . addslashes($file_type) . '";';
                                    echo 'filterSelect.appendChild(option' . preg_replace('/[^A-Za-z0-9]/', '', $file_type) . ');';
                                }
                                echo 'filterWrapper.style.display = "flex";';
                                echo '}';
                                echo '});';
                                echo '</script>';
                            }
                            
                            // Display as Kanban board
                            echo '<div class="kanban-board">';
                            
                            // Display folder columns
                            foreach ($folders as $folder_name => $folder_data) {
                                $files = $folder_data['files'];
                                $folder_cm = $folder_data['cm'];
                                $file_count = count($files);
                                
                                // Get folder description/intro
                                $folder_record = $DB->get_record('folder', ['id' => $folder_cm->instance]);
                                $folder_intro = '';
                                if ($folder_record && !empty($folder_record->intro)) {
                                    // Format the intro text with proper rich text handling and image support
                                    $folder_context = context_module::instance($folder_cm->id);
                                    $folder_intro = file_rewrite_pluginfile_urls(
                                        $folder_record->intro,
                                        'pluginfile.php',
                                        $folder_context->id,
                                        'mod_folder',
                                        'intro',
                                        null
                                    );
                                    $folder_intro = format_text($folder_intro, $folder_record->introformat, [
                                        'context' => $folder_context,
                                        'noclean' => true
                                    ]);
                                }
                                
                                echo '<div class="kanban-column">';
                                
                                // Store description in hidden div for later retrieval
                                if (!empty($folder_intro)) {
                                    echo '<div id="folder-desc-' . $folder_cm->id . '" style="display: none;">';
                                    echo $folder_intro;
                                    echo '</div>';
                                }
                                
                                // Column Header
                                echo '<div class="kanban-column-header">';
                                echo '<div class="kanban-column-title">';
                                echo '<i class="fa fa-folder"></i>';
                                echo '<span>' . format_string($folder_name) . '</span>';
                                
                                // Add info icon if description exists
                                if (!empty($folder_intro)) {
                                    echo '<button class="folder-info-btn" onclick="showFolderDescription(\'' . 
                                         addslashes($folder_name) . '\', ' . $folder_cm->id . ')" title="View folder description">';
                                    echo '<i class="fa fa-info-circle"></i>';
                                    echo '</button>';
                                }
                                
                                echo '</div>';
                                echo '<div class="kanban-column-count">' . $file_count . ' file' . ($file_count != 1 ? 's' : '') . '</div>';
                                echo '</div>';
                                
                                // Column Body with file cards
                                echo '<div class="kanban-column-body">';
                                
                                if (!empty($files)) {
                                    foreach ($files as $file) {
                                        $filename = $file->get_filename();
                                        $filesize = display_size($file->get_filesize());
                                        $mimetype = $file->get_mimetype();
                                        
                                        // Get file extension
                                        $file_extension = strtoupper(pathinfo($filename, PATHINFO_EXTENSION));
                                        if (empty($file_extension)) {
                                            $file_extension = 'FILE';
                                        }
                                        
                                        // Determine logo image and icon based on file extension FIRST (more reliable)
                                        $logo_image = '';
                                        $icon_class = 'fa-file';
                                        $use_image = false;
                                        
                                        // Check by extension first for Office files
                                        if ($file_extension === 'PDF') {
                                            $logo_image = 'https://m.media-amazon.com/images/I/41JbJdLaqwL.png';
                                            $icon_class = 'fa-file-pdf';
                                            $use_image = true;
                                        } else if ($file_extension === 'PPTX' || $file_extension === 'PPT') {
                                            $logo_image = 'https://cdn.rswebsols.com/wp-content/uploads/2023/03/microsoft-powerpoint-edited-920x518.png?strip=all&lossy=1&ssl=1';
                                            $icon_class = 'fa-file-powerpoint';
                                            $use_image = true;
                                        } else if ($file_extension === 'XLSX' || $file_extension === 'XLS' || $file_extension === 'CSV') {
                                            $logo_image = 'https://www.ryadel.com/wp-content/uploads/2019/03/excel-logo-xls-xlsx-ms-microsoft.jpg';
                                            $icon_class = 'fa-file-excel';
                                            $use_image = true;
                                        } else if ($file_extension === 'DOCX' || $file_extension === 'DOC') {
                                            $logo_image = 'https://chromeready.com/wp-content/uploads/sites/3/2022/11/open-Office-Word-Document-.docx-with-Google-Docs.png';
                                            $icon_class = 'fa-file-word';
                                            $use_image = true;
                                        } else if (strpos($mimetype, 'pdf') !== false) {
                                            $logo_image = 'https://m.media-amazon.com/images/I/41JbJdLaqwL.png';
                                            $icon_class = 'fa-file-pdf';
                                            $use_image = true;
                                        } else if (strpos($mimetype, 'image') !== false) {
                                            $icon_class = 'fa-file-image';
                                        } else if (strpos($mimetype, 'video') !== false) {
                                            $icon_class = 'fa-file-video';
                                        } else if (strpos($mimetype, 'text') !== false) {
                                            $icon_class = 'fa-file-alt';
                                        } else if (strpos($mimetype, 'zip') !== false || strpos($mimetype, 'compressed') !== false) {
                                            $icon_class = 'fa-file-archive';
                                        }
                                        
                                        // Get file URL
                                        $fileurl = moodle_url::make_pluginfile_url(
                                            $file->get_contextid(),
                                            $file->get_component(),
                                            $file->get_filearea(),
                                            $file->get_itemid(),
                                            $file->get_filepath(),
                                            $file->get_filename()
                                        );
                                        
                                        echo '<div class="resource-card" data-file-type="' . $file_extension . '" onclick="window.open(\'' . $fileurl . '\', \'_blank\')">';
                                        
                                        // Show image logo if available
                                        if ($use_image && !empty($logo_image)) {
                                            echo '<img src="' . $logo_image . '" alt="' . $file_extension . ' file" class="resource-card-image">';
                                        }
                                        
                                        // Card Header
                                        echo '<div class="resource-card-header">';
                                        if (!$use_image) {
                                            echo '<div class="resource-card-icon"><i class="fa ' . $icon_class . '"></i></div>';
                                        }
                                        echo '<div class="resource-card-info">';
                                        echo '<div class="resource-card-title">' . s($filename) . '</div>';
                                        echo '</div>';
                                        echo '</div>';
                                        
                                        // Card Footer
                                        echo '<div class="resource-card-footer">';
                                        echo '<div class="resource-card-type">' . $file_extension . '</div>';
                                        echo '<div class="resource-card-type">' . $filesize . '</div>';
                                        echo '</div>';
                                        
                                        echo '</div>'; // End resource-card
                                    }
                                } else {
                                    echo '<div style="padding: 20px; text-align: center; color: #6c757d; font-size: 13px;">Empty folder</div>';
                                }
                                
                                echo '</div>'; // End kanban-column-body
                                echo '</div>'; // End kanban-column
                            }
                            
                            // If there are standalone files (not in folders), show them in "Other Resources" column
                            if (!empty($standalone_files)) {
                                echo '<div class="kanban-column">';
                                
                                echo '<div class="kanban-column-header">';
                                echo '<div class="kanban-column-title">';
                                echo '<i class="fa fa-file-alt"></i>';
                                echo '<span>Other Resources</span>';
                                echo '</div>';
                                echo '<div class="kanban-column-count">' . count($standalone_files) . ' resource' . (count($standalone_files) != 1 ? 's' : '') . '</div>';
                                echo '</div>';
                                
                                echo '<div class="kanban-column-body">';
                                
                                foreach ($standalone_files as $resource) {
                                    $cm = $resource['cm'];
                                    $mod_name = $cm->modname;
                                    $icon_class = 'fa-file';
                                    
                                    if ($mod_name === 'resource') {
                                        $icon_class = 'fa-file-pdf';
                                    } else if ($mod_name === 'url') {
                                        $icon_class = 'fa-link';
                                    } else if ($mod_name === 'page') {
                                        $icon_class = 'fa-file-alt';
                                    } else if ($mod_name === 'assign') {
                                        $icon_class = 'fa-tasks';
                                    } else if ($mod_name === 'quiz') {
                                        $icon_class = 'fa-question-circle';
                                    } else if ($mod_name === 'book') {
                                        $icon_class = 'fa-book';
                                    }
                                    
                                    echo '<div class="resource-card" onclick="openResource(' . $cm->id . ', \'' . 
                                         addslashes($cm->name) . '\', \'' . $mod_name . '\')">';
                                    
                                    echo '<div class="resource-card-header">';
                                    echo '<div class="resource-card-icon"><i class="fa ' . $icon_class . '"></i></div>';
                                    echo '<div class="resource-card-info">';
                                    echo '<div class="resource-card-title">' . format_string($cm->name) . '</div>';
                                    echo '</div>';
                                    echo '</div>';
                                    
                                    echo '<div class="resource-card-footer">';
                                    echo '<div class="resource-card-type">' . strtoupper($mod_name) . '</div>';
                                    echo '</div>';
                                    
                                    echo '</div>';
                                }
                                
                                echo '</div>';
                                echo '</div>';
                            }
                            
                            echo '</div>'; // End kanban-board
                        } else {
                            echo '<div class="no-resources">';
                            echo '<i class="fa fa-info-circle"></i>';
                            echo '<p>No teacher resources found in this course.</p>';
                            echo '<p style="font-size: 13px; margin-top: 10px;">To add teacher resources:</p>';
                            echo '<ol style="text-align: left; display: inline-block; font-size: 13px; color: #6c757d; margin-top: 8px;">';
                            echo '<li>Create a section named "Teacher Resources" or hide any section</li>';
                            echo '<li>Add folders with files to organize your resources</li>';
                            echo '<li>Each folder will become a Kanban column</li>';
                            echo '</ol>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div><!-- End content-wrapper -->
        </div><!-- End teacher-main-content -->
    </div><!-- End teacher-dashboard-wrapper -->
</div><!-- End teacher-course-view-wrapper -->

<!-- Folder Description Modal -->
<div id="folderDescriptionModal" class="folder-description-modal">
    <div class="folder-description-content">
        <div class="folder-description-header">
            <h3 class="folder-description-title" id="folderDescriptionTitle">Folder Description</h3>
            <button class="folder-description-close" onclick="closeFolderDescription()">×</button>
        </div>
        <div class="folder-description-body" id="folderDescriptionBody">
            <!-- Description content will be inserted here -->
        </div>
    </div>
</div>

<!-- PPT Player Modal -->
<div id="pptPlayerModal" class="ppt-player-modal">
    <div class="ppt-player-content">
        <div class="ppt-player-header">
            <h3 class="ppt-player-title" id="pptPlayerTitle">Resource Viewer</h3>
            <button class="ppt-player-close" onclick="closePPTPlayer()">×</button>
        </div>
        <div class="ppt-player-body">
            <iframe id="pptPlayerIframe" class="ppt-player-iframe" src=""></iframe>
        </div>
    </div>
</div>

<script>
// Sidebar Toggle Function
function toggleTeacherSidebar() {
    const sidebar = document.querySelector('.teacher-sidebar');
    sidebar.classList.toggle('sidebar-open');
}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
    const sidebar = document.querySelector('.teacher-sidebar');
    const toggleButton = document.querySelector('.sidebar-toggle');
    
    if (window.innerWidth <= 768) {
        if (!sidebar.contains(event.target) && !toggleButton.contains(event.target)) {
            sidebar.classList.remove('sidebar-open');
        }
    }
});

// Handle window resize
window.addEventListener('resize', function() {
    const sidebar = document.querySelector('.teacher-sidebar');
    if (window.innerWidth > 768) {
        sidebar.classList.remove('sidebar-open');
    }
});

// Change course - reload page with new course ID
function changeCourse(courseId) {
    if (courseId) {
        window.location.href = 'view_course.php?id=' + courseId;
    }
}

// Filter resources by file type
function filterResourcesByType() {
    const selectedType = document.getElementById('resourceTypeFilter').value;
    const allCards = document.querySelectorAll('.resource-card');
    const allColumns = document.querySelectorAll('.kanban-column');
    
    allCards.forEach(card => {
        const cardType = card.getAttribute('data-file-type');
        
        if (selectedType === 'all' || cardType === selectedType) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
    
    // Hide/show columns based on whether they have visible cards
    allColumns.forEach(column => {
        const columnBody = column.querySelector('.kanban-column-body');
        const visibleCards = columnBody.querySelectorAll('.resource-card:not([style*="display: none"])');
        
        if (visibleCards.length === 0) {
            column.style.display = 'none';
        } else {
            column.style.display = '';
            
            // Update card count in column header
            const countElement = column.querySelector('.kanban-column-count');
            if (countElement) {
                const fileText = visibleCards.length === 1 ? 'file' : 'files';
                countElement.textContent = visibleCards.length + ' ' + fileText;
            }
        }
    });
}

// Show folder description in modal
function showFolderDescription(folderName, folderId) {
    const modal = document.getElementById('folderDescriptionModal');
    const title = document.getElementById('folderDescriptionTitle');
    const body = document.getElementById('folderDescriptionBody');
    
    // Get description from hidden div
    const descriptionDiv = document.getElementById('folder-desc-' + folderId);
    
    if (descriptionDiv) {
        title.textContent = folderName;
        body.innerHTML = descriptionDiv.innerHTML;
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

// Close folder description modal
function closeFolderDescription() {
    const modal = document.getElementById('folderDescriptionModal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
}

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeFolderDescription();
    }
});

// Close modal on background click
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('folderDescriptionModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeFolderDescription();
            }
        });
    }
});

// Open resource (PPT player for files, new tab for others)
function openResource(cmid, name, modname) {
    const url = '<?php echo $CFG->wwwroot; ?>/mod/' + modname + '/view.php?id=' + cmid;
    
    // For resources and folders, open in player
    if (modname === 'resource' || modname === 'folder') {
        openPPTPlayer(url, name);
    } else {
        // For other types, open in new tab
        window.open(url, '_blank');
    }
}

// Open PPT player modal
function openPPTPlayer(url, title) {
    const modal = document.getElementById('pptPlayerModal');
    const iframe = document.getElementById('pptPlayerIframe');
    const titleElement = document.getElementById('pptPlayerTitle');
    
    titleElement.textContent = title;
    iframe.src = url;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Close PPT player
function closePPTPlayer() {
    const modal = document.getElementById('pptPlayerModal');
    const iframe = document.getElementById('pptPlayerIframe');
    
    modal.classList.remove('active');
    iframe.src = '';
    document.body.style.overflow = '';
}

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePPTPlayer();
    }
});

// Close modal on background click
document.getElementById('pptPlayerModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closePPTPlayer();
    }
});
</script>

<?php
echo $OUTPUT->footer();
?>
?>