<?php
/**
 * Custom Assignments Page for Teacher Dashboard
 * 
 * This page provides a comprehensive view of all assignments
 * with advanced filtering, search, and management capabilities.
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// Security checks
require_login();
$context = context_system::instance();

// Restrict to teachers/admins
if (!has_capability('moodle/course:update', $context) && !has_capability('moodle/site:config', $context)) {
    throw new moodle_exception('nopermissions', 'error', '', 'access teacher assignments page');
}

// Page setup
$PAGE->set_context($context);
$PAGE->set_url('/theme/remui_kids/teacher/assignments.php');
$PAGE->set_title('Assignments');
$PAGE->set_heading('Assignments Management');

// Get parameters for filtering
$courseid = optional_param('courseid', 0, PARAM_INT);
$status = optional_param('status', 'all', PARAM_ALPHA);
$search = optional_param('search', '', PARAM_TEXT);
$sort = optional_param('sort', 'duedate', PARAM_ALPHA);

// Get teacher's courses
$teacher_courses = $DB->get_records_sql("
    SELECT DISTINCT c.id, c.fullname, c.shortname, c.startdate, c.enddate
    FROM {course} c
    JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = " . CONTEXT_COURSE . "
    JOIN {role_assignments} ra ON ra.contextid = ctx.id
    JOIN {role} r ON r.id = ra.roleid
    WHERE ra.userid = ? AND r.shortname IN ('teacher', 'editingteacher', 'manager')
    AND c.id > 1
    ORDER BY c.fullname
", [$USER->id]);

// Get assignments based on filters
$assignments_sql = "
    SELECT a.*, c.fullname as course_name, c.shortname as course_shortname,
           cm.id as cmid, cm.visible,
           (SELECT COUNT(*) FROM {assign_submission} s WHERE s.assignment = a.id) as submission_count,
           (SELECT COUNT(*) FROM {assign_grades} g WHERE g.assignment = a.id AND g.grade >= 0) as graded_count,
           (SELECT COUNT(*) FROM {grading_definitions} gd 
            JOIN {grading_areas} ga ON ga.id = gd.areaid 
            WHERE ga.contextid = ctx.id AND gd.method = 'rubric') as has_rubric
    FROM {assign} a
    JOIN {course} c ON c.id = a.course
    JOIN {course_modules} cm ON cm.instance = a.id AND cm.module = (SELECT id FROM {modules} WHERE name = 'assign')
    JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = " . CONTEXT_COURSE . "
    JOIN {role_assignments} ra ON ra.contextid = ctx.id
    JOIN {role} r ON r.id = ra.roleid
    WHERE ra.userid = ? AND r.shortname IN ('teacher', 'editingteacher', 'manager')
    AND c.id > 1
    AND cm.deletioninprogress = 0
";

$params = [$USER->id];

// Apply course filter
if ($courseid > 0) {
    $assignments_sql .= " AND a.course = ?";
    $params[] = $courseid;
}

// Apply search filter
if (!empty($search)) {
    $assignments_sql .= " AND (a.name LIKE ? OR c.fullname LIKE ?)";
    $search_param = '%' . $search . '%';
    $params[] = $search_param;
    $params[] = $search_param;
}

// Apply status filter
switch ($status) {
    case 'active':
        $assignments_sql .= " AND a.allowsubmissionsfromdate <= ? AND a.duedate >= ?";
        $params[] = time();
        $params[] = time();
        break;
    case 'overdue':
        $assignments_sql .= " AND a.duedate < ?";
        $params[] = time();
        break;
    case 'upcoming':
        $assignments_sql .= " AND a.allowsubmissionsfromdate > ?";
        $params[] = time();
        break;
}

// Apply sorting
switch ($sort) {
    case 'name':
        $assignments_sql .= " ORDER BY a.name ASC";
        break;
    case 'course':
        $assignments_sql .= " ORDER BY c.fullname ASC, a.name ASC";
        break;
    case 'duedate':
    default:
        $assignments_sql .= " ORDER BY a.duedate ASC, a.name ASC";
        break;
}

$assignments = $DB->get_records_sql($assignments_sql, $params);

// Calculate statistics
$total_assignments = count($assignments);
$active_assignments = 0;
$overdue_assignments = 0;
$total_submissions = 0;
$total_graded = 0;

foreach ($assignments as $assignment) {
    $now = time();
    if ($assignment->allowsubmissionsfromdate <= $now && $assignment->duedate >= $now) {
        $active_assignments++;
    } elseif ($assignment->duedate < $now) {
        $overdue_assignments++;
    }
    $total_submissions += $assignment->submission_count;
    $total_graded += $assignment->graded_count;
}

echo $OUTPUT->header();
?>

<style>
/* Hide Moodle's default main content area */

#region-main,
[role="main"] {
    background: transparent !important;
    box-shadow: none !important;
    border: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
}
/* Teacher Dashboard Styles */
.teacher-css-wrapper {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
    min-height: 100vh;
}

.teacher-dashboard-wrapper {
    display: flex;
    min-height: 100vh;
}

.teacher-sidebar {
    width: 280px;
    background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
    color: white;
    padding: 0;
    overflow-y: auto;
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    position: fixed;
    height: 100vh;
    z-index: 1000;
}

.teacher-sidebar.collapsed {
    width: 60px;
}

.sidebar-header {
    padding: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    text-align: center;
}

.sidebar-logo {
    font-size: 24px;
    font-weight: bold;
    color: #ecf0f1;
    margin-bottom: 10px;
}

.sidebar-toggle {
    display: none;
    background: #3498db;
    color: white;
    border: none;
    padding: 10px;
    border-radius: 5px;
    cursor: pointer;
    margin-bottom: 20px;
}

.sidebar-section {
    margin-bottom: 30px;
}

.sidebar-category {
    color: #bdc3c7;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 0 20px 10px;
    margin: 0;
}

.sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar-item {
    margin: 0;
}

.sidebar-link {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    color: #ecf0f1;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
}

.sidebar-link:hover {
    background-color: rgba(255,255,255,0.1);
    border-left-color: #3498db;
    color: white;
}

.sidebar-item.active .sidebar-link {
    background-color: rgba(52, 152, 219, 0.2);
    border-left-color: #3498db;
    color: #3498db;
}

.sidebar-icon {
    width: 20px;
    margin-right: 12px;
    text-align: center;
    font-size: 16px;
}

.sidebar-text {
    font-size: 14px;
    font-weight: 500;
}

.teacher-main-content {
    flex: 1;
    margin-left: 280px;
    padding: 30px;
    transition: margin-left 0.3s ease;
}

.teacher-sidebar.collapsed + .teacher-main-content {
    margin-left: 60px;
}

.assignments-header {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.assignments-title {
    font-size: 28px;
    font-weight: 700;
    color: #2c3e50;
    margin: 0 0 10px 0;
}

.assignments-subtitle {
    color: #7f8c8d;
    font-size: 16px;
    margin: 0 0 20px 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    text-align: center;
}

.stat-number {
    font-size: 32px;
    font-weight: 700;
    color: #2c3e50;
    margin: 0;
}

.stat-label {
    color: #7f8c8d;
    font-size: 14px;
    margin: 5px 0 0 0;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filters-section {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.filters-row {
    display: flex;
    gap: 15px;
    align-items: end;
    flex-wrap: wrap;
}

.filter-group {
    flex: 1;
    min-width: 200px;
}

.filter-label {
    display: block;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 5px;
    font-size: 14px;
}

.filter-input, .filter-select {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    transition: border-color 0.3s ease;
}

.filter-input:focus, .filter-select:focus {
    outline: none;
    border-color: #3498db;
    box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.btn-primary {
    background: #3498db;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-primary:hover {
    background: #2980b9;
}

.btn-secondary {
    background: #95a5a6;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-secondary:hover {
    background: #7f8c8d;
}

/* Assignments Table Styles */
.assignments-table-container {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    overflow: hidden;
}

.table-responsive {
    overflow-x: auto;
}

.assignments-table {
    width: 100%;
    border-collapse: collapse;
    margin: 0;
}

.assignments-table th {
    background: #f8f9fa;
    color: #495057;
    font-weight: 600;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 16px 12px;
    text-align: left;
    border: none;
    border-bottom: 2px solid #dee2e6;
}

.assignments-table th:first-child {
    border-top-left-radius: 12px;
}

.assignments-table th:last-child {
    border-top-right-radius: 12px;
}

.assignments-table td {
    padding: 16px 12px;
    border-bottom: 1px solid #f1f3f4;
    vertical-align: top;
}

.assignment-row:hover {
    background-color: #f8f9fa;
}

.assignment-row:last-child td {
    border-bottom: none;
}

/* Column Widths */
.col-assignment {
    width: 30%;
    min-width: 250px;
}

.col-course {
    width: 15%;
    min-width: 120px;
}

.col-status {
    width: 12%;
    min-width: 100px;
}

.col-due-date {
    width: 15%;
    min-width: 120px;
}

.col-submissions,
.col-graded {
    width: 10%;
    min-width: 80px;
}

.col-progress {
    width: 12%;
    min-width: 100px;
}

.col-actions {
    width: 16%;
    min-width: 120px;
}

/* Assignment Info */
.assignment-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.assignment-title-row {
    display: flex;
    align-items: center;
    gap: 8px;
}

.assignment-title {
    font-size: 16px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
    line-height: 1.3;
    flex: 1;
}

/* Rubric Indicator */
.rubric-indicator {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    background: #6f42c1;
    color: white;
    border-radius: 4px;
    text-decoration: none;
    font-size: 12px;
    transition: all 0.2s ease;
    flex-shrink: 0;
}

.rubric-indicator:hover {
    background: #5a32a3;
    transform: translateY(-1px);
    box-shadow: 0 2px 6px rgba(111, 66, 193, 0.3);
    color: white;
    text-decoration: none;
}

.assignment-description {
    font-size: 13px;
    color: #7f8c8d;
    margin: 0;
    line-height: 1.4;
}

/* Course Name */
.course-name {
    font-size: 14px;
    font-weight: 500;
    color: #5d6d7e;
}

/* Status Badges */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
}

.status-active {
    background: #d4edda;
    color: #155724;
}

.status-overdue {
    background: #f8d7da;
    color: #721c24;
}

.status-upcoming {
    background: #d1ecf1;
    color: #0c5460;
}

.status-completed {
    background: #e2e3e5;
    color: #383d41;
}

/* Due Date */
.due-date-info {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    color: #5d6d7e;
}

.due-date-info i {
    color: #95a5a6;
}

/* Submission and Graded Counts */
.submission-count,
.graded-count {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

.count-number {
    font-size: 20px;
    font-weight: 700;
    color: #2c3e50;
    line-height: 1;
}

.count-label {
    font-size: 11px;
    color: #7f8c8d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 2px;
}

/* Progress Bar */
.progress-container {
    display: flex;
    align-items: center;
    gap: 8px;
}

.progress-bar {
    flex: 1;
    height: 8px;
    background: #ecf0f1;
    border-radius: 4px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #27ae60 0%, #2ecc71 100%);
    border-radius: 4px;
    transition: width 0.3s ease;
}

.progress-text {
    font-size: 12px;
    font-weight: 600;
    color: #2c3e50;
    min-width: 35px;
    text-align: right;
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 6px;
    align-items: center;
}

.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 6px;
    text-decoration: none;
    transition: all 0.2s ease;
    font-size: 14px;
}

.btn-view {
    background: #17a2b8;
    color: white;
}

.btn-view:hover {
    background: #138496;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(23, 162, 184, 0.3);
}

.btn-grade {
    background: #28a745;
    color: white;
}

.btn-grade:hover {
    background: #218838;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(40, 167, 69, 0.3);
}

.btn-edit {
    background: #ffc107;
    color: #212529;
}

.btn-edit:hover {
    background: #e0a800;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(255, 193, 7, 0.3);
    color: #212529;
}

.btn-rubric {
    background: #6f42c1;
    color: white;
}

.btn-rubric:hover {
    background: #5a32a3;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(111, 66, 193, 0.3);
}

.status-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-active {
    background: #d4edda;
    color: #155724;
}

.status-overdue {
    background: #f8d7da;
    color: #721c24;
}

.status-upcoming {
    background: #d1ecf1;
    color: #0c5460;
}

.status-completed {
    background: #e2e3e5;
    color: #383d41;
}

@media (max-width: 768px) {
    .teacher-sidebar {
        transform: translateX(-100%);
    }
    
    .teacher-sidebar.open {
        transform: translateX(0);
    }
    
    .teacher-main-content {
        margin-left: 0;
        padding: 20px;
    }
    
    .sidebar-toggle {
        display: block;
    }
    
    .filters-row {
        flex-direction: column;
    }
    
    .assignments-table-container {
        overflow-x: auto;
    }
    
    .assignments-table {
        min-width: 800px;
    }
    
    .assignment-title {
        font-size: 14px;
    }
    
    .assignment-description {
        font-size: 12px;
    }
    
    .rubric-indicator {
        width: 20px;
        height: 20px;
        font-size: 10px;
    }
    
    .status-badge {
        font-size: 10px;
        padding: 4px 8px;
    }
    
    .action-btn {
        width: 28px;
        height: 28px;
        font-size: 12px;
    }
    
    .count-number {
        font-size: 16px;
    }
    
    .count-label {
        font-size: 10px;
    }
}

/* Create Assignment Button */
.btn-create-assignment {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    text-decoration: none;
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 2px 8px rgba(40, 167, 69, 0.3);
}

.btn-create-assignment:hover {
    background: linear-gradient(135deg, #218838, #1ea085);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(40, 167, 69, 0.4);
    color: white;
    text-decoration: none;
}
</style>

<div class="teacher-css-wrapper">
    <div class="teacher-dashboard-wrapper">
        <!-- Sidebar Toggle Button -->
        <button class="sidebar-toggle" onclick="toggleTeacherSidebar()">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Teacher Sidebar -->
        <div class="teacher-sidebar" id="teacherSidebar">
                <div class="sidebar-header">
                    <div class="sidebar-logo"></div>
                </div>

            <div class="sidebar-section">
                    <h3 class="sidebar-category">DASHBOARD</h3>
                    <ul class="sidebar-menu">
                        <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/my/" class="sidebar-link"><i class="fa fa-th-large sidebar-icon"></i><span class="sidebar-text">Teacher Dashboard</span></a></li>
                        <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/teacher_courses.php/theme/remui_kids/teacher/teacher_courses.php" class="sidebar-link"><i class="fa fa-book sidebar-icon"></i><span class="sidebar-text">My Courses</span></a></li>
                    </ul>
                </div>

            <!-- Students Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">STUDENTS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/students.php" class="sidebar-link"><i class="fa fa-users sidebar-icon"></i><span class="sidebar-text">All Students</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/enroll_students.php" class="sidebar-link"><i class="fa fa-user-plus sidebar-icon"></i><span class="sidebar-text">Enroll Students</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Reports</span></a></li>
                </ul>
            </div>

            <!-- Assessments Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">ASSESSMENTS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item active"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/assignments.php" class="sidebar-link"><i class="fa fa-tasks sidebar-icon"></i><span class="sidebar-text">Assignments</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/quizzes.php" class="sidebar-link"><i class="fa fa-question-circle sidebar-icon"></i><span class="sidebar-text">Quizzes</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/competencies.php" class="sidebar-link"><i class="fa fa-sitemap sidebar-icon"></i><span class="sidebar-text">Competencies</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/rubrics.php" class="sidebar-link"><i class="fa fa-list-alt sidebar-icon"></i><span class="sidebar-text">Rubrics</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/gradebook.php" class="sidebar-link"><i class="fa fa-star sidebar-icon"></i><span class="sidebar-text">Gradebook</span></a></li>
                </ul>
            </div>

            <!-- Questions Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">QUESTIONS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/pages/questions_unified.php" class="sidebar-link"><i class="fa fa-question-circle sidebar-icon"></i><span class="sidebar-text">Questions Management</span></a></li>
                </ul>
            </div>

            <!-- Reports Section -->
            <div class="sidebar-section">
                <h3 class="sidebar-category">REPORTS</h3>
                <ul class="sidebar-menu">
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/log/index.php" class="sidebar-link"><i class="fa fa-chart-bar sidebar-icon"></i><span class="sidebar-text">Activity Logs</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/outline/index.php" class="sidebar-link"><i class="fa fa-file-alt sidebar-icon"></i><span class="sidebar-text">Course Reports</span></a></li>
                    <li class="sidebar-item"><a href="<?php echo $CFG->wwwroot; ?>/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Tracking</span></a></li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="teacher-main-content">
            <!-- Header Section -->
            <div class="assignments-header">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <div>
                        <h1 class="assignments-title">Assignments Management</h1>
                        <p class="assignments-subtitle">Manage and track all your course assignments</p>
                    </div>
                    <a href="create_assignment_page.php" class="btn-create-assignment">
                        <i class="fa fa-plus"></i> Create Assignment
                    </a>
                </div>

                <!-- Statistics -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <h3 class="stat-number"><?php echo $total_assignments; ?></h3>
                        <p class="stat-label">Total Assignments</p>
                    </div>
                    <div class="stat-card">
                        <h3 class="stat-number"><?php echo $active_assignments; ?></h3>
                        <p class="stat-label">Active</p>
                    </div>
                    <div class="stat-card">
                        <h3 class="stat-number"><?php echo $overdue_assignments; ?></h3>
                        <p class="stat-label">Overdue</p>
                    </div>
                    <div class="stat-card">
                        <h3 class="stat-number"><?php echo $total_submissions; ?></h3>
                        <p class="stat-label">Total Submissions</p>
                    </div>
                    <div class="stat-card">
                        <h3 class="stat-number"><?php echo $total_graded; ?></h3>
                        <p class="stat-label">Graded</p>
                    </div>
                </div>
            </div>

            <!-- Filters Section -->
            <div class="filters-section">
                <form method="GET" class="filters-row">
                    <div class="filter-group">
                        <label class="filter-label">Course</label>
                        <select name="courseid" class="filter-select">
                            <option value="0">All Courses</option>
                            <?php foreach ($teacher_courses as $course): ?>
                                <option value="<?php echo $course->id; ?>" <?php echo ($courseid == $course->id) ? 'selected' : ''; ?>>
                                    <?php echo format_string($course->fullname); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Status</label>
                        <select name="status" class="filter-select">
                            <option value="all" <?php echo ($status == 'all') ? 'selected' : ''; ?>>All</option>
                            <option value="active" <?php echo ($status == 'active') ? 'selected' : ''; ?>>Active</option>
                            <option value="overdue" <?php echo ($status == 'overdue') ? 'selected' : ''; ?>>Overdue</option>
                            <option value="upcoming" <?php echo ($status == 'upcoming') ? 'selected' : ''; ?>>Upcoming</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Search</label>
                        <input type="text" name="search" class="filter-input" placeholder="Search assignments..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Sort By</label>
                        <select name="sort" class="filter-select">
                            <option value="duedate" <?php echo ($sort == 'duedate') ? 'selected' : ''; ?>>Due Date</option>
                            <option value="name" <?php echo ($sort == 'name') ? 'selected' : ''; ?>>Name</option>
                            <option value="course" <?php echo ($sort == 'course') ? 'selected' : ''; ?>>Course</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn-primary">Apply Filters</button>
                        <a href="<?php echo $PAGE->url; ?>" class="btn-secondary">Clear</a>
                    </div>
                </form>
            </div>

            <!-- Assignments Table -->
            <div class="assignments-table-container">
                <?php if (empty($assignments)): ?>
                    <div class="no-assignments" style="text-align: center; padding: 60px; color: #7f8c8d; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                        <i class="fa fa-tasks" style="font-size: 64px; margin-bottom: 20px; opacity: 0.3;"></i>
                        <h3 style="margin: 0 0 10px 0; color: #5d6d7e;">No assignments found</h3>
                        <p style="margin: 0; font-size: 16px;">Try adjusting your filters or create a new assignment.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="assignments-table">
                            <thead>
                                <tr>
                                    <th class="col-assignment">Assignment</th>
                                    <th class="col-course">Course</th>
                                    <th class="col-status">Status</th>
                                    <th class="col-due-date">Due Date</th>
                                    <th class="col-submissions">Submissions</th>
                                    <th class="col-graded">Graded</th>
                                    <th class="col-progress">Progress</th>
                                    <th class="col-actions">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($assignments as $assignment): ?>
                                    <?php
                                    // Determine status
                                    $now = time();
                                    $status_class = 'status-completed';
                                    $status_text = 'Completed';
                                    $status_icon = 'fa-check-circle';
                                    
                                    if ($assignment->duedate < $now) {
                                        $status_class = 'status-overdue';
                                        $status_text = 'Overdue';
                                        $status_icon = 'fa-exclamation-triangle';
                                    } elseif ($assignment->allowsubmissionsfromdate > $now) {
                                        $status_class = 'status-upcoming';
                                        $status_text = 'Upcoming';
                                        $status_icon = 'fa-clock-o';
                                    } elseif ($assignment->allowsubmissionsfromdate <= $now && $assignment->duedate >= $now) {
                                        $status_class = 'status-active';
                                        $status_text = 'Active';
                                        $status_icon = 'fa-play-circle';
                                    }
                                    
                                    // Calculate completion rate
                                    $completion_rate = $assignment->submission_count > 0 ? round(($assignment->graded_count / $assignment->submission_count) * 100) : 0;
                                    $has_rubric = $assignment->has_rubric > 0;
                                    ?>
                                    <tr class="assignment-row">
                                        <td class="col-assignment">
                                            <div class="assignment-info">
                                                <div class="assignment-title-row">
                                                    <h4 class="assignment-title"><?php echo format_string($assignment->name); ?></h4>
                                                    <?php if ($has_rubric): ?>
                                                        <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/rubric_grading.php?assignmentid=<?php echo $assignment->id; ?>&courseid=<?php echo $assignment->course; ?>" 
                                                           class="rubric-indicator" title="Rubric Grading Available">
                                                            <i class="fa fa-list-alt"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                                <p class="assignment-description">
                                                    <?php echo format_string(substr(strip_tags($assignment->intro), 0, 80)); ?>
                                                    <?php if (strlen(strip_tags($assignment->intro)) > 80): ?>...<?php endif; ?>
                                                </p>
                                            </div>
                                        </td>
                                        <td class="col-course">
                                            <span class="course-name"><?php echo format_string($assignment->course_name); ?></span>
                                        </td>
                                        <td class="col-status">
                                            <span class="status-badge <?php echo $status_class; ?>">
                                                <i class="fa <?php echo $status_icon; ?>"></i>
                                                <?php echo $status_text; ?>
                                            </span>
                                        </td>
                                        <td class="col-due-date">
                                            <div class="due-date-info">
                                                <i class="fa fa-calendar"></i>
                                                <span><?php echo userdate($assignment->duedate, get_string('strftimedatefullshort')); ?></span>
                                            </div>
                                        </td>
                                        <td class="col-submissions">
                                            <div class="submission-count">
                                                <span class="count-number"><?php echo $assignment->submission_count; ?></span>
                                                <span class="count-label">submissions</span>
                                            </div>
                                        </td>
                                        <td class="col-graded">
                                            <div class="graded-count">
                                                <span class="count-number"><?php echo $assignment->graded_count; ?></span>
                                                <span class="count-label">graded</span>
                                            </div>
                                        </td>
                                        <td class="col-progress">
                                            <div class="progress-container">
                                                <div class="progress-bar">
                                                    <div class="progress-fill" style="width: <?php echo $completion_rate; ?>%"></div>
                                                </div>
                                                <span class="progress-text"><?php echo $completion_rate; ?>%</span>
                                            </div>
                                        </td>
                                        <td class="col-actions">
                                            <div class="action-buttons">
                                                <a href="<?php echo $CFG->wwwroot; ?>/mod/assign/view.php?id=<?php echo $assignment->cmid; ?>" 
                                                   class="action-btn btn-view" title="View Assignment">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                                <a href="<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/edit_assignment_page.php?id=<?php echo $assignment->cmid; ?>&courseid=<?php echo $assignment->course; ?>" 
                                                   class="action-btn btn-edit" title="Edit Assignment">
                                                    <i class="fa fa-pencil-alt"></i>
                                                </a>
                                                <a href="<?php echo $CFG->wwwroot; ?>/mod/assign/view.php?id=<?php echo $assignment->cmid; ?>&action=grading" 
                                                   class="action-btn btn-grade" title="Grade Submissions">
                                                    <i class="fa fa-check-circle"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<script>
function toggleTeacherSidebar() {
    const sidebar = document.getElementById('teacherSidebar');
    sidebar.classList.toggle('collapsed');
}


// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', function() {
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.getElementById('teacherSidebar');
    
    if (window.innerWidth <= 768) {
        sidebar.classList.add('collapsed');
    }
    
    window.addEventListener('resize', function() {
        if (window.innerWidth <= 768) {
            sidebar.classList.add('collapsed');
        } else {
            sidebar.classList.remove('collapsed');
        }
    });
});
</script>

<?php
echo $OUTPUT->footer();
?>