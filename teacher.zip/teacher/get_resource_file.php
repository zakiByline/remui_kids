<?php
/**
 * Get Resource File URL
 * Fetches the actual file URL for a resource to display in viewer
 */

define('AJAX_SCRIPT', true);

require_once(__DIR__ . '/../../../config.php');

header('Content-Type: application/json');

require_login();

try {
    $cmid = required_param('cmid', PARAM_INT);
    
    // Get course module
    $cm = get_coursemodule_from_id('resource', $cmid, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
    
    // Verify access - check if user is enrolled or is a teacher
    $coursecontext = context_course::instance($course->id);
    
    // Allow access if user is a teacher/admin OR enrolled in the course
    $canaccess = has_capability('moodle/course:update', $coursecontext) || 
                 has_capability('moodle/course:view', $coursecontext) ||
                 is_enrolled($coursecontext, $USER->id) ||
                 is_siteadmin();
    
    if (!$canaccess) {
        throw new moodle_exception('nopermissions', 'error', '', 'access resource file');
    }
    
    // Get the resource
    $resource = $DB->get_record('resource', ['id' => $cm->instance], '*', MUST_EXIST);
    
    // Get context
    $context = context_module::instance($cm->id);
    
    // Get files
    $fs = get_file_storage();
    $files = $fs->get_area_files($context->id, 'mod_resource', 'content', 0, 'sortorder DESC, id ASC', false);
    
    if (empty($files)) {
        echo json_encode([
            'success' => false,
            'message' => 'No file found'
        ]);
        exit;
    }
    
    // Get the first file
    $file = reset($files);
    
    // Generate the file URL
    $fileurl = moodle_url::make_pluginfile_url(
        $file->get_contextid(),
        $file->get_component(),
        $file->get_filearea(),
        $file->get_itemid(),
        $file->get_filepath(),
        $file->get_filename(),
        false
    )->out(true); // true = force download disabled
    
    echo json_encode([
        'success' => true,
        'fileurl' => $fileurl,
        'filename' => $file->get_filename(),
        'mimetype' => $file->get_mimetype(),
        'contextid' => $file->get_contextid(),
        'component' => $file->get_component(),
        'filearea' => $file->get_filearea(),
        'itemid' => $file->get_itemid(),
        'filepath' => $file->get_filepath()
    ]);
    
} catch (Exception $e) {
    error_log("get_resource_file.php error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

