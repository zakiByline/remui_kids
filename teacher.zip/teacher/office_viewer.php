<?php
/**
 * Office Document Viewer
 * Serves Office files (PPT, DOC, XLS) through Microsoft Office Online viewer
 * with proper authentication
 */

require_once(__DIR__ . '/../../../config.php');

// Require login but don't require course context yet
require_login(null, false);

// Get file parameters
$fileid = optional_param('fileid', 0, PARAM_INT);
$contextid = required_param('contextid', PARAM_INT);
$component = required_param('component', PARAM_TEXT);
$filearea = required_param('filearea', PARAM_TEXT);
$itemid = required_param('itemid', PARAM_INT);
$filepath = required_param('filepath', PARAM_TEXT);
$filename = required_param('filename', PARAM_TEXT);

// Get context
$context = context::instance_by_id($contextid);

// Get the course module to find the course
$cm = null;
$course = null;

if ($context->contextlevel == CONTEXT_MODULE) {
    // Get the course module record directly from context
    $cm = $DB->get_record('course_modules', ['id' => $context->instanceid], '*', MUST_EXIST);
    $course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
} else if ($context->contextlevel == CONTEXT_COURSE) {
    $course = $DB->get_record('course', ['id' => $context->instanceid], '*', MUST_EXIST);
}

// Verify access - check at course level
if (!$course) {
    print_error('coursemisconf');
}

// Now require login to the specific course
require_login($course, false);

// Get course context
$coursecontext = context_course::instance($course->id);

// Check access - be very permissive for teachers
$canaccess = false;

// First check: Is user a site admin?
if (is_siteadmin()) {
    $canaccess = true;
    error_log("office_viewer.php: Access granted - user {$USER->id} is site admin");
}

// Second check: Can user update the course? (teachers, managers)
if (!$canaccess && has_capability('moodle/course:update', $coursecontext)) {
    $canaccess = true;
    error_log("office_viewer.php: Access granted - user {$USER->id} has course:update in course {$course->id}");
}

// Third check: Can user view the course?
if (!$canaccess && has_capability('moodle/course:view', $coursecontext)) {
    $canaccess = true;
    error_log("office_viewer.php: Access granted - user {$USER->id} has course:view in course {$course->id}");
}

// Fourth check: Is user enrolled?
if (!$canaccess && is_enrolled($coursecontext, $USER->id, '', true)) {
    $canaccess = true;
    error_log("office_viewer.php: Access granted - user {$USER->id} is enrolled in course {$course->id}");
}

// If still no access, check if they can view hidden courses
if (!$canaccess && has_capability('moodle/course:viewhiddencourses', $coursecontext)) {
    $canaccess = true;
    error_log("office_viewer.php: Access granted - user {$USER->id} can view hidden courses");
}

if (!$canaccess) {
    // Detailed error logging
    error_log("office_viewer.php: ===== ACCESS DENIED =====");
    error_log("office_viewer.php: User ID: {$USER->id}");
    error_log("office_viewer.php: Username: {$USER->username}");
    error_log("office_viewer.php: Course ID: {$course->id}");
    error_log("office_viewer.php: Course Name: {$course->fullname}");
    error_log("office_viewer.php: Context ID: {$contextid}");
    error_log("office_viewer.php: Context Level: {$context->contextlevel}");
    error_log("office_viewer.php: is_siteadmin: " . (is_siteadmin() ? 'YES' : 'NO'));
    error_log("office_viewer.php: has course:update: " . (has_capability('moodle/course:update', $coursecontext) ? 'YES' : 'NO'));
    error_log("office_viewer.php: has course:view: " . (has_capability('moodle/course:view', $coursecontext) ? 'YES' : 'NO'));
    error_log("office_viewer.php: has course:viewhiddencourses: " . (has_capability('moodle/course:viewhiddencourses', $coursecontext) ? 'YES' : 'NO'));
    error_log("office_viewer.php: is_enrolled: " . (is_enrolled($coursecontext, $USER->id, '', true) ? 'YES' : 'NO'));
    
    // Get user's roles in this course
    $roles = get_user_roles($coursecontext, $USER->id);
    $rolenames = [];
    foreach ($roles as $role) {
        $rolenames[] = $role->shortname;
    }
    error_log("office_viewer.php: User roles in course: " . implode(', ', $rolenames));
    error_log("office_viewer.php: ========================");
    
    print_error('nopermissions', 'error', '', 'access this file');
}

error_log("office_viewer.php: Access granted for user {$USER->id} to view file in course {$course->id}");

// Get the file
$fs = get_file_storage();
$file = $fs->get_file($contextid, $component, $filearea, $itemid, $filepath, $filename);

if (!$file) {
    print_error('filenotfound', 'error');
}

// Create direct file serving URL (bypasses authentication for Office Online)
// This URL goes through our serve_office_file.php which handles authentication
// and serves the file directly with proper headers
$fileurl = new moodle_url('/theme/remui_kids/teacher/serve_office_file.php', [
    'contextid' => $contextid,
    'component' => $component,
    'filearea' => $filearea,
    'itemid' => $itemid,
    'filepath' => $filepath,
    'filename' => $filename
]);
$fileurl = $fileurl->out(true); // Get absolute URL

// Log the file URL for debugging
error_log("office_viewer.php: Generated file URL = $fileurl");
error_log("office_viewer.php: WWW Root = {$CFG->wwwroot}");
error_log("office_viewer.php: File parameters: contextid=$contextid, component=$component, filearea=$filearea, itemid=$itemid, filepath=$filepath, filename=$filename");

// Get file extension
$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

// Check if we're on localhost
$is_localhost = (strpos($CFG->wwwroot, 'localhost') !== false || 
                 strpos($CFG->wwwroot, '127.0.0.1') !== false ||
                 strpos($CFG->wwwroot, '::1') !== false);

// Determine viewer type
$viewerUrl = '';
$viewerType = 'office'; // office, google, or download

if (in_array($extension, ['ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx'])) {
    if ($is_localhost) {
        // Localhost - Office viewer won't work, show download
        $viewerType = 'download';
        $error_message = 'Office documents cannot be previewed on localhost. Microsoft Office Online requires a publicly accessible URL. Please download the file to view it.';
    } else {
        // Production server - try Microsoft Office Online viewer
        $viewerUrl = 'https://view.officeapps.live.com/op/embed.aspx?src=' . urlencode($fileurl);
        $viewerType = 'office';
        
        // Log the Office viewer URL
        error_log("office_viewer.php: Office Online Viewer URL = $viewerUrl");
        error_log("office_viewer.php: Raw file URL (before encoding) = $fileurl");
    }
} else {
    // Unsupported - show download
    $viewerType = 'download';
    $error_message = 'This file type is not supported for preview.';
}

// Set page layout
$PAGE->set_context($context);
$PAGE->set_url('/theme/remui_kids/teacher/office_viewer.php');
$PAGE->set_pagelayout('embedded'); // Use embedded layout for cleaner view
$PAGE->set_title(format_string($filename));

echo $OUTPUT->header();
?>

<style>
body {
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #2b2b2b;
}

#region-main {
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
}

.office-viewer-container {
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: column;
    background-color: #2b2b2b;
}

.viewer-header {
    background-color: #1f1f1f;
    color: white;
    padding: 12px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.3);
    z-index: 1000;
}

.viewer-title {
    font-size: 14px;
    font-weight: 500;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.viewer-title i {
    color: #4CAF50;
}

.viewer-actions {
    display: flex;
    gap: 10px;
}

.viewer-btn {
    background-color: #3b82f6;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: background-color 0.2s;
}

.viewer-btn:hover {
    background-color: #2563eb;
}

.viewer-btn.secondary {
    background-color: #6b7280;
}

.viewer-btn.secondary:hover {
    background-color: #4b5563;
}

.viewer-content {
    flex: 1;
    position: relative;
    overflow: hidden;
}

.viewer-iframe {
    width: 100%;
    height: 100%;
    border: none;
    background-color: white;
}

.viewer-loading {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    color: white;
    z-index: 10;
}

.loading-spinner {
    width: 50px;
    height: 50px;
    border: 4px solid #333;
    border-top: 4px solid #4CAF50;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 20px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.viewer-fallback {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    color: white;
    background-color: #1f1f1f;
    padding: 40px;
    border-radius: 12px;
    max-width: 500px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.5);
    display: none;
}

.viewer-fallback.active {
    display: block;
}

.fallback-icon {
    font-size: 64px;
    color: #dc2626;
    margin-bottom: 20px;
}

.fallback-title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 12px;
    color: white;
}

.fallback-message {
    font-size: 14px;
    color: #9ca3af;
    margin-bottom: 24px;
    line-height: 1.6;
}

.fallback-actions {
    display: flex;
    gap: 12px;
    justify-content: center;
}
</style>

<div class="office-viewer-container">
    <div class="viewer-header">
        <div class="viewer-title">
            <i class="fa fa-file-<?php 
                if ($extension === 'ppt' || $extension === 'pptx') echo 'powerpoint';
                else if ($extension === 'doc' || $extension === 'docx') echo 'word';
                else if ($extension === 'xls' || $extension === 'xlsx') echo 'excel';
                else echo 'o';
            ?>"></i>
            <?php echo format_string($filename); ?>
        </div>
        <div class="viewer-actions">
            <a href="<?php echo $fileurl; ?>" download="<?php echo $filename; ?>" class="viewer-btn">
                <i class="fa fa-download"></i>
                Download
            </a>
            <button onclick="window.close()" class="viewer-btn secondary">
                <i class="fa fa-times"></i>
                Close
            </button>
        </div>
    </div>
    
    <div class="viewer-content">
        <div class="viewer-loading" id="viewerLoading">
            <div class="loading-spinner"></div>
            <p>Loading document...</p>
        </div>
        
        <?php if ($viewerType === 'office'): ?>
            <iframe id="viewerIframe" 
                    class="viewer-iframe" 
                    src="<?php echo $viewerUrl; ?>"
                    allow="autoplay">
            </iframe>
        <?php elseif ($viewerType === 'download'): ?>
            <div class="viewer-fallback active">
                <div class="fallback-icon">
                    <i class="fa fa-<?php 
                        if ($extension === 'ppt' || $extension === 'pptx') echo 'file-powerpoint-o';
                        else if ($extension === 'doc' || $extension === 'docx') echo 'file-word-o';
                        else if ($extension === 'xls' || $extension === 'xlsx') echo 'file-excel-o';
                        else echo 'file-o';
                    ?>"></i>
                </div>
                <div class="fallback-title">Preview Not Available</div>
                <div class="fallback-message">
                    <?php echo isset($error_message) ? $error_message : 'This file cannot be previewed in the browser.'; ?>
                </div>
                <div class="fallback-actions">
                    <a href="<?php echo $fileurl; ?>" download="<?php echo $filename; ?>" class="viewer-btn">
                        <i class="fa fa-download"></i>
                        Download File
                    </a>
                    <button onclick="window.close()" class="viewer-btn secondary">
                        <i class="fa fa-times"></i>
                        Close
                    </button>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="viewer-fallback" id="viewerFallback">
            <div class="fallback-icon">
                <i class="fa fa-exclamation-triangle"></i>
            </div>
            <div class="fallback-title">Preview Not Available</div>
            <div class="fallback-message">
                The document viewer cannot display this file. This may happen if:
                <ul style="text-align: left; margin: 12px 0; padding-left: 24px;">
                    <li>The file is too large</li>
                    <li>The file format is not supported</li>
                    <li>The viewer service is temporarily unavailable</li>
                </ul>
                Please download the file to view it on your computer.
            </div>
            <div class="fallback-actions">
                <a href="<?php echo $fileurl; ?>" download="<?php echo $filename; ?>" class="viewer-btn">
                    <i class="fa fa-download"></i>
                    Download File
                </a>
                <button onclick="window.close()" class="viewer-btn secondary">
                    <i class="fa fa-times"></i>
                    Close
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Handle iframe loading
const iframe = document.getElementById('viewerIframe');
const loading = document.getElementById('viewerLoading');
const fallback = document.getElementById('viewerFallback');

if (iframe) {
    let loadTimeout = setTimeout(() => {
        // If takes too long, show fallback
        loading.style.display = 'none';
        fallback.classList.add('active');
    }, 15000); // 15 second timeout

    iframe.onload = function() {
        clearTimeout(loadTimeout);
        
        // Check if error page loaded
        setTimeout(() => {
            try {
                // Try to detect error page
                const iframeWin = iframe.contentWindow;
                const iframeUrl = iframeWin.location.href;
                
                if (iframeUrl.includes('errorpage') || iframeUrl.includes('error')) {
                    loading.style.display = 'none';
                    fallback.classList.add('active');
                } else {
                    // Loaded successfully
                    loading.style.display = 'none';
                }
            } catch (e) {
                // Cross-origin - means external viewer loaded (good!)
                loading.style.display = 'none';
            }
        }, 1000);
    };

    iframe.onerror = function() {
        clearTimeout(loadTimeout);
        loading.style.display = 'none';
        fallback.classList.add('active');
    };
}

// Close on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        window.close();
    }
});
</script>

<?php
echo $OUTPUT->footer();
?>

