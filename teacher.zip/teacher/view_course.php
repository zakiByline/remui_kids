<?php
/**
 * Teacher Course View Page
 * Dedicated course viewing page for teachers with two views:
 * 1. Teacher Resources - Shows resources hidden from students (PPTs, etc.)
 * 2. Student View - Shows all course content in tree format
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->dirroot . '/course/lib.php');

// Security checks
require_login();
$context = context_system::instance();

// Get course ID
$courseid = required_param('id', PARAM_INT);

// Get course
$course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
$coursecontext = context_course::instance($courseid);

// Verify user is a teacher in this course
require_capability('moodle/course:update', $coursecontext);

// Page setup
$PAGE->set_context($coursecontext);
$PAGE->set_url('/theme/remui_kids/teacher/view_course.php', ['id' => $courseid]);
$PAGE->set_pagelayout('base'); // Use base layout to minimize Moodle UI
$PAGE->set_title(format_string($course->fullname));
$PAGE->set_heading(''); // Remove default heading

// Get course sections
$sections = $DB->get_records('course_sections', ['course' => $courseid], 'section ASC');

// Get modinfo for the course
$modinfo = get_fast_modinfo($courseid);

// Get ALL activities/resources that are hidden from students
$teacher_resources = []; // Activities hidden from students
$student_sections = []; // Sections visible to students

foreach ($sections as $section) {
    // Skip section 0 (general section)
    if ($section->section == 0) {
        continue;
    }
    
    // Skip sections that ARE subsections themselves (component = 'mod_subsection')
    if ($section->component === 'mod_subsection') {
        continue;
    }
    
    // Check if section is hidden from students
    $section_hidden = ($section->visible == 0);
    
    // If section is hidden OR named "Teacher Resources", check its activities
    if ($section_hidden || 
        stripos($section->name, 'teacher resource') !== false || 
        stripos($section->name, 'teacher material') !== false ||
        stripos($section->name, 'instructor resource') !== false) {
        
        // Get all activities in this section
        if (!empty($section->sequence)) {
            $module_ids = explode(',', $section->sequence);
            foreach ($module_ids as $module_id) {
                try {
                    $cm = $modinfo->get_cm($module_id);
                    if (!$cm) continue;
                    
                    // If it's a subsection, look inside it for activities
                    if ($cm->modname === 'subsection') {
                        // Get the subsection's actual section
                        $subsection = $DB->get_record('course_sections', [
                            'component' => 'mod_subsection',
                            'itemid' => $cm->instance
                        ]);
                        
                        if ($subsection && !empty($subsection->sequence)) {
                            $sub_module_ids = explode(',', $subsection->sequence);
                            foreach ($sub_module_ids as $sub_module_id) {
                                try {
                                    $sub_cm = $modinfo->get_cm($sub_module_id);
                                    if ($sub_cm && $sub_cm->modname !== 'subsection') {
                                        // Add activities from inside subsection
                                        $teacher_resources[] = [
                                            'cm' => $sub_cm,
                                            'section_name' => $section->name . ' > ' . $subsection->name
                                        ];
                                    }
                                } catch (Exception $e) {
                                    continue;
                                }
                            }
                        }
                    } else {
                        // Regular activity (not a subsection)
                        $teacher_resources[] = [
                            'cm' => $cm,
                            'section_name' => $section->name
                        ];
                    }
                } catch (Exception $e) {
                    // Skip invalid modules
                    continue;
                }
            }
        }
    }
    
    // Also check for individual hidden activities in visible sections
    if (!$section_hidden && !empty($section->sequence)) {
        $module_ids = explode(',', $section->sequence);
        foreach ($module_ids as $module_id) {
            try {
                $cm = $modinfo->get_cm($module_id);
                if ($cm && $cm->visible == 0 && $cm->modname !== 'subsection') {
                    // This activity is hidden from students in a visible section
                    $teacher_resources[] = [
                        'cm' => $cm,
                        'section_name' => $section->name
                    ];
                }
            } catch (Exception $e) {
                continue;
            }
        }
        
        // This section is visible to students - add to student view
        $student_sections[] = $section;
    }
}

echo $OUTPUT->header();
?>

<style>
/* Hide ALL Moodle navigation and UI elements */
#region-main,
[role="main"] {
    background: transparent !important;
    box-shadow: none !important;
    border: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
}

/* Remove ALL gaps and spacing from page wrapper */
#page {
    margin: 0 !important;
    padding: 0 !important;
}

#page-content {
    padding: 0 !important;
    margin: 0 !important;
}

#region-main-box {
    padding: 0 !important;
    margin: 0 !important;
}

.drawers {
    margin: 0 !important;
    padding: 0 !important;
}

/* Hide Moodle navigation bars (but keep top navbar) */
.secondary-navigation,
.tertiary-navigation,
.breadcrumb,
#page-header,
.page-context-header,
.activity-navigation,
[data-region="drawer"],
.drawer-toggles {
    display: none !important;
}

/* Hide page header title area */
#page-header {
    display: none !important;
}

/* Teacher Course View Wrapper */
.teacher-course-view-wrapper {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
    min-height: 100vh;
}

.teacher-dashboard-wrapper {
    display: flex;
    min-height: 100vh;
}

.teacher-main-content {
    flex: 1;
    padding: 0;
    width: 100%;
}

.content-wrapper {
    margin: 0 auto;
    padding: 0 15px 30px 15px;
}

/* Course Header - Sticky below navbar */
.course-view-header {
    background: white;
    padding: 32px 40px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    position: sticky;
    top: 50px; /* Stick below navbar (adjust based on your navbar height) */
    z-index: 100;
    display: flex;
    align-items: center;
    gap: 24px;
    min-height: 100px;
}

/* View Toggle - Also sticky below header */
.view-toggle-section {
    background: white;
    padding: 20px 30px;
    border-radius: 0;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: sticky;
    top: 150px; /* Stick below header (50px navbar + 100px header) */
    z-index: 99;
}

.back-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: #6c757d;
    color: white;
    text-decoration: none;
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.back-button:hover {
    background: #5a6268;
    color: white;
    text-decoration: none;
    transform: translateY(-1px);
}

.course-header-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.course-view-title {
    font-size: 28px;
    font-weight: 700;
    color: #2c3e50;
    margin: 0;
    line-height: 1.2;
}

.course-view-subtitle {
    color: #7f8c8d;
    font-size: 14px;
    margin: 0;
}

/* View Toggle - styles defined above with sticky positioning */

.view-toggle-buttons {
    display: flex;
    gap: 12px;
    background: #f8f9fa;
    padding: 6px;
    border-radius: 8px;
}

.view-toggle-btn {
    padding: 10px 24px;
    border: none;
    background: transparent;
    color: #6c757d;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border-radius: 6px;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    gap: 8px;
}

.view-toggle-btn.active {
    background: white;
    color: #28a745;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.view-toggle-btn:hover:not(.active) {
    background: #e9ecef;
}

/* Content Views */
.view-content {
    display: none;
}

.view-content.active {
    display: block;
}

/* Teacher Resources View */
.teacher-resources-container {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    overflow: hidden;
}

.resources-header {
    background: linear-gradient(135deg, #6f42c1, #5a32a3);
    color: white;
    padding: 24px 30px;
    border-bottom: 4px solid #5a32a3;
}

.resources-header h2 {
    margin: 0 0 8px 0;
    font-size: 24px;
    font-weight: 600;
}

.resources-header p {
    margin: 0;
    opacity: 0.9;
    font-size: 14px;
}

.resources-content {
    padding: 30px;
}

.resource-item {
    background: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 16px;
    transition: all 0.2s ease;
    cursor: pointer;
}

.resource-item:hover {
    border-color: #6f42c1;
    background: white;
    box-shadow: 0 2px 8px rgba(111, 66, 193, 0.1);
}

.resource-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, #6f42c1, #5a32a3);
    color: white;
    border-radius: 8px;
    font-size: 20px;
    margin-right: 16px;
    float: left;
}

.resource-info {
    overflow: hidden;
}

.resource-title {
    font-size: 16px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0 0 8px 0;
}

.resource-type {
    font-size: 13px;
    color: #6c757d;
    margin: 0;
}

.no-resources {
    text-align: center;
    padding: 60px 20px;
    color: #6c757d;
}

.no-resources i {
    font-size: 64px;
    color: #dee2e6;
    margin-bottom: 20px;
}

/* Student View - Tree Format */
.student-view-container {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    overflow: hidden;
}

.student-view-header {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    padding: 24px 30px;
    border-bottom: 4px solid #20c997;
}

.student-view-header h2 {
    margin: 0 0 8px 0;
    font-size: 24px;
    font-weight: 600;
}

.student-view-header p {
    margin: 0;
    opacity: 0.9;
    font-size: 14px;
}

.student-view-content {
    padding: 30px;
}

.course-tree {
    list-style: none;
    padding: 0;
    margin: 0;
}

.section-item {
    margin-bottom: 20px;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    overflow: hidden;
}

.section-header {
    background: #f8f9fa;
    padding: 16px 20px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #e9ecef;
    transition: all 0.2s ease;
}

.section-header:hover {
    background: #e9ecef;
}

.section-header-left {
    display: flex;
    align-items: center;
    gap: 12px;
    flex: 1;
}

.section-number {
    background: #28a745;
    color: white;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 14px;
    flex-shrink: 0;
}

.section-name {
    font-size: 16px;
    font-weight: 600;
    color: #2c3e50;
}

.section-toggle {
    background: none;
    border: none;
    color: #6c757d;
    font-size: 18px;
    cursor: pointer;
    transition: transform 0.2s ease;
}

.section-toggle.expanded {
    transform: rotate(90deg);
}

.section-content {
    display: none;
    padding: 20px;
    background: white;
}

.section-content.show {
    display: block;
}

/* Subsections and Modules */
.subsection-list {
    list-style: none;
    padding: 0;
    margin: 0 0 0 24px;
}

.subsection-item {
    margin-bottom: 16px;
    border-left: 3px solid #dee2e6;
    padding-left: 20px;
}

.subsection-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 16px;
    background: #f8f9fa;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.subsection-header:hover {
    background: #e9ecef;
}

.subsection-icon {
    color: #007bff;
    font-size: 16px;
}

.subsection-name {
    font-size: 15px;
    font-weight: 600;
    color: #495057;
    flex: 1;
}

.subsection-toggle {
    background: none;
    border: none;
    color: #6c757d;
    font-size: 14px;
    cursor: pointer;
}

.activity-list {
    list-style: none;
    padding: 12px 0 0 32px;
    margin: 0;
    display: none;
}

.activity-list.show {
    display: block;
}

.activity-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 16px;
    margin-bottom: 8px;
    background: white;
    border: 1px solid #e9ecef;
    border-radius: 6px;
    transition: all 0.2s ease;
}

.activity-item:hover {
    border-color: #28a745;
    background: #f8f9fa;
    transform: translateX(4px);
}

.activity-icon {
    width: 32px;
    height: 32px;
    flex-shrink: 0;
}

.activity-icon img {
    width: 100%;
    height: 100%;
    object-fit: contain;
}

.activity-name {
    font-size: 14px;
    color: #495057;
    flex: 1;
}

.activity-type {
    font-size: 12px;
    color: #6c757d;
    background: #e9ecef;
    padding: 4px 10px;
    border-radius: 12px;
    text-transform: uppercase;
    font-weight: 600;
}

/* PPT Player Modal */
.ppt-player-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.9);
    z-index: 9999;
    padding: 20px;
}

.ppt-player-modal.active {
    display: flex;
    align-items: center;
    justify-content: center;
}

.ppt-player-content {
    background: white;
    border-radius: 12px;
    width: 100%;
    max-width: 1200px;
    height: 90vh;
    display: flex;
    flex-direction: column;
}

.ppt-player-header {
    padding: 20px 30px;
    background: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
    border-radius: 12px 12px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.ppt-player-title {
    font-size: 20px;
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
}

.ppt-player-close {
    background: none;
    border: none;
    font-size: 28px;
    color: #6c757d;
    cursor: pointer;
    padding: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    transition: all 0.2s ease;
}

.ppt-player-close:hover {
    background: #e9ecef;
    color: #212529;
}

.ppt-player-body {
    flex: 1;
    padding: 20px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}

.ppt-player-iframe {
    width: 100%;
    height: 100%;
    border: none;
    border-radius: 8px;
}

/* Responsive */
@media (max-width: 768px) {
    .teacher-main-content {
        padding: 20px;
    }
}
</style>

<div class="teacher-course-view-wrapper">
    <div class="teacher-dashboard-wrapper">
        <!-- Main Content (No Sidebar) -->
        <div class="teacher-main-content" style="margin-left: 0; margin: 0 auto;">
            <!-- Header - Sticky -->
            <div class="course-view-header">
                <a href="teacher_courses.php" class="back-button">
                    <i class="fa fa-arrow-left"></i>
                    Back to Courses
                </a>
                <div class="course-header-info">
                    <h1 class="course-view-title"><?php echo format_string($course->fullname); ?></h1>
                </div>
            </div>

            <!-- Content Wrapper for max-width constraint -->
            <div class="content-wrapper">
            <!-- View Toggle -->
            <div class="view-toggle-section">
                <div class="view-toggle-buttons">
                    <button class="view-toggle-btn active" onclick="switchView('teacher-resources-view')">
                        <i class="fa fa-folder-open"></i>
                        Teacher Resources
                    </button>
                    <button class="view-toggle-btn" onclick="switchView('student-view')">
                        <i class="fa fa-sitemap"></i>
                        Student View
                    </button>
                </div>
                <div>
                    <a href="<?php echo $CFG->wwwroot; ?>/course/view.php?id=<?php echo $courseid; ?>" 
                       class="back-button" style="background: #007bff;">
                        <i class="fa fa-external-link-alt"></i>
                        Manage the Course
                    </a>
                </div>
            </div>

            <!-- Teacher Resources View -->
            <div id="teacher-resources-view" class="view-content active">
                <div class="teacher-resources-container">
                    <div class="resources-header">
                        <h2><i class="fa fa-folder-open"></i> Teacher Resources</h2>
                        <p>Materials and resources for teaching this course</p>
                    </div>
                    <div class="resources-content">
                        <?php
                        if (!empty($teacher_resources)) {
                            // Group resources by section for better organization
                            $resources_by_section = [];
                            foreach ($teacher_resources as $resource) {
                                $section_name = $resource['section_name'];
                                if (!isset($resources_by_section[$section_name])) {
                                    $resources_by_section[$section_name] = [];
                                }
                                $resources_by_section[$section_name][] = $resource['cm'];
                            }
                            
                            // Display resources grouped by section
                            foreach ($resources_by_section as $section_name => $cms) {
                                // Always show section/subsection path for context
                                echo '<h3 style="margin: 0 0 16px 0; color: #495057; font-size: 16px; padding-bottom: 8px; border-bottom: 2px solid #e9ecef;">';
                                echo '<i class="fa fa-folder" style="color: #6f42c1; margin-right: 8px;"></i>';
                                echo format_string($section_name) . '</h3>';
                                
                                foreach ($cms as $cm) {
                                    $mod_name = $cm->modname;
                                    $icon_class = 'fa-file';
                                    
                                    // Determine icon based on module type
                                    if ($mod_name === 'resource' || $mod_name === 'folder') {
                                        $icon_class = 'fa-file-powerpoint';
                                    } else if ($mod_name === 'url') {
                                        $icon_class = 'fa-link';
                                    } else if ($mod_name === 'page') {
                                        $icon_class = 'fa-file-alt';
                                    } else if ($mod_name === 'assign') {
                                        $icon_class = 'fa-tasks';
                                    } else if ($mod_name === 'quiz') {
                                        $icon_class = 'fa-question-circle';
                                    }
                                    
                                    echo '<div class="resource-item" onclick="openResource(' . $cm->id . ', \'' . 
                                         addslashes($cm->name) . '\', \'' . $mod_name . '\')">';
                                    echo '<div class="resource-icon"><i class="fa ' . $icon_class . '"></i></div>';
                                    echo '<div class="resource-info">';
                                    echo '<div class="resource-title">' . format_string($cm->name) . '</div>';
                                    echo '<div class="resource-type">' . ucfirst($mod_name);
                                    echo '</div>';
                                    echo '</div>';
                                    echo '</div>';
                                }
                                
                                // Add spacing between sections
                                echo '<div style="margin-bottom: 24px;"></div>';
                            }
                        } else {
                            echo '<div class="no-resources">';
                            echo '<i class="fa fa-info-circle"></i>';
                            echo '<p>No hidden activities or teacher resources found in this course.</p>';
                            echo '<p style="font-size: 13px; margin-top: 10px;">To add teacher resources:</p>';
                            echo '<ol style="text-align: left; display: inline-block; font-size: 13px; color: #6c757d; margin-top: 8px;">';
                            echo '<li>Create a section named "Teacher Resources" or hide any section</li>';
                            echo '<li>Add activities (File, URL, Page, etc.) to that section</li>';
                            echo '<li>Or hide individual activities in any section</li>';
                            echo '</ol>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>

            <!-- Student View -->
            <div id="student-view" class="view-content">
                <div class="student-view-container">
                    <div class="student-view-header">
                        <h2><i class="fa fa-sitemap"></i> Student View</h2>
                        <p>See the course structure as students see it</p>
                    </div>
                    <div class="student-view-content">
                        <ul class="course-tree">
                            <?php
                            foreach ($student_sections as $section) {
                                echo '<li class="section-item">';
                                echo '<div class="section-header" onclick="toggleSection(' . $section->id . ')">';
                                echo '<div class="section-header-left">';
                                echo '<div class="section-number">' . $section->section . '</div>';
                                echo '<div class="section-name">' . format_string($section->name) . '</div>';
                                echo '</div>';
                                echo '<button class="section-toggle" id="toggle_' . $section->id . '">▶</button>';
                                echo '</div>';
                                
                                echo '<div class="section-content" id="content_' . $section->id . '">';
                                
                                // Get subsections and activities
                                if (!empty($section->sequence)) {
                                    $module_ids = explode(',', $section->sequence);
                                    
                                    echo '<ul class="subsection-list">';
                                    foreach ($module_ids as $module_id) {
                                        $cm = $modinfo->get_cm($module_id);
                                        if (!$cm) continue;
                                        
                                        // Check if it's a subsection
                                        if ($cm->modname === 'subsection') {
                                            // Get subsection details
                                            $subsection_section = $DB->get_record('course_sections', [
                                                'component' => 'mod_subsection',
                                                'itemid' => $cm->instance
                                            ]);
                                            
                                            if ($subsection_section) {
                                                echo '<li class="subsection-item">';
                                                echo '<div class="subsection-header" onclick="toggleSubsection(' . $subsection_section->id . ')">';
                                                echo '<i class="fa fa-folder subsection-icon"></i>';
                                                echo '<div class="subsection-name">' . format_string($subsection_section->name) . '</div>';
                                                echo '<button class="subsection-toggle" id="subtoggle_' . $subsection_section->id . '">▼</button>';
                                                echo '</div>';
                                                
                                                // Get activities in subsection
                                                if (!empty($subsection_section->sequence)) {
                                                    echo '<ul class="activity-list show" id="subcontent_' . $subsection_section->id . '">';
                                                    $sub_module_ids = explode(',', $subsection_section->sequence);
                                                    
                                                    foreach ($sub_module_ids as $sub_module_id) {
                                                        $sub_cm = $modinfo->get_cm($sub_module_id);
                                                        if (!$sub_cm) continue;
                                                        
                                                        echo '<li class="activity-item">';
                                                        echo '<div class="activity-icon">';
                                                        echo '<img src="' . $sub_cm->get_icon_url() . '" alt="' . $sub_cm->modname . '">';
                                                        echo '</div>';
                                                        echo '<div class="activity-name">' . format_string($sub_cm->name) . '</div>';
                                                        echo '<div class="activity-type">' . $sub_cm->modname . '</div>';
                                                        echo '</li>';
                                                    }
                                                    echo '</ul>';
                                                }
                                                echo '</li>';
                                            }
                                        } else {
                                            // Regular activity (not in subsection)
                                            echo '<li class="activity-item" style="margin-left: 0;">';
                                            echo '<div class="activity-icon">';
                                            echo '<img src="' . $cm->get_icon_url() . '" alt="' . $cm->modname . '">';
                                            echo '</div>';
                                            echo '<div class="activity-name">' . format_string($cm->name) . '</div>';
                                            echo '<div class="activity-type">' . $cm->modname . '</div>';
                                            echo '</li>';
                                        }
                                    }
                                    echo '</ul>';
                                }
                                
                                echo '</div>';
                                echo '</li>';
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
            </div><!-- End content-wrapper -->
        </div><!-- End teacher-main-content -->
    </div><!-- End teacher-dashboard-wrapper -->
</div><!-- End teacher-course-view-wrapper -->

<!-- PPT Player Modal -->
<div id="pptPlayerModal" class="ppt-player-modal">
    <div class="ppt-player-content">
        <div class="ppt-player-header">
            <h3 class="ppt-player-title" id="pptPlayerTitle">Resource Viewer</h3>
            <button class="ppt-player-close" onclick="closePPTPlayer()">×</button>
        </div>
        <div class="ppt-player-body">
            <iframe id="pptPlayerIframe" class="ppt-player-iframe" src=""></iframe>
        </div>
    </div>
</div>

<script>
// Switch between views
function switchView(viewName) {
    // Update buttons
    document.querySelectorAll('.view-toggle-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.closest('.view-toggle-btn').classList.add('active');
    
    // Update content
    document.querySelectorAll('.view-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(viewName).classList.add('active');
}

// Toggle section in student view
function toggleSection(sectionId) {
    const content = document.getElementById('content_' + sectionId);
    const toggle = document.getElementById('toggle_' + sectionId);
    
    if (content.classList.contains('show')) {
        content.classList.remove('show');
        toggle.textContent = '▶';
        toggle.classList.remove('expanded');
    } else {
        content.classList.add('show');
        toggle.textContent = '▼';
        toggle.classList.add('expanded');
    }
}

// Toggle subsection
function toggleSubsection(subsectionId) {
    const content = document.getElementById('subcontent_' + subsectionId);
    const toggle = document.getElementById('subtoggle_' + subsectionId);
    
    if (content && toggle) {
        if (content.classList.contains('show')) {
            content.classList.remove('show');
            toggle.textContent = '▶';
        } else {
            content.classList.add('show');
            toggle.textContent = '▼';
        }
    }
}

// Open resource (PPT player for files, new tab for others)
function openResource(cmid, name, modname) {
    // For resources, get the file URL and open in viewer
    if (modname === 'resource') {
        // Fetch the file URL via AJAX
        fetch('<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/get_resource_file.php?cmid=' + cmid)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.fileurl) {
                    // Check file type
                    const fileExt = data.filename.split('.').pop().toLowerCase();
                    
                    if (fileExt === 'pdf') {
                        // PDF can be previewed directly in iframe
                        openPPTPlayer(data.fileurl, name);
                    } else if (fileExt === 'ppt' || fileExt === 'pptx' || 
                               fileExt === 'doc' || fileExt === 'docx' ||
                               fileExt === 'xls' || fileExt === 'xlsx') {
                        // Open Office files in dedicated viewer (new window)
                        openOfficeViewer(cmid, data, name);
                    } else if (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png' || 
                               fileExt === 'gif' || fileExt === 'svg' || fileExt === 'webp') {
                        // Images can be previewed directly
                        showImagePreview(data.fileurl, name);
                    } else if (fileExt === 'mp4' || fileExt === 'webm' || fileExt === 'ogg') {
                        // Videos can be previewed directly
                        showVideoPreview(data.fileurl, name, fileExt);
                    } else {
                        // For other files, show download interface
                        showDownloadOption(data.fileurl, name, fileExt);
                    }
                } else {
                    alert('Could not load resource file.');
                }
            })
            .catch(error => {
                console.error('Error loading resource:', error);
                alert('Error loading resource. Opening in new tab...');
                window.open('<?php echo $CFG->wwwroot; ?>/mod/' + modname + '/view.php?id=' + cmid, '_blank');
            });
    } else {
        // For other types, open in new tab
        const url = '<?php echo $CFG->wwwroot; ?>/mod/' + modname + '/view.php?id=' + cmid;
        window.open(url, '_blank');
    }
}

// Open Office files in dedicated viewer (new window)
function openOfficeViewer(cmid, fileData, title) {
    // Build office_viewer.php URL with file parameters
    const viewerUrl = '<?php echo $CFG->wwwroot; ?>/theme/remui_kids/teacher/office_viewer.php?' +
        'contextid=' + encodeURIComponent(fileData.contextid || '') +
        '&component=' + encodeURIComponent(fileData.component || 'mod_resource') +
        '&filearea=' + encodeURIComponent(fileData.filearea || 'content') +
        '&itemid=' + encodeURIComponent(fileData.itemid || '0') +
        '&filepath=' + encodeURIComponent(fileData.filepath || '/') +
        '&filename=' + encodeURIComponent(fileData.filename);
    
    // Open in new window/tab
    const viewerWindow = window.open(viewerUrl, '_blank', 'width=1200,height=800,menubar=no,toolbar=no,location=no');
    
    if (!viewerWindow) {
        alert('Please allow popups to view Office documents');
    }
}

// Open PPT player modal
function openPPTPlayer(url, title) {
    const modal = document.getElementById('pptPlayerModal');
    const iframe = document.getElementById('pptPlayerIframe');
    const titleElement = document.getElementById('pptPlayerTitle');
    
    titleElement.textContent = title;
    iframe.src = url;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Show download option for unsupported files
function showDownloadOption(fileurl, filename, fileExt) {
    const modal = document.getElementById('pptPlayerModal');
    const iframe = document.getElementById('pptPlayerIframe');
    const titleElement = document.getElementById('pptPlayerTitle');
    
    titleElement.textContent = filename;
    
    // Determine icon and message based on file type
    let icon = 'fa-file';
    let message = 'This file cannot be previewed in the browser.';
    
    if (fileExt === 'ppt' || fileExt === 'pptx') {
        icon = 'fa-file-powerpoint';
        message = 'PowerPoint files cannot be previewed on localhost. Please download to view.';
    } else if (fileExt === 'doc' || fileExt === 'docx') {
        icon = 'fa-file-word';
        message = 'Word documents cannot be previewed on localhost. Please download to view.';
    } else if (fileExt === 'xls' || fileExt === 'xlsx') {
        icon = 'fa-file-excel';
        message = 'Excel files cannot be previewed on localhost. Please download to view.';
    }
    
    // Create download interface
    const downloadHtml = `
        <div style="padding: 40px; text-align: center; background: #f8f9fa; height: 100%;">
            <div style="font-size: 64px; color: #6c757d; margin-bottom: 20px;">
                <i class="fa ${icon}"></i>
            </div>
            <h3 style="color: #495057; margin-bottom: 16px; font-size: 20px;">Preview Not Available</h3>
            <p style="color: #6c757d; margin-bottom: 8px; font-size: 14px;">
                ${message}
            </p>
            <p style="color: #6c757d; margin-bottom: 32px; font-size: 13px;">
                File type: <strong>${fileExt.toUpperCase()}</strong>
            </p>
            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                <a href="${fileurl}" download="${filename}" 
                   style="background: #007bff; color: white; padding: 14px 28px; 
                          border-radius: 8px; text-decoration: none; display: inline-flex; 
                          align-items: center; gap: 10px; font-size: 15px; font-weight: 500;
                          box-shadow: 0 2px 8px rgba(0,123,255,0.3); transition: all 0.2s;">
                    <i class="fa fa-download"></i> Download File
                </a>
                <button onclick="window.open('${fileurl}', '_blank')" 
                        style="background: #28a745; color: white; padding: 14px 28px; 
                               border-radius: 8px; border: none; cursor: pointer; 
                               display: inline-flex; align-items: center; gap: 10px; font-size: 15px;
                               font-weight: 500; box-shadow: 0 2px 8px rgba(40,167,69,0.3); 
                               transition: all 0.2s;">
                    <i class="fa fa-external-link-alt"></i> Open in New Tab
                </button>
            </div>
        </div>
    `;
    
    iframe.srcdoc = downloadHtml;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Show image preview
function showImagePreview(fileurl, filename) {
    const modal = document.getElementById('pptPlayerModal');
    const iframe = document.getElementById('pptPlayerIframe');
    const titleElement = document.getElementById('pptPlayerTitle');
    
    titleElement.textContent = filename;
    
    const imageHtml = `
        <div style="padding: 20px; text-align: center; background: #f8f9fa; height: 100%; 
                    display: flex; align-items: center; justify-content: center;">
            <img src="${fileurl}" alt="${filename}" 
                 style="max-width: 100%; max-height: 100%; object-fit: contain;">
        </div>
    `;
    
    iframe.srcdoc = imageHtml;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Show video preview
function showVideoPreview(fileurl, filename, fileExt) {
    const modal = document.getElementById('pptPlayerModal');
    const iframe = document.getElementById('pptPlayerIframe');
    const titleElement = document.getElementById('pptPlayerTitle');
    
    titleElement.textContent = filename;
    
    const mimeType = fileExt === 'mp4' ? 'video/mp4' : fileExt === 'webm' ? 'video/webm' : 'video/ogg';
    
    const videoHtml = `
        <div style="padding: 20px; text-align: center; background: #000; height: 100%; 
                    display: flex; align-items: center; justify-content: center;">
            <video controls style="max-width: 100%; max-height: 100%;">
                <source src="${fileurl}" type="${mimeType}">
                Your browser does not support the video tag.
            </video>
        </div>
    `;
    
    iframe.srcdoc = videoHtml;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Close PPT player
function closePPTPlayer() {
    const modal = document.getElementById('pptPlayerModal');
    const iframe = document.getElementById('pptPlayerIframe');
    
    modal.classList.remove('active');
    iframe.src = '';
    document.body.style.overflow = '';
}

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePPTPlayer();
    }
});

// Close modal on background click
document.getElementById('pptPlayerModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closePPTPlayer();
    }
});
</script>

<?php
echo $OUTPUT->footer();
?>