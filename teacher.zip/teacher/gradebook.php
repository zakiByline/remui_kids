<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Simplified Gradebook for Teachers (theme_remui_kids)
 *
 * @package   theme_remui_kids
 * @copyright 2025
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/gradelib.php');
require_once($CFG->libdir . '/gradelib.php');

require_login();

$systemcontext = context_system::instance();
$PAGE->set_context($systemcontext);
$PAGE->set_url('/theme/remui_kids/teacher/gradebook.php');
$PAGE->set_pagelayout('admin');
$PAGE->set_title('Gradebook');
$PAGE->add_body_class('gradebook-page');
$PAGE->navbar->add('Gradebook');

// Security: teacher/admin only.
if (!has_capability('moodle/course:update', $systemcontext) && !has_capability('moodle/grade:viewall', $systemcontext) && !is_siteadmin()) {
    throw new moodle_exception('nopermissions', 'error', '', 'access gradebook');
}

// Teacher courses.
$teachercourses = enrol_get_my_courses('id, fullname, shortname', 'visible DESC, sortorder ASC');

// Params.
$courseid = optional_param('courseid', 0, PARAM_INT);

echo $OUTPUT->header();

// Clean, modern dashboard CSS for Gradebook - Redesigned to match beautiful UI
echo '<style>
#region-main,[role="main"]{background:transparent!important;box-shadow:none!important;border:0!important;padding:0!important;margin:0!important}
.teacher-dashboard-wrapper{min-height:100vh;background:#f8f9fa;position:relative}
.teacher-sidebar{width:280px;background:#fff;color:#333;position:fixed;left:0;top:0;height:100vh;overflow-y:auto;z-index:1000;border-right:1px solid #e8eaed;box-shadow:2px 0 10px rgba(0,0,0,0.1)}
.teacher-main-content{margin-left:280px;min-height:100vh;background:#f8f9fa}
.students-page-wrapper{padding:20px 40px 40px 40px;background:#f8f9fa; margin-top: -120px;}
.students-page-title{font-size:32px;font-weight:700;margin:0 0 8px 0;color:#1a1a1a;letter-spacing:-0.02em}
.students-page-subtitle{color:#5f6368;margin:0 0 24px;font-size:16px;font-weight:400;line-height:1.5}
.course-selector{margin:0 0 32px;display:flex;align-items:center;gap:12px}
.course-dropdown-label{font-size:14px;font-weight:600;color:#374151;margin:0}
.course-dropdown{position:relative;display:inline-block;min-width:320px}
.course-dropdown select{padding:12px 16px;border:1px solid #d1d5db;border-radius:8px;background:#fff;font-size:14px;color:#374151;width:100%;cursor:pointer;transition:all 0.2s;appearance:none;padding-right:40px}
.course-dropdown select:focus{outline:none;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,0.1)}
.course-dropdown select:hover{border-color:#9ca3af}
.course-dropdown select option{padding:8px 12px;background:#fff;color:#374151}
.course-dropdown select option:hover{background:#f3f4f6}
.course-dropdown select option:checked{background:#3b82f6;color:#fff}
.stats-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin:0 0 32px}
.stat-card{background:#fff;border:1px solid #e8eaed;border-radius:10px;padding:16px;display:flex;align-items:center;gap:12px;box-shadow:0 2px 6px rgba(0,0,0,0.06);transition:all 0.2s;min-width:0}
.stat-card:hover{transform:translateY(-1px);box-shadow:0 3px 8px rgba(0,0,0,0.1)}
.stat-card .stat-icon{width:40px;height:40px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:#f1f3f4;color:#5f6368;font-size:16px;border:1px solid #e8eaed;flex-shrink:0}
.stat-value{font-weight:600;font-size:20px;color:#1a1a1a;line-height:1.2}
.stat-label{color:#5f6368;font-size:11px;font-weight:500;text-transform:uppercase;letter-spacing:0.3px}
.gb-controls{display:flex;gap:16px;align-items:center;justify-content:space-between;margin:0 0 24px;flex-wrap:wrap}
.gb-search{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid #dadce0;border-radius:8px;padding:12px 16px;min-width:320px;flex:1;max-width:400px}
.gb-search input{border:0;outline:0;width:100%;font-size:14px;color:#3c4043;background:transparent}
.gb-search input::placeholder{color:#9aa0a6}
.gb-legend{display:flex;gap:12px;align-items:center;color:#5f6368;font-size:13px;flex-wrap:wrap}
.legend-pill{padding:6px 12px;border-radius:6px;font-size:12px;font-weight:500;display:inline-block;border:1px solid #e8eaed}
.gb-filters{display:flex;gap:8px}
.gb-filter{padding:10px 16px;border:1px solid #dadce0;background:#fff;border-radius:8px;cursor:pointer;color:#3c4043;font-size:14px;font-weight:500;transition:all 0.2s}
.gb-filter:hover{background:#f8f9fa;border-color:#1a73e8}
.gb-filter.active{background:#1a73e8;color:#fff;border-color:#1a73e8}
.gradebook-card{background:#fff;border:1px solid #e8eaed;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.08);overflow:hidden}
.grade-table{width:100%;border-collapse:separate;border-spacing:0;overflow:auto;display:block;background:#fff}
.grade-table thead th{position:sticky;top:0;background:#f8f9fa;border-bottom:2px solid #e8eaed;white-space:nowrap;padding:24px 20px;font-weight:700;color:#1a1a1a;z-index:2;font-size:13px;text-align:center;text-transform:uppercase;letter-spacing:0.5px;min-width:120px}
.grade-table thead th .modhead{display:flex;align-items:center;justify-content:center;gap:8px;font-weight:700;flex-direction:column}
.grade-table thead th .modhead i{font-size:18px;color:#5f6368;margin-bottom:4px}
.grade-table thead th .modhead span{font-size:11px;line-height:1.2;max-width:100px;word-wrap:break-word}
.grade-table tbody td{border-bottom:1px solid #f1f3f4;padding:20px 16px;vertical-align:middle;text-align:center;font-size:14px;min-width:120px}
.grade-table tbody tr:hover{background:#f8f9fa;transition:background-color 0.2s}
.grade-table tbody tr:nth-child(even){background:#fafbfc}
.cell-pill{display:inline-block;min-width:60px;text-align:center;padding:8px 12px;border-radius:6px;font-size:13px;font-weight:600;border:1px solid transparent}
.pill-missing{background:#f5f5f5;color:#666;border-color:#e0e0e0}
.pill-pending{background:#fff3cd;color:#856404;border-color:#ffeaa7}
.pill-attempted{background:#d1ecf1;color:#0c5460;border-color:#bee5eb}
.pill-graded{background:#d4edda;color:#155724;border-color:#c3e6cb}
.cell-pill:hover{transform:translateY(-1px);transition:transform 0.2s}
.grade-cell{display:flex;align-items:center;gap:12px;justify-content:center;padding:8px}
.grade-icon{width:24px;height:24px;border-radius:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:12px;font-weight:600;transition:all 0.2s;border:1px solid transparent}
.grade-icon:hover{transform:translateY(-1px)}
.grade-icon.plus{background:#e8eaed;color:#333;border-color:#dadce0;box-shadow:0 1px 3px rgba(0,0,0,0.1)}
.grade-icon.plus:hover{background:#dadce0;box-shadow:0 2px 6px rgba(0,0,0,0.15)}
.grade-icon.rubric{background:#e8f5e8;color:#137333;border-color:#c3e6cb;box-shadow:0 1px 3px rgba(0,0,0,0.1)}
.grade-icon.rubric:hover{background:#d4edda;box-shadow:0 2px 6px rgba(0,0,0,0.15)}
.student-cell{display:flex;align-items:center;gap:12px;min-width:220px}
.student-avatar{width:40px;height:40px;border-radius:8px;background:#e8eaed;display:flex;align-items:center;justify-content:center;font-weight:600;color:#3c4043;flex-shrink:0;font-size:14px}
.student-info{flex:1;min-width:0}
.student-name{font-weight:600;color:#1a1a1a;margin-bottom:2px;line-height:1.3;font-size:14px}
.student-email{font-size:12px;color:#5f6368;line-height:1.2}
.sticky-student{position:sticky;left:0;background:#fff;border-right:1px solid #e8eaed;z-index:1;min-width:250px}
.sticky-student-header{position:sticky;left:0;z-index:3;background:#f8f9fa;border-right:1px solid #e8eaed}
.table-scroll{border-radius:12px;overflow:auto}
.helper-note{color:#5f6368;font-size:13px;margin:16px 0 0;font-style:italic}
.actions a{color:#1a73e8;text-decoration:none;font-weight:500}
.actions a:hover{text-decoration:underline}
/* New percentage-based grade styling - Subtle and clean design */
.grade-percentage{display:inline-block;padding:8px 12px;border-radius:8px;font-size:13px;font-weight:600;text-align:center;min-width:60px;border:1px solid transparent;transition:all 0.2s;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.grade-excellent{background:#e8f5e8;color:#2d5a2d;border-color:#c3e6cb;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.grade-good{background:#fff8e1;color:#8a6914;border-color:#ffeaa7;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.grade-fair{background:#fce4ec;color:#8e2a4a;border-color:#f5c6cb;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.grade-poor{background:#ffebee;color:#c62828;border-color:#f1b0b7;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.grade-ungraded{background:#f5f5f5;color:#757575;border-color:#e0e0e0;box-shadow:0 1px 3px rgba(0,0,0,0.05)}
.grade-percentage:hover{transform:translateY(-1px);box-shadow:0 2px 6px rgba(0,0,0,0.12)}
/* Student percentage badge styling - Subtle and clean design */
.student-percentage{display:inline-block;padding:4px 8px;border-radius:12px;font-size:11px;font-weight:600;margin-left:8px;border:1px solid transparent;transition:all 0.2s;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.student-percentage.excellent{background:#e8f5e8;color:#2d5a2d;border-color:#c3e6cb;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.student-percentage.good{background:#fff8e1;color:#8a6914;border-color:#ffeaa7;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.student-percentage.fair{background:#fce4ec;color:#8e2a4a;border-color:#f5c6cb;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.student-percentage.poor{background:#ffebee;color:#c62828;border-color:#f1b0b7;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.student-percentage.ungraded{background:#f5f5f5;color:#757575;border-color:#e0e0e0;box-shadow:0 1px 3px rgba(0,0,0,0.05)}
.student-percentage:hover{transform:translateY(-1px);box-shadow:0 2px 6px rgba(0,0,0,0.12)}
/* SCORM Modal Styles */
.scorm-modal{position:fixed;z-index:10000;left:0;top:0;width:100%;height:100%;background-color:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center}
.scorm-modal-content{background:#fff;border-radius:12px;box-shadow:0 20px 25px -5px rgba(0,0,0,0.1),0 10px 10px -5px rgba(0,0,0,0.04);max-width:600px;width:90%;max-height:80vh;overflow:hidden}
.scorm-modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid #e5e7eb;background:#f9fafb}
.scorm-modal-header h3{margin:0;font-size:18px;font-weight:700;color:#111827}
.scorm-modal-close{font-size:24px;font-weight:bold;color:#6b7280;cursor:pointer;line-height:1}
.scorm-modal-close:hover{color:#374151}
.scorm-modal-body{padding:24px;max-height:60vh;overflow-y:auto}
.scorm-details-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.scorm-detail-item{display:flex;flex-direction:column;gap:4px}
.scorm-detail-item label{font-size:12px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.05em}
.scorm-detail-item span{font-size:14px;color:#111827;font-weight:500}
.status-badge,.completion-badge{padding:4px 8px;border-radius:6px;font-size:12px;font-weight:600;text-transform:capitalize;display:inline-block}
.status-badge.completed,.completion-badge.completed{background:#dcfce7;color:#065f46}
.status-badge.incomplete,.completion-badge.incomplete{background:#fef3c7;color:#92400e}
.status-badge.attempted,.completion-badge.attempted{background:#fed7aa;color:#c2410c}
.status-badge.browsed,.completion-badge.browsed{background:#e0e7ff;color:#3730a3}
.status-badge.not_attempted,.completion-badge.not_attempted{background:#fee2e2;color:#b91c1c}
.status-badge.passed{background:#dcfce7;color:#065f46}
.status-badge.failed{background:#fee2e2;color:#b91c1c}
.scorm-modal-footer{padding:16px 24px;border-top:1px solid #e5e7eb;background:#f9fafb;display:flex;justify-content:flex-end}
.scorm-modal-btn{background:#111827;color:#fff;border:0;padding:8px 16px;border-radius:6px;font-size:14px;font-weight:600;cursor:pointer}
.scorm-modal-btn:hover{background:#374151}
/* Grading Modal Styles */
.grading-modal{position:fixed;z-index:10000;left:0;top:0;width:100%;height:100%;background-color:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center}
.grading-modal-content{background:#fff;border-radius:12px;box-shadow:0 20px 25px -5px rgba(0,0,0,0.1),0 10px 10px -5px rgba(0,0,0,0.04);max-width:500px;width:90%;max-height:80vh;overflow:hidden}
.grading-modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid #e5e7eb;background:#f9fafb}
.grading-modal-header h3{margin:0;font-size:18px;font-weight:700;color:#111827}
.grading-modal-close{font-size:24px;font-weight:bold;color:#6b7280;cursor:pointer;line-height:1}
.grading-modal-close:hover{color:#374151}
.grading-modal-body{padding:24px;max-height:60vh;overflow-y:auto}
.grading-details-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px}
.grading-detail-item{display:flex;flex-direction:column;gap:4px}
.grading-detail-item label{font-size:12px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.05em}
.grading-detail-item span{font-size:14px;color:#111827;font-weight:500}
.grading-input-section{display:flex;flex-direction:column;gap:12px}
.grading-input-section label{font-size:14px;font-weight:600;color:#374151}
.grading-input-section input{width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px}
.grading-input-section input:focus{outline:none;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,0.1)}
.grading-actions{display:flex;gap:8px}
.grading-save-btn{background:#10b981;color:#fff;border:0;padding:8px 16px;border-radius:6px;font-size:14px;font-weight:600;cursor:pointer}
.grading-save-btn:hover{background:#059669}
.grading-clear-btn{background:#ef4444;color:#fff;border:0;padding:8px 16px;border-radius:6px;font-size:14px;font-weight:600;cursor:pointer}
.grading-clear-btn:hover{background:#dc2626}
.grading-modal-footer{padding:16px 24px;border-top:1px solid #e5e7eb;background:#f9fafb;display:flex;justify-content:flex-end}
.grading-modal-btn{background:#111827;color:#fff;border:0;padding:8px 16px;border-radius:6px;font-size:14px;font-weight:600;cursor:pointer}
.grading-modal-btn:hover{background:#374151}
@media(max-width: 1400px){.stats-grid{grid-template-columns:repeat(6,1fr);gap:8px}.stat-card{padding:12px}.stat-card .stat-icon{width:16px;height:36px;font-size:14px}.stat-value{font-size:18px}.stat-label{font-size:10px}}
@media(max-width: 1200px){.stats-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width: 768px){.stats-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width: 1024px){.teacher-main-content{margin-left:0}.teacher-sidebar{transform:translateX(-100%)}.teacher-sidebar.sidebar-open{transform:translateX(0)}.table-scroll{border-left:1px solid #e5e7eb;border-right:1px solid #e5e7eb}.scorm-details-grid{grid-template-columns:1fr}.grading-details-grid{grid-template-columns:1fr}}
</style>';

// Sidebar (reuse links pattern from other teacher pages) - minimal subset.
echo '<div class="teacher-dashboard-wrapper">';
echo '<button class="sidebar-toggle" onclick="toggleTeacherSidebar()">';
echo '    <i class="fa fa-bars"></i>';
echo '</button>';

// Teacher Sidebar Navigation
echo '<div class="teacher-sidebar">';
echo '  <div class="sidebar-content">';
// Dashboard section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">DASHBOARD</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/my/" class="sidebar-link"><i class="fa fa-th-large sidebar-icon"></i><span class="sidebar-text">Teacher Dashboard</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/teacher_courses.php" class="sidebar-link"><i class="fa fa-book sidebar-icon"></i><span class="sidebar-text">My Courses</span></a></li>';
echo '    </div>';
// Students section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">STUDENTS</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/students.php" class="sidebar-link"><i class="fa fa-users sidebar-icon"></i><span class="sidebar-text">All Students</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/enroll_students.php" class="sidebar-link"><i class="fa fa-user-plus sidebar-icon"></i><span class="sidebar-text">Enroll Students</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Reports</span></a></li>';
echo '      </ul>';
echo '    </div>';
// Assessments section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">ASSESSMENTS</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/assignments.php" class="sidebar-link"><i class="fa fa-tasks sidebar-icon"></i><span class="sidebar-text">Assignments</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/quizzes.php" class="sidebar-link"><i class="fa fa-question-circle sidebar-icon"></i><span class="sidebar-text">Quizzes</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/competencies.php" class="sidebar-link"><i class="fa fa-sitemap sidebar-icon"></i><span class="sidebar-text">Competencies</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/rubrics.php" class="sidebar-link"><i class="fa fa-list-alt sidebar-icon"></i><span class="sidebar-text">Rubrics</span></a></li>';
echo '        <li class="sidebar-item active"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/gradebook.php" class="sidebar-link"><i class="fa fa-star sidebar-icon"></i><span class="sidebar-text">Gradebook</span></a></li>';
echo '      </ul>';
echo '    </div>';
// Reports section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">REPORTS</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/log/index.php" class="sidebar-link"><i class="fa fa-chart-bar sidebar-icon"></i><span class="sidebar-text">Activity Logs</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/outline/index.php" class="sidebar-link"><i class="fa fa-file-alt sidebar-icon"></i><span class="sidebar-text">Course Reports</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Tracking</span></a></li>';
echo '      </ul>';
echo '    </div>';

echo '  </div>';
echo '</div>'; // end teacher-sidebar

// Main content.
echo '<div class="teacher-main-content">';
echo '<div class="students-page-wrapper">';
echo '<div class="students-page-header">';
echo '<h1 class="students-page-title">Gradebook</h1>';
echo '<p class="students-page-subtitle">See and update grades across all activities</p>';
echo '</div>';

// Course selector.
echo '<div class="course-selector">';
echo '<label for="gbCourseSelect" class="course-dropdown-label">Select Course</label>';
echo '<div class="course-dropdown">';
echo '<select id="gbCourseSelect" onchange="window.location.href=this.value">';
echo '<option value="">Choose a course...</option>';
foreach ($teachercourses as $course) {
    $selected = ($courseid == $course->id) ? 'selected' : '';
    $url = new moodle_url('/theme/remui_kids/teacher/gradebook.php', array('courseid' => $course->id));
    echo '<option value="' . $url->out() . '" ' . $selected . '>' . format_string($course->shortname) . ' - ' . format_string($course->fullname) . '</option>';
}
echo '</select>';
echo '</div>';
echo '</div>';

if ($courseid) {
    try {
        error_log("Gradebook: Loading course with ID: " . $courseid);
        
        $course = get_course($courseid);
        $coursecontext = context_course::instance($course->id);
        error_log("Gradebook: Course loaded - " . $course->fullname);

        require_capability('moodle/grade:viewall', $coursecontext);

        // Enrolled students (exclude teachers/managers).
        error_log("Gradebook: Fetching enrolled students for course " . $course->id);
        $students = $DB->get_records_sql(
            "SELECT DISTINCT u.id, u.firstname, u.lastname, u.email
             FROM {user} u
             JOIN {user_enrolments} ue ON ue.userid = u.id
             JOIN {enrol} e ON e.id = ue.enrolid AND e.courseid = ?
             WHERE u.deleted = 0
               AND u.id NOT IN (
                 SELECT ra.userid FROM {role_assignments} ra
                 JOIN {context} ctx ON ctx.id = ra.contextid AND ctx.contextlevel = ?
                 JOIN {role} r ON r.id = ra.roleid
                 WHERE ctx.instanceid = ? AND r.shortname IN ('admin','manager','editingteacher','teacher')
               )
             ORDER BY u.lastname, u.firstname",
            array($course->id, CONTEXT_COURSE, $course->id)
        );
        error_log("Gradebook: Found " . count($students) . " students");

        // Grade items: include mod/manual; omit course/category totals to keep UI clean.
        error_log("Gradebook: Fetching grade items for course " . $course->id);
        $gradeitems = $DB->get_records_select('grade_items', 'courseid = ? AND itemtype IN (\'mod\', \'manual\')', array($course->id), 'sortorder ASC');
        error_log("Gradebook: Found " . count($gradeitems) . " grade items");
        
        // Check grading methods for each grade item to detect rubric usage
        // Use the same logic as rubric_grading.php and rubrics.php
        $gradingMethods = array();
        
        // Get all rubrics for this course using the existing function
        $rubrics = theme_remui_kids_get_teacher_rubrics($USER->id, $course->id);
        $rubricAssignmentIds = array();
        
        // Extract assignment IDs that use rubrics
        foreach ($rubrics as $rubric) {
            $rubricAssignmentIds[] = $rubric['assignment_id'];
        }
        
        error_log("Gradebook: Found " . count($rubrics) . " rubrics for course " . $course->id);
        error_log("Gradebook: Rubric assignment IDs: " . implode(', ', $rubricAssignmentIds));
        
        // Check each grade item
        foreach ($gradeitems as $gi) {
            error_log("Gradebook: Checking grade item - ID: " . $gi->id . ", Module: " . $gi->itemmodule . ", Instance: " . $gi->iteminstance . ", Name: " . $gi->itemname);
            
            if ($gi->itemmodule === 'assign' && in_array($gi->iteminstance, $rubricAssignmentIds)) {
                $gradingMethods[$gi->id] = 'rubric';
                error_log("Gradebook: Assignment " . $gi->itemname . " uses rubric grading (ID: " . $gi->iteminstance . ")");
            } else {
                $gradingMethods[$gi->id] = 'standard';
                error_log("Gradebook: Grade item " . $gi->itemname . " uses standard grading");
            }
        }

    // Preload grades for all students and items.
    $itemids = array_map(function($gi){return $gi->id;}, $gradeitems);
    $gradesbykey = array();
    if (!empty($itemids) && !empty($students)) {
        list($insql, $inparams) = $DB->get_in_or_equal($itemids, SQL_PARAMS_QM);
        $userids = array_map(function($u){return $u->id;}, $students);
        list($uinsql, $uinparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_QM);
        
        
        // Use Moodle's exact approach from grade_report_grader
        $query = "SELECT g.*
                  FROM {grade_items} gi,
                       {grade_grades} g
                 WHERE g.itemid = gi.id AND gi.courseid = ?";
        error_log("Gradebook: Using Moodle's query: " . $query);
        error_log("Gradebook: Course ID: " . $course->id);
        
        $records = $DB->get_records_sql($query, array($course->id));
        
        // Store all grades (SQL already filters out null/empty)
        error_log("Gradebook: Found " . count($records) . " non-null grade records");
        
        foreach ($records as $rec) {
            // Only store non-null, non-empty grades (like Moodle does)
            if ($rec->finalgrade !== null && $rec->finalgrade !== '') {
                $gradesbykey[$rec->userid . ':' . $rec->itemid] = $rec->finalgrade;
                error_log("Gradebook: Stored grade - User: " . $rec->userid . ", Item: " . $rec->itemid . ", Grade: " . $rec->finalgrade);
            }
        }
        error_log("Gradebook: Total grades stored: " . count($gradesbykey));
    }

    // Preload SCORM tracking data for SCORM activities
    $scormtracking = array();
    $scorm_by_user_scorm = array();
    $gradeitem_to_scormid = array();
    
    try {
        error_log("Gradebook: Starting SCORM tracking data collection");
        
        $scormitems = array_filter($gradeitems, function($gi) { return $gi->itemmodule === 'scorm'; });
        error_log("Gradebook: Found " . count($scormitems) . " SCORM items");
        
        if (!empty($scormitems) && !empty($students)) {
            $scormitemids = array_map(function($gi){return $gi->id;}, $scormitems);
            error_log("Gradebook: SCORM item IDs: " . implode(',', $scormitemids));
            
            list($insql, $inparams) = $DB->get_in_or_equal($scormitemids, SQL_PARAMS_QM);
            error_log("Gradebook: SCORM instances query - SQL: " . $insql . ", Params: " . implode(',', $inparams));
            $scorminstances = $DB->get_records_sql(
                "SELECT gi.id as gradeitemid, s.id as scormid, s.name as scormname
                 FROM {grade_items} gi
                 JOIN {scorm} s ON s.id = gi.iteminstance
                 WHERE gi.id $insql
                 AND gi.itemmodule = 'scorm'",
                $inparams
            );
            error_log("Gradebook: Found " . count($scorminstances) . " SCORM instances");
            foreach ($scorminstances as $inst) {
                error_log("Gradebook: SCORM instance - GradeItemID: " . $inst->gradeitemid . ", SCORMID: " . $inst->scormid . ", Name: " . $inst->scormname);
            }
            
            // Build item->scorm map and a second index (user:scormid) for robust lookups
            foreach ($scorminstances as $instance) {
                $gradeitem_to_scormid[$instance->gradeitemid] = $instance->scormid;
                error_log("Gradebook: Processing SCORM instance - ID: " . $instance->scormid . ", Name: " . $instance->scormname);
                
                $userids = array_map(function($u){return $u->id;}, $students);
                list($uinsql, $uinparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_QM);
                
                $trackingquery = "SELECT sa.userid, sv.value, se.element, sv.timemodified
                     FROM {scorm_attempt} sa
                     JOIN {scorm_scoes_value} sv ON sv.attemptid = sa.id
                     JOIN {scorm_element} se ON se.id = sv.elementid
                     WHERE sa.scormid = ? AND sa.userid $uinsql
                     AND se.element IN ('cmi.core.lesson_status', 'cmi.core.completion_status', 'cmi.core.total_time', 'cmi.core.session_time', 'cmi.core.exit', 'cmi.core.entry', 'cmi.core.score.raw')
                     ORDER BY sa.userid, sv.timemodified DESC";
                $trackingparams = array_merge(array($instance->scormid), $uinparams);
                error_log("Gradebook: Tracking query for SCORM " . $instance->scormid . " - Params: " . implode(',', $trackingparams));
                $trackingdata = $DB->get_records_sql($trackingquery, $trackingparams);
                error_log("Gradebook: Found " . count($trackingdata) . " tracking records for SCORM " . $instance->scormid);
                
                // Also get ALL tracking data for this SCORM to see what we're missing
                $allTrackingQuery = "SELECT sa.userid, sv.value, se.element, sv.timemodified
                     FROM {scorm_attempt} sa
                     JOIN {scorm_scoes_value} sv ON sv.attemptid = sa.id
                     JOIN {scorm_element} se ON se.id = sv.elementid
                     WHERE sa.scormid = ? AND sa.userid $uinsql
                     ORDER BY sa.userid, sv.timemodified DESC";
                $allTrackingData = $DB->get_records_sql($allTrackingQuery, array_merge(array($instance->scormid), $uinparams));
                error_log("Gradebook: ALL tracking data for SCORM " . $instance->scormid . " (" . count($allTrackingData) . " records):");
                foreach ($allTrackingData as $allTrack) {
                    error_log("Gradebook: ALL - User: " . $allTrack->userid . ", Element: " . $allTrack->element . ", Value: " . $allTrack->value);
                }
                
                // Debug: Log all tracking records
                foreach ($trackingdata as $debugTrack) {
                    error_log("Gradebook: Raw track - User: " . $debugTrack->userid . ", Element: " . $debugTrack->element . ", Value: " . $debugTrack->value . ", TimeModified: " . $debugTrack->timemodified);
                }
                
                // Debug: Check if we're getting the expected elements
                $elementsFound = array();
                foreach ($trackingdata as $debugTrack) {
                    $elementsFound[$debugTrack->element] = true;
                }
                error_log("Gradebook: Elements found in query: " . implode(', ', array_keys($elementsFound)));
                
                // Group tracking data by user first, then process all elements for each user
                $userTrackingData = array();
                foreach ($trackingdata as $track) {
                    $userid = $track->userid;
                    if (!isset($userTrackingData[$userid])) {
                        $userTrackingData[$userid] = array();
                    }
                    $userTrackingData[$userid][] = $track;
                }
                
                // Process each user's tracking data
                foreach ($userTrackingData as $userid => $userTracks) {
                    $key = $userid . ':' . $instance->gradeitemid;
                    
                    // Initialize user data
                    $scormtracking[$key] = array(
                        'scormname' => $instance->scormname,
                        'status' => 'not_attempted',
                        'completion' => 'not_attempted', 
                        'score' => null,
                        'total_time' => '00:00:00',
                        'session_time' => '00:00:00',
                        'entry' => 'ab-initio',
                        'exit' => null,
                        'last_accessed' => null,
                        'has_attempted' => false
                    );
                    
                    // Mark as attempted since we have tracking data
                    $scormtracking[$key]['has_attempted'] = true;
                    
                    // Also index by user + scormid so we can resolve mismatches
                    $altkey = $userid . ':' . $instance->scormid;
                    $scorm_by_user_scorm[$altkey] = &$scormtracking[$key];
                    
                    // Process all tracking records for this user
                    foreach ($userTracks as $track) {
                        error_log("Gradebook: Processing track for user $userid - Element: " . $track->element . ", Value: " . $track->value . ", Time: " . $track->timemodified);
                        
                        switch ($track->element) {
                            case 'cmi.core.lesson_status':
                                $scormtracking[$key]['status'] = $track->value;
                                error_log("Gradebook: Set status to: " . $track->value);
                                // Also set completion based on lesson_status for consistency
                                if ($track->value === 'completed' || $track->value === 'passed') {
                                    $scormtracking[$key]['completion'] = 'completed';
                                } else if ($track->value === 'incomplete' || $track->value === 'failed') {
                                    $scormtracking[$key]['completion'] = 'incomplete';
                                } else if ($track->value === 'browsed') {
                                    $scormtracking[$key]['completion'] = 'browsed';
                                }
                                break;
                            case 'cmi.core.completion_status':
                                $scormtracking[$key]['completion'] = $track->value;
                                error_log("Gradebook: Set completion to: " . $track->value);
                                break;
                            case 'cmi.core.total_time':
                                $scormtracking[$key]['total_time'] = $track->value;
                                error_log("Gradebook: Set total_time to: " . $track->value);
                                break;
                            case 'cmi.core.session_time':
                                $scormtracking[$key]['session_time'] = $track->value;
                                error_log("Gradebook: Set session_time to: " . $track->value);
                                break;
                            case 'cmi.core.exit':
                                $scormtracking[$key]['exit'] = $track->value;
                                error_log("Gradebook: Set exit to: " . $track->value);
                                break;
                            case 'cmi.core.entry':
                                $scormtracking[$key]['entry'] = $track->value;
                                error_log("Gradebook: Set entry to: " . $track->value);
                                break;
                            case 'cmi.core.score.raw':
                                $scormtracking[$key]['score'] = $track->value;
                                error_log("Gradebook: Set score to: " . $track->value);
                                break;
                            default:
                                error_log("Gradebook: Unknown element: " . $track->element);
                                break;
                        }
                        $scormtracking[$key]['last_accessed'] = max($scormtracking[$key]['last_accessed'] ?? 0, $track->timemodified);
                    }
                    
                    error_log("Gradebook: Final data for user $userid: " . json_encode($scormtracking[$key]));
                }
            }
        }
        error_log("Gradebook: SCORM tracking data collection completed. Total records: " . count($scormtracking));
        error_log("Gradebook: SCORM tracking (by scormid) records: " . count($scorm_by_user_scorm));
        
    } catch (Exception $e) {
        error_log("Gradebook: SCORM tracking error - " . $e->getMessage());
        error_log("Gradebook: SCORM tracking error trace - " . $e->getTraceAsString());
        // Continue without SCORM tracking if there's an error
        $scormtracking = array();
    }

    // Enhanced dashboard statistics
    $studentcount = count($students);
    $columncount = count($gradeitems);
    $gradedcells = 0; 
    $attemptedcells = 0;
    $completedactivities = 0;
    $gradesum = 0;
    $gradecount = 0;
    $totalcells = max(1, $studentcount * max(1, $columncount));
    
    foreach ($students as $s) {
        foreach ($gradeitems as $gi) {
            $final = null;
            if (isset($gradesbykey[$s->id . ':' . $gi->id])) {
                $final = $gradesbykey[$s->id . ':' . $gi->id];
                $gradedcells++;
                if ($final !== null && $final !== '') {
                    $gradesum += $final;
                    $gradecount++;
                }
            }
            
            // Check for attempts and completions
            $hasAttempted = false;
            if ($gi->itemmodule === 'scorm' && isset($scormtracking[$s->id][$gi->id])) {
                $hasAttempted = $scormtracking[$s->id][$gi->id]['has_attempted'];
                if ($scormtracking[$s->id][$gi->id]['completion'] === 'completed') {
                    $completedactivities++;
                }
            } else if ($gi->itemmodule === 'quiz') {
                $attempts = $DB->get_records('quiz_attempts', array('quiz' => $gi->iteminstance, 'userid' => $s->id));
                $hasAttempted = !empty($attempts);
            } else if ($gi->itemmodule === 'assign') {
                $submissions = $DB->get_records('assign_submission', array('assignment' => $gi->iteminstance, 'userid' => $s->id));
                $hasAttempted = !empty($submissions);
            }
            
            if ($hasAttempted) {
                $attemptedcells++;
            }
        }
    }
    
    $gradedpct = round(($gradedcells / $totalcells) * 100);
    $attemptedpct = round(($attemptedcells / $totalcells) * 100);
    $avgGrade = $gradecount > 0 ? round($gradesum / $gradecount, 1) : 0;
    $completionRate = $totalcells > 0 ? round(($completedactivities / $totalcells) * 100) : 0;

    echo '<div class="stats-grid">';
    echo '  <div class="stat-card"><div class="stat-icon"><i class="fa fa-users"></i></div><div><div class="stat-value">' . $studentcount . '</div><div class="stat-label">Students</div></div></div>';
    echo '  <div class="stat-card"><div class="stat-icon"><i class="fa fa-layer-group"></i></div><div><div class="stat-value">' . $columncount . '</div><div class="stat-label">Activities</div></div></div>';
    echo '  <div class="stat-card"><div class="stat-icon"><i class="fa fa-chart-line"></i></div><div><div class="stat-value">' . $avgGrade . '</div><div class="stat-label">Avg Grade</div></div></div>';
    echo '  <div class="stat-card"><div class="stat-icon"><i class="fa fa-check-circle"></i></div><div><div class="stat-value">' . $gradedpct . '%</div><div class="stat-label">Graded</div></div></div>';
    echo '</div>';

    // Controls: search, legend, quick filters.
    echo '<div class="gb-controls">';
    echo '  <div class="gb-search"><i class="fa fa-search"></i><input type="text" id="gbSearch" placeholder="Search students or emails..."></div>';

    echo '  <div class="gb-filters">'
        . '<button class="gb-filter active" data-filter="all">All</button>'
        . '<button class="gb-filter" data-filter="graded">Has graded</button>'
        . '<button class="gb-filter" data-filter="attempted">Has attempted</button>'
        . '<button class="gb-filter" data-filter="missing">Has missing</button>'
        . '</div>';
    echo '</div>';
    
    // Table.
    echo '<div class="table-scroll gradebook-card">';
    echo '<table class="grade-table">';
    echo '<thead><tr>';
    echo '<th class="sticky-student-header">Student</th>';
    echo '<th>Total</th>';
    foreach ($gradeitems as $gi) {
        $coltitle = format_string($gi->itemname ?: $gi->itemtype);
        $mod = isset($gi->itemmodule) ? $gi->itemmodule : '';
        $icon = 'fa-star';
        if ($mod === 'quiz') { $icon = 'fa-question-circle'; }
        else if ($mod === 'assign') { $icon = 'fa-tasks'; }
        else if ($mod === 'scorm') { $icon = 'fa-cube'; }
        else if ($mod === 'h5pactivity') { $icon = 'fa-shapes'; }
        else if ($mod === 'workshop') { $icon = 'fa-people-arrows'; }
        echo '<th title="' . s($coltitle) . '"><span class="modhead"><i class="fa ' . $icon . '"></i><span>' . s(core_text::substr($coltitle, 0, 28)) . '</span></span></th>';
    }
    echo '<th class="actions">Actions</th>';
    echo '</tr></thead><tbody>';

    foreach ($students as $s) {
        $initials = strtoupper(substr($s->firstname, 0, 1) . substr($s->lastname, 0, 1));
        echo '<tr>';
        echo '<td class="sticky-student">';
        echo '<div class="student-cell">';
        echo '<div class="student-avatar">' . $initials . '</div>';
        echo '<div class="student-info">';
        echo '<div class="student-name">' . fullname($s) . '</div>';
        echo '<div class="student-email">' . s($s->email) . '</div>';
        echo '</div>';
        echo '</div>';
        echo '</td>';

        // Calculate total first (only calculate, don't render yet)
        $usertotal = 0; $usertotalmax = 0;
        foreach ($gradeitems as $gi) {
            $key = $s->id . ':' . $gi->id;
            $final = isset($gradesbykey[$key]) ? (float)$gradesbykey[$key] : null;
            $max = (float)$gi->grademax;
            
            if ($final !== null && $final !== '' && $final > 0) {
                $usertotal += $final; 
                $usertotalmax += $max;
            }
        }

        $totaldisplay = ($usertotalmax > 0) ? format_float(($usertotal / $usertotalmax) * 100, 1) . '%' : '-';
        $userurl = new moodle_url('/grade/report/user/index.php', array('id' => $course->id, 'userid' => $s->id));
        
        // Calculate student percentage for badge styling
        $studentPercentage = ($usertotalmax > 0) ? ($usertotal / $usertotalmax) * 100 : 0;
        $studentBadgeClass = 'ungraded';
        if ($studentPercentage >= 75) {
            $studentBadgeClass = 'excellent';
        } else if ($studentPercentage >= 50) {
            $studentBadgeClass = 'good';
        } else if ($studentPercentage >= 30) {
            $studentBadgeClass = 'fair';
        } else if ($studentPercentage > 0) {
            $studentBadgeClass = 'poor';
        }
        
        // Add percentage badge to student display
        $percentageBadge = '';
        if ($studentPercentage > 0) {
            $percentageBadge = '<span class="student-percentage ' . $studentBadgeClass . '">' . round($studentPercentage) . '%</span>';
        }
        
        // Display total column (second column position)
        echo '<td><strong>' . $totaldisplay . '</strong>' . $percentageBadge . '</td>';
        
        // Now display all grade items
        foreach ($gradeitems as $gi) {
            $key = $s->id . ':' . $gi->id;
            $final = isset($gradesbykey[$key]) ? (float)$gradesbykey[$key] : null;
            $max = (float)$gi->grademax;
            $display = '-';
            $class = 'grade-ungraded';
            
            if ($final !== null && $final !== '' && $final > 0) {
                $percentage = ($final / $max) * 100;
                $display = format_float($final, 2);
                
                if ($percentage >= 75) {
                    $class = 'grade-excellent';
                } else if ($percentage >= 50) {
                    $class = 'grade-good';
                } else if ($percentage >= 30) {
                    $class = 'grade-fair';
                } else {
                    $class = 'grade-poor';
                }
            }
            
            // Build cell content
            $cellContent = '';
            
            if ($gi->itemmodule === 'scorm') {
                $scormkey = $s->id . ':' . $gi->id;
                $scormdata = isset($scormtracking[$scormkey]) ? $scormtracking[$scormkey] : null;
                
                // For SCORM: Show actual grade with percentage-based colors, otherwise show status
                if ($final !== null && $final !== '' && $final > 0) {
                    // Show actual grade with percentage-based color coding
                    $percentage = ($final / $max) * 100;
                    $display = format_float($final, 1);
                    
                    if ($percentage >= 75) {
                        $class = 'grade-excellent';
                    } else if ($percentage >= 50) {
                        $class = 'grade-good';
                    } else if ($percentage >= 30) {
                        $class = 'grade-fair';
                    } else {
                        $class = 'grade-poor';
                    }
                    
                    $cellContent = '<span class="grade-percentage ' . $class . '" onclick="showScormDetails(' . $s->id . ', ' . $gi->id . ', \'' . addslashes($s->firstname . ' ' . $s->lastname) . '\', \'' . addslashes($gi->itemname) . '\')" style="cursor: pointer;">' . $display . '</span>';
                } else {
                    // Show status icons when not graded or grade is 0
                    if ($scormdata) {
                        $status = $scormdata['status'] ?? 'not_attempted';
                        $completion = $scormdata['completion'] ?? 'not_attempted';
                        $hasAttempted = $scormdata['has_attempted'] ?? false;
                        
                        $primaryStatus = ($completion !== 'not_attempted') ? $completion : $status;
                        
                        if ($primaryStatus === 'completed' || $primaryStatus === 'passed') {
                            $display = '✓';
                            $class = 'grade-excellent';
                        } else if ($primaryStatus === 'incomplete' || $primaryStatus === 'failed') {
                            $display = '◐';
                            $class = 'grade-fair';
                        } else if ($primaryStatus === 'browsed') {
                            $display = '👁';
                            $class = 'grade-good';
                        } else if ($hasAttempted) {
                            $display = '◐';
                            $class = 'grade-fair';
                        } else {
                            $display = '-';
                            $class = 'grade-ungraded';
                        }
                    } else {
                        $display = '-';
                        $class = 'grade-ungraded';
                    }
                    
                    $cellContent = '<span class="grade-percentage ' . $class . '" onclick="showScormDetails(' . $s->id . ', ' . $gi->id . ', \'' . addslashes($s->firstname . ' ' . $s->lastname) . '\', \'' . addslashes($gi->itemname) . '\')" style="cursor: pointer;">' . $display . '</span>';
                }
            } else {
                // Non-SCORM grade display with percentage-based styling
                $cellContent = '<span class="grade-percentage ' . $class . '">' . $display . '</span>';
            }
            
            // Add grading icon for all activities - check grading method
            $gradingMethod = isset($gradingMethods[$gi->id]) ? $gradingMethods[$gi->id] : 'standard';
            
            if ($gradingMethod === 'rubric') {
                $rubricUrl = $CFG->wwwroot . '/theme/remui_kids/teacher/grade_student.php?assignmentid=' . $gi->iteminstance . '&courseid=' . $course->id . '&studentid=' . $s->id;
                $gradingIcon = '<div class="grade-icon rubric" onclick="window.open(\'' . $rubricUrl . '\', \'_blank\')" title="Grade with rubric">R</div>';
            } else {
                $gradingIcon = '<div class="grade-icon plus" onclick="showGradingModal(' . $s->id . ', ' . $gi->id . ', \'' . addslashes($s->firstname . ' ' . $s->lastname) . '\', \'' . addslashes($gi->itemname) . '\', ' . $gi->grademax . ', \'' . $final . '\')" title="Grade this activity">+</div>';
            }
            
            echo '<td><div class="grade-cell">' . $cellContent . $gradingIcon . '</div></td>';
        }
        
        echo '<td class="actions"><a href="' . $userurl->out() . '" target="_blank">User report</a></td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
        echo '<p class="helper-note">Tip: Use the search and filters above to quickly find students who need attention. Totals shown are simple percent across visible items.</p>';
        
    } catch (Exception $e) {
        error_log("Gradebook: Main error - " . $e->getMessage());
        error_log("Gradebook: Main error trace - " . $e->getTraceAsString());
        echo '<div class="alert alert-danger">Error loading gradebook: ' . $e->getMessage() . '</div>';
    }
}

echo '</div>'; // students-page-wrapper
echo '</div>'; // teacher-main-content
echo '</div>'; // teacher-dashboard-wrapper

// Manual Grading Modal
echo '<div id="gradingModal" class="grading-modal" style="display: none;">';
echo '  <div class="grading-modal-content">';
echo '    <div class="grading-modal-header">';
echo '      <h3 id="gradingModalTitle">Manual Grade Entry</h3>';
echo '      <span class="grading-modal-close" onclick="closeGradingModal()">&times;</span>';
echo '    </div>';
echo '    <div class="grading-modal-body">';
echo '      <div class="grading-details-grid">';
echo '        <div class="grading-detail-item">';
echo '          <label>Student:</label>';
echo '          <span id="gradingStudentName">-</span>';
echo '        </div>';
echo '        <div class="grading-detail-item">';
echo '          <label>Activity:</label>';
echo '          <span id="gradingActivityName">-</span>';
echo '        </div>';
echo '        <div class="grading-detail-item">';
echo '          <label>Max Points:</label>';
echo '          <span id="gradingMaxPoints">-</span>';
echo '        </div>';
echo '        <div class="grading-detail-item">';
echo '          <label>Current Grade:</label>';
echo '          <span id="gradingCurrentGrade">-</span>';
echo '        </div>';
echo '      </div>';
echo '      <div class="grading-input-section">';
echo '        <label for="gradingInput">Enter Grade:</label>';
echo '        <input type="number" id="gradingInput" step="0.01" min="0" placeholder="Enter grade...">';
echo '        <div class="grading-actions">';
echo '          <button onclick="saveManualGrade()" class="grading-save-btn">Save Grade</button>';
echo '          <button onclick="clearManualGrade()" class="grading-clear-btn">Clear Grade</button>';
echo '        </div>';
echo '      </div>';
echo '    </div>';
echo '    <div class="grading-modal-footer">';
echo '      <button onclick="closeGradingModal()" class="grading-modal-btn">Close</button>';
echo '    </div>';
echo '  </div>';
echo '</div>';

// SCORM Details Modal
echo '<div id="scormModal" class="scorm-modal" style="display: none;">';
echo '  <div class="scorm-modal-content">';
echo '    <div class="scorm-modal-header">';
echo '      <h3 id="scormModalTitle">SCORM Activity Details</h3>';
echo '      <span class="scorm-modal-close" onclick="closeScormModal()">&times;</span>';
echo '    </div>';
echo '    <div class="scorm-modal-body">';
echo '      <div class="scorm-details-grid">';
echo '        <div class="scorm-detail-item">';
echo '          <label>Student:</label>';
echo '          <span id="scormStudentName">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Activity:</label>';
echo '          <span id="scormActivityName">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Status:</label>';
echo '          <span id="scormStatus" class="status-badge">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Completion:</label>';
echo '          <span id="scormCompletion" class="completion-badge">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Score:</label>';
echo '          <span id="scormScore">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Total Time:</label>';
echo '          <span id="scormTotalTime">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Last Session:</label>';
echo '          <span id="scormSessionTime">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Entry Type:</label>';
echo '          <span id="scormEntry">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Exit Type:</label>';
echo '          <span id="scormExit">-</span>';
echo '        </div>';
echo '        <div class="scorm-detail-item">';
echo '          <label>Last Accessed:</label>';
echo '          <span id="scormLastAccessed">-</span>';
echo '        </div>';
echo '      </div>';
echo '    </div>';
echo '    <div class="scorm-modal-footer">';
echo '      <button onclick="closeScormModal()" class="scorm-modal-btn">Close</button>';
echo '    </div>';
echo '  </div>';
echo '</div>';

// Add SCORM tracking data to JavaScript
echo '<script>';
echo 'var scormTrackingData = ' . json_encode($scormtracking) . ';';
echo 'var scormByUserScorm = ' . json_encode($scorm_by_user_scorm) . ';';
echo 'var gradeitemToScorm = ' . json_encode($gradeitem_to_scormid) . ';';
echo 'console.log("SCORM Tracking Data:", scormTrackingData);';
echo 'console.log("SCORM By User Scorm:", scormByUserScorm);';
echo '</script>';

// Sidebar toggle and client-side search/filter behavior.
echo <<<'JS'
<script>
function toggleTeacherSidebar(){const s=document.querySelector(".teacher-sidebar");if(s){s.classList.toggle("sidebar-open");}}

// Manual Grading Functions
function showGradingModal(userId, itemId, studentName, activityName, maxPoints, currentGrade) {
  // Update modal content
  document.getElementById('gradingStudentName').textContent = studentName;
  document.getElementById('gradingActivityName').textContent = activityName;
  document.getElementById('gradingMaxPoints').textContent = maxPoints;
  document.getElementById('gradingCurrentGrade').textContent = currentGrade || 'No grade';
  
  // Set current grade as placeholder in input
  const input = document.getElementById('gradingInput');
  input.value = currentGrade || '';
  input.max = maxPoints;
  input.placeholder = 'Enter grade (max: ' + maxPoints + ')';
  
  // Store data for saving
  window.currentGradingData = {
    userId: userId,
    itemId: itemId,
    studentName: studentName,
    activityName: activityName,
    maxPoints: maxPoints
  };
  
  // Show modal
  document.getElementById('gradingModal').style.display = 'flex';
}

function closeGradingModal() {
  document.getElementById('gradingModal').style.display = 'none';
  window.currentGradingData = null;
}

function saveManualGrade() {
  const input = document.getElementById('gradingInput');
  const grade = parseFloat(input.value);
  const maxPoints = window.currentGradingData.maxPoints;
  
  if (isNaN(grade) || grade < 0) {
    alert('Please enter a valid grade (0 or higher)');
    return;
  }
  
  if (grade > maxPoints) {
    alert('Grade cannot exceed maximum points (' + maxPoints + ')');
    return;
  }
  
  // Send AJAX request to save grade
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'save_manual_grade.php', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        try {
          const response = JSON.parse(xhr.responseText);
          if (response.success) {
            alert('Grade saved successfully!');
            closeGradingModal();
            location.reload(); // Refresh to show updated grade
          } else {
            alert('Error saving grade: ' + response.message);
          }
        } catch (e) {
          alert('Error processing response');
        }
      } else {
        alert('Error saving grade. Please try again.');
      }
    }
  };
  
  const data = 'userid=' + window.currentGradingData.userId + 
               '&itemid=' + window.currentGradingData.itemId + 
               '&grade=' + grade;
  xhr.send(data);
}

function clearManualGrade() {
  if (confirm('Are you sure you want to clear this grade?')) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_manual_grade.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          try {
            const response = JSON.parse(xhr.responseText);
            if (response.success) {
              alert('Grade cleared successfully!');
              closeGradingModal();
              location.reload();
            } else {
              alert('Error clearing grade: ' + response.message);
            }
          } catch (e) {
            alert('Error processing response');
          }
        } else {
          alert('Error clearing grade. Please try again.');
        }
      }
    };
    
    const data = 'userid=' + window.currentGradingData.userId + 
                 '&itemid=' + window.currentGradingData.itemId + 
                 '&grade=';
    xhr.send(data);
  }
}

// SCORM Modal Functions
function showScormDetails(userId, itemId, studentName, activityName) {
  const key = userId + ':' + itemId;
  let data = scormTrackingData[key];

  // Fallback lookup if primary key fails
  if (!data) {
    const scormId = (typeof gradeitemToScorm !== 'undefined' && gradeitemToScorm[itemId]) ? gradeitemToScorm[itemId] : null;
    if (scormId) {
      const altKey = userId + ':' + scormId;
      data = (typeof scormByUserScorm !== 'undefined') ? scormByUserScorm[altKey] : null;
    }
  }
  if (!data) data = {}; // default fallback

  // Update modal content
  document.getElementById('scormStudentName').textContent = studentName;
  document.getElementById('scormActivityName').textContent = activityName;
  
  // Status - use lesson_status
  const statusEl = document.getElementById('scormStatus');
  const status = data.status || 'not_attempted';
  const hasAttempted = data.has_attempted || false;
  
  // If student has attempted but status is not_attempted, show as attempted
  let displayStatus = status;
  if (status === 'not_attempted' && hasAttempted) {
    displayStatus = 'attempted';
  }
  
  statusEl.textContent = displayStatus.replace('_', ' ');
  statusEl.className = 'status-badge ' + displayStatus;
  
  // Completion - use completion_status, fallback to lesson_status
  const completionEl = document.getElementById('scormCompletion');
  let completion = data.completion || 'not_attempted';
  
  // If completion is not_attempted but student has attempted, show as attempted
  if (completion === 'not_attempted' && hasAttempted) {
    completion = 'attempted';
  } else if (completion === 'not_attempted' && status !== 'not_attempted') {
    completion = status;
  }
  
  completionEl.textContent = completion.replace('_', ' ');
  completionEl.className = 'completion-badge ' + completion;
  
  // Score - handle different score formats
  const scoreEl = document.getElementById('scormScore');
  if (data.score && data.score !== '') {
    // If score is already in percentage format or has a slash, use as-is
    if (data.score.toString().includes('/') || data.score.toString().includes('%')) {
      scoreEl.textContent = data.score;
    } else {
      // Assume raw score, display as-is
      scoreEl.textContent = data.score;
    }
  } else {
    scoreEl.textContent = 'No score';
  }
  
  // Time tracking - debug what we're getting
  console.log('SCORM data for time tracking:', data);
  document.getElementById('scormTotalTime').textContent = data.total_time || '00:00:00';
  document.getElementById('scormSessionTime').textContent = data.session_time || '00:00:00';
  
  // Entry/Exit
  document.getElementById('scormEntry').textContent = data.entry || 'ab-initio';
  document.getElementById('scormExit').textContent = data.exit || 'Not exited';
  
  // Last accessed
  const lastAccessed = data.last_accessed ? new Date(data.last_accessed * 1000).toLocaleString() : 'Never';
  document.getElementById('scormLastAccessed').textContent = lastAccessed;
  
  // Show modal
  document.getElementById('scormModal').style.display = 'flex';
}

function closeScormModal() {
  document.getElementById('scormModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
  const scormModal = document.getElementById('scormModal');
  const gradingModal = document.getElementById('gradingModal');
  
  if (event.target === scormModal) {
    closeScormModal();
  }
  if (event.target === gradingModal) {
    closeGradingModal();
  }
}

document.addEventListener("DOMContentLoaded",function(){
  console.log("Gradebook: Initializing search and filters...");
  const searchInput=document.getElementById("gbSearch");
  const filterBtns=document.querySelectorAll(".gb-filter");
  const rows=[...document.querySelectorAll(".grade-table tbody tr")];
  let activeFilter="all";
  
  console.log("Gradebook: Found search input:", searchInput);
  console.log("Gradebook: Found filter buttons:", filterBtns.length);
  console.log("Gradebook: Found table rows:", rows.length);
  
  function apply(){
    const q=(searchInput?searchInput.value.toLowerCase():"")||"";
    console.log("Gradebook: Applying filter - query:", q, "activeFilter:", activeFilter);
    rows.forEach(row=>{
      const name=(row.querySelector(".student-name")?.innerText||"").toLowerCase();
      const email=(row.querySelector(".student-email")?.innerText||"").toLowerCase();
      const hasGraded=row.querySelector(".pill-graded")!==null;
      const hasMissing=row.querySelector(".pill-missing")!==null;
      const hasAttempted=row.querySelector(".pill-attempted")!==null;
      let ok=true;
      if(q && !(name.includes(q)||email.includes(q))) ok=false;
      if(activeFilter==='graded' && !hasGraded) ok=false;
      if(activeFilter==='attempted' && !hasAttempted) ok=false;
      if(activeFilter==='missing' && !hasMissing) ok=false;
      row.style.display= ok? '' : 'none';
    });
  }
  if(searchInput){searchInput.addEventListener("input",apply);} 
  filterBtns.forEach(btn=>btn.addEventListener("click",function(){
    filterBtns.forEach(b=>b.classList.remove("active"));
    this.classList.add("active");
    activeFilter=this.dataset.filter||"all";
    console.log("Gradebook: Filter clicked:", activeFilter);
    apply();
  }));
});
</script>
JS;

echo $OUTPUT->footer();