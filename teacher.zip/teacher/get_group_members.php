<?php
/**
 * Get Group Members API
 * Fetches members of a specific group
 */

require_once(__DIR__ . '/../../../config.php');
require_login();

// Set JSON header
header('Content-Type: application/json');

try {
    // Get group ID
    $groupid = required_param('groupid', PARAM_INT);
    
    // Validate group exists
    $group = $DB->get_record('groups', ['id' => $groupid]);
    if (!$group) {
        throw new Exception('Invalid group ID');
    }
    
    // Check course access
    $context = context_course::instance($group->courseid);
    require_capability('moodle/course:managegroups', $context);
    
    // Get group members
    $sql = "SELECT u.id, u.firstname, u.lastname, u.email, gm.timeadded
            FROM {groups_members} gm
            JOIN {user} u ON u.id = gm.userid
            WHERE gm.groupid = :groupid
              AND u.deleted = 0
            ORDER BY u.lastname, u.firstname";
    
    $members = $DB->get_records_sql($sql, ['groupid' => $groupid]);
    
    // Format member data
    $formatted_members = [];
    foreach ($members as $member) {
        $formatted_members[] = [
            'id' => $member->id,
            'fullname' => fullname($member),
            'firstname' => $member->firstname,
            'lastname' => $member->lastname,
            'email' => $member->email,
            'added' => userdate($member->timeadded, get_string('strftimedatetime'))
        ];
    }
    
    // Return success response
    echo json_encode([
        'success' => true,
        'members' => $formatted_members,
        'count' => count($formatted_members),
        'group_name' => $group->name
    ]);
    
} catch (Exception $e) {
    // Log error
    error_log('get_group_members.php - Error: ' . $e->getMessage());
    
    // Return error response
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'members' => []
    ]);
}
?>


