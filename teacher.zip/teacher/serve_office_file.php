<?php
/**
 * Serve Office File
 * Serves the actual file content with proper headers for Office Online viewer
 * This bypasses authentication issues by serving the file directly from an authenticated endpoint
 */

require_once(__DIR__ . '/../../../config.php');

// Require login
require_login(null, false);

// Get file parameters
$contextid = required_param('contextid', PARAM_INT);
$component = required_param('component', PARAM_TEXT);
$filearea = required_param('filearea', PARAM_TEXT);
$itemid = required_param('itemid', PARAM_INT);
$filepath = required_param('filepath', PARAM_TEXT);
$filename = required_param('filename', PARAM_TEXT);

try {
    // Get context
    $context = context::instance_by_id($contextid);
    
    // Get the course
    $course = null;
    if ($context->contextlevel == CONTEXT_MODULE) {
        $cm = $DB->get_record('course_modules', ['id' => $context->instanceid], '*', MUST_EXIST);
        $course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);
    } else if ($context->contextlevel == CONTEXT_COURSE) {
        $course = $DB->get_record('course', ['id' => $context->instanceid], '*', MUST_EXIST);
    }
    
    if (!$course) {
        die('Course not found');
    }
    
    // Require login to course
    require_login($course, false);
    
    $coursecontext = context_course::instance($course->id);
    
    // Check access
    $canaccess = is_siteadmin() ||
                 has_capability('moodle/course:update', $coursecontext) || 
                 has_capability('moodle/course:view', $coursecontext) ||
                 is_enrolled($coursecontext, $USER->id, '', true);
    
    if (!$canaccess) {
        die('Access denied');
    }
    
    // Get the file
    $fs = get_file_storage();
    $file = $fs->get_file($contextid, $component, $filearea, $itemid, $filepath, $filename);
    
    if (!$file) {
        die('File not found');
    }
    
    // Log file serving
    error_log("serve_office_file.php: Serving file: $filename (size: " . $file->get_filesize() . " bytes)");
    
    // Send file with proper headers for Office Online to access
    // Use send_file() which handles all the headers correctly
    send_file($file, $filename, 0, 0, true, false, $file->get_mimetype(), false);
    
} catch (Exception $e) {
    error_log("serve_office_file.php error: " . $e->getMessage());
    die('Error serving file: ' . $e->getMessage());
}

