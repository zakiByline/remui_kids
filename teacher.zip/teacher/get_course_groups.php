<?php
/**
 * Get Course Groups API
 * 
 * Returns all groups in a specific course with member counts
 */

define('AJAX_SCRIPT', true);

require_once(__DIR__ . '/../../../config.php');

header('Content-Type: application/json');

try {
    // Security checks
    require_login();
    
    // Get course ID
    $courseid = required_param('courseid', PARAM_INT);
    
    // Validate course access
    $course = get_course($courseid);
    $coursecontext = context_course::instance($course->id);
    require_capability('moodle/course:update', $coursecontext);
    
    // Fetch groups in this course
    $sql = "
        SELECT 
            g.id,
            g.name,
            g.description,
            g.descriptionformat,
            g.timecreated,
            g.timemodified,
            COUNT(gm.userid) as membercount
        FROM {groups} g
        LEFT JOIN {groups_members} gm ON gm.groupid = g.id
        WHERE g.courseid = ?
        GROUP BY g.id, g.name, g.description, g.descriptionformat, g.timecreated, g.timemodified
        ORDER BY g.name ASC
    ";
    
    $groups = $DB->get_records_sql($sql, [$courseid]);
    
    $result = [];
    foreach ($groups as $group) {
        $result[] = [
            'id' => $group->id,
            'name' => $group->name,
            'description' => $group->description,
            'descriptionformat' => $group->descriptionformat,
            'membercount' => $group->membercount
        ];
    }
    
    echo json_encode([
        'success' => true,
        'groups' => $result,
        'count' => count($result)
    ]);
    
} catch (Exception $e) {
    error_log("Get course groups error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error loading groups: ' . $e->getMessage(),
        'groups' => []
    ]);
}
?>


