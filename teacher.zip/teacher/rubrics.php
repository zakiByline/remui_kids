<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Teacher Rubrics page - custom UI for managing assessment rubrics
 *
 * @package   theme_remui_kids
 * @copyright 2025 Kodeit
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../../config.php');
require_once($CFG->dirroot . '/theme/remui_kids/lib.php');

require_login();
$context = context_system::instance();

// Restrict to teachers/admins.
if (!has_capability('moodle/course:update', $context) && !has_capability('moodle/site:config', $context)) {
    throw new moodle_exception('nopermissions', 'error', '', 'access teacher rubrics page');
}

// Page setup.
$PAGE->set_context($context);
$PAGE->set_url('/theme/remui_kids/teacher/rubrics.php');
$PAGE->set_pagelayout('admin');
$PAGE->set_title('Rubrics');
$PAGE->add_body_class('rubrics-page');

// Breadcrumb.
$PAGE->navbar->add('Rubrics');

// Teacher courses.
$teachercourses = enrol_get_my_courses('id, fullname, shortname', 'visible DESC, sortorder ASC');

// Get course filter parameter
$currentcourseid = optional_param('courseid', 0, PARAM_INT);

// Get rubrics data
$rubrics = theme_remui_kids_get_teacher_rubrics($USER->id, $currentcourseid);

// Debugging output to browser console
echo '<script>console.log("Teacher Rubrics Debug: selectedCourseId=' . (int)$currentcourseid . '");</script>';
if (!empty($teachercourses)) {
    foreach ($teachercourses as $cdbg) {
        echo '<script>console.log("Course ID: ' . (int)$cdbg->id . ' - ' . addslashes($cdbg->shortname) . ' - ' . addslashes($cdbg->fullname) . '");</script>';
    }
}
echo '<script>console.log("Rubrics count: ' . count($rubrics) . '");</script>';

// Output start.
echo $OUTPUT->header();

// Add CSS to remove the default main container
echo '<style>
/* Neutralize the default main container */
#region-main,
[role="main"] {
    background: transparent !important;
    box-shadow: none !important;
    border: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
}
</style>';

echo '<div class="teacher-css-wrapper">';
// Layout wrapper and sidebar (same as students page).
echo '<div class="teacher-dashboard-wrapper">';
echo '<button class="sidebar-toggle" onclick="toggleTeacherSidebar()">';
echo '    <i class="fa fa-bars"></i>';
echo '</button>';

echo '<div class="teacher-sidebar">';
echo '  <div class="sidebar-content">';
// Dashboard section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">DASHBOARD</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/my/" class="sidebar-link"><i class="fa fa-th-large sidebar-icon"></i><span class="sidebar-text">Teacher Dashboard</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/teacher_courses.php" class="sidebar-link"><i class="fa fa-book sidebar-icon"></i><span class="sidebar-text">My Courses</span></a></li>';
echo '      </ul>';
echo '    </div>';
// Students section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">STUDENTS</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/students.php" class="sidebar-link"><i class="fa fa-users sidebar-icon"></i><span class="sidebar-text">All Students</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/enroll_students.php" class="sidebar-link"><i class="fa fa-user-plus sidebar-icon"></i><span class="sidebar-text">Enroll Students</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Reports</span></a></li>';
echo '      </ul>';
echo '    </div>';
// Assessments section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">ASSESSMENTS</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/assignments.php" class="sidebar-link"><i class="fa fa-tasks sidebar-icon"></i><span class="sidebar-text">Assignments</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/quizzes.php" class="sidebar-link"><i class="fa fa-question-circle sidebar-icon"></i><span class="sidebar-text">Quizzes</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/competencies.php" class="sidebar-link"><i class="fa fa-sitemap sidebar-icon"></i><span class="sidebar-text">Competencies</span></a></li>';
echo '        <li class="sidebar-item active"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/rubrics.php" class="sidebar-link"><i class="fa fa-list-alt sidebar-icon"></i><span class="sidebar-text">Rubrics</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/teacher/gradebook.php" class="sidebar-link"><i class="fa fa-star sidebar-icon"></i><span class="sidebar-text">Gradebook</span></a></li>';
echo '      </ul>';
echo '    </div>';
// Questions section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">QUESTIONS</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/theme/remui_kids/pages/questions_unified.php" class="sidebar-link"><i class="fa fa-question-circle sidebar-icon"></i><span class="sidebar-text">Questions Management</span></a></li>';
echo '      </ul>';
echo '    </div>';
// Reports section
echo '    <div class="sidebar-section">';
echo '      <h3 class="sidebar-category">REPORTS</h3>';
echo '      <ul class="sidebar-menu">';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/log/index.php" class="sidebar-link"><i class="fa fa-chart-bar sidebar-icon"></i><span class="sidebar-text">Activity Logs</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/outline/index.php" class="sidebar-link"><i class="fa fa-file-alt sidebar-icon"></i><span class="sidebar-text">Course Reports</span></a></li>';
echo '        <li class="sidebar-item"><a href="' . $CFG->wwwroot . '/report/progress/index.php" class="sidebar-link"><i class="fa fa-chart-line sidebar-icon"></i><span class="sidebar-text">Progress Tracking</span></a></li>';
echo '      </ul>';
echo '    </div>';

echo '  </div>';
echo '</div>'; // end teacher-sidebar

echo '<div class="teacher-main-content">';
echo '<div class="students-page-wrapper">';

// Header
echo '<div class="students-page-header">';
echo '<h1 class="students-page-title">Rubrics</h1>';
echo '<p class="students-page-subtitle">Create and manage assessment rubrics for your courses</p>';
echo '</div>';

// Course selector
echo '<div class="course-selector">';
echo '<div class="course-dropdown-wrapper">';
echo '<label for="rubricCourseSelect" class="course-dropdown-label">Select Course</label>';
echo '<select id="rubricCourseSelect" class="course-dropdown" onchange="window.location.href=this.value">';
echo '<option value="' . (new moodle_url('/theme/remui_kids/teacher/rubrics.php'))->out() . '">All Courses</option>';

foreach ($teachercourses as $course) {
    $selected = ($currentcourseid == $course->id) ? 'selected' : '';
    $url = new moodle_url('/theme/remui_kids/teacher/rubrics.php', array('courseid' => $course->id));
    echo '<option value="' . $url->out() . '" ' . $selected . '>' . $course->shortname . ' - ' . $course->fullname . '</option>';
}
echo '</select>';
echo '</div>';
echo '</div>';

// Statistics cards
$total_rubrics = count($rubrics);
$total_criteria = 0;
$total_submissions = 0;
$graded_submissions = 0;

foreach ($rubrics as $rubric) {
    $total_criteria += is_array($rubric['criteria']) ? count($rubric['criteria']) : 0;
    $total_submissions += $rubric['total_submissions'];
    $graded_submissions += $rubric['graded_submissions'];
}

$grading_progress = ($total_submissions > 0) ? round(min(100, ($graded_submissions / $total_submissions) * 100), 1) : 0;

echo '<div class="stats-grid">';

// Card 1: Total Rubrics
echo '<div class="stat-card">';
echo '<div class="stat-icon"><i class="fa fa-list-alt"></i></div>';
echo '<div class="stat-content">';
echo '<div class="stat-value">' . $total_rubrics . '</div>';
echo '<div class="stat-label">Total Rubrics</div>';
echo '</div>';
echo '</div>';

// Card 2: Total Criteria
echo '<div class="stat-card">';
echo '<div class="stat-icon"><i class="fa fa-tasks"></i></div>';
echo '<div class="stat-content">';
echo '<div class="stat-value">' . $total_criteria . '</div>';
echo '<div class="stat-label">Total Criteria</div>';
echo '</div>';
echo '</div>';

// Card 3: Total Submissions
echo '<div class="stat-card">';
echo '<div class="stat-icon"><i class="fa fa-file-text"></i></div>';
echo '<div class="stat-content">';
echo '<div class="stat-value">' . $total_submissions . '</div>';
echo '<div class="stat-label">Total Submissions</div>';
echo '</div>';
echo '</div>';

// Card 4: Grading Progress
echo '<div class="stat-card">';
echo '<div class="stat-icon"><i class="fa fa-check-circle"></i></div>';
echo '<div class="stat-content">';
echo '<div class="stat-value">' . $grading_progress . '%</div>';
echo '<div class="stat-label">Grading Progress</div>';
echo '</div>';
echo '</div>';

echo '</div>'; // stats-grid

// Rubrics list
echo '<div class="students-container">';

if (empty($rubrics)) {
    echo '<div class="empty-state">';
    echo '<div class="empty-state-icon"><i class="fa fa-list-alt"></i></div>';
    echo '<h3 class="empty-state-title">No Rubrics Found</h3>';
    echo '<p class="empty-state-text">You don\'t have any assignments with rubrics yet. Create assignments and set their grading method to "Rubric" to see them here.</p>';
    echo '</div>';
} else {
    echo '<div class="students-table-wrapper">';
    echo '<table class="students-table">';
    echo '<thead><tr><th>Assignment</th><th>Course</th><th>Rubric Name</th><th>Criteria</th><th>Submissions</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    
    foreach ($rubrics as $rubric) {
        $criteria_count = count($rubric['criteria']);
        $submission_text = $rubric['graded_submissions'] . ' / ' . $rubric['total_submissions'];
        
        echo '<tr>';
        echo '<td class="student-name"><div class="student-avatar">AS</div>' . format_string($rubric['assignment_name']) . '</td>';
        echo '<td class="student-email">' . format_string($rubric['course_name']) . '</td>';
        echo '<td>' . format_string($rubric['rubric_name']) . '</td>';
        echo '<td>' . $criteria_count . ' criteria</td>';
        echo '<td>' . $submission_text . '</td>';
        echo '<td>';
        echo '<button class="filter-btn" type="button" onclick="toggleRubric(\'' . $rubric['cmid'] . '\')">View</button> ';
        $grading_url = new moodle_url('/theme/remui_kids/teacher/rubric_grading.php', [
            'assignmentid' => $rubric['assignment_id'],
            'courseid' => $rubric['course_id']
        ]);
        echo '<a class="filter-btn" href="' . $grading_url->out() . '">Grade</a> ';
        echo '<a class="filter-btn" href="' . $rubric['assignment_url'] . '" target="_blank">Open Assignment</a>';
        echo '</td>';
        echo '</tr>';

        // Expandable rubric row
        echo '<tr id="rubric-details-' . $rubric['cmid'] . '" class="rubric-details-row" style="display:none;">';
        echo '<td colspan="6">';
        echo '<div class="rubric-detail-card">';
        echo '<div class="rubric-header-line"><span class="pill">' . format_string($rubric['rubric_name']) . '</span></div>';

        // Build rubric table from criteria
        $maxlevels = 0; foreach ($rubric['criteria'] as $c) { $maxlevels = max($maxlevels, count($c['levels'])); }
        echo '<div class="rubric-table-wrapper"><table class="rubric-table">';
        echo '<thead><tr><th style="width:28%">Criterion</th>';
        for ($i = 0; $i < $maxlevels; $i++) { echo '<th>Level ' . ($i+1) . '</th>'; }
        echo '</tr></thead><tbody>';
        foreach ($rubric['criteria'] as $criterion) {
            echo '<tr>';
            echo '<td>' . format_text($criterion['description'] ?? '', FORMAT_HTML) . '</td>';
            $levels = $criterion['levels'];
            for ($i = 0; $i < $maxlevels; $i++) {
                if (isset($levels[$i])) {
                    $lvl = $levels[$i];
                    $cell = '<div class="rubric-level-score"><strong>' . format_float($lvl->score ?? 0, 2) . '</strong></div>';
                    $cell .= '<div class="rubric-level-desc">' . format_text($lvl->definition ?? '', FORMAT_HTML) . '</div>';
                } else { $cell = '<span class="muted">—</span>'; }
                echo '<td>' . $cell . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table></div>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';
    }
    
    echo '</tbody></table></div>';
}

echo '</div>'; // students-container

echo '</div>'; // students-page-wrapper
echo '</div>'; // teacher-main-content
echo '</div>'; // teacher-dashboard-wrapper
echo '</div>'; // teacher-css-wrapper

// Sidebar JS
echo '<script>
function toggleTeacherSidebar() {
  const sidebar = document.querySelector(".teacher-sidebar");
  sidebar.classList.toggle("sidebar-open");
}
document.addEventListener("click", function(event) {
  const sidebar = document.querySelector(".teacher-sidebar");
  const toggleButton = document.querySelector(".sidebar-toggle");
  if (!sidebar || !toggleButton) return;
  if (window.innerWidth <= 768 && !sidebar.contains(event.target) && !toggleButton.contains(event.target)) {
    sidebar.classList.remove("sidebar-open");
  }
});
window.addEventListener("resize", function() {
  const sidebar = document.querySelector(".teacher-sidebar");
  if (!sidebar) return;
  if (window.innerWidth > 768) {
    sidebar.classList.remove("sidebar-open");
  }
});
</script>';

// Styles + JS for dropdown rubric
echo '<style>
.rubric-detail-card{background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:16px}
.pill{display:inline-block;padding:4px 10px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:12px}
.rubric-table{width:100%;border-collapse:separate;border-spacing:0}
.rubric-table thead th{background:#f7f9fc;border-bottom:1px solid #e5e7eb;padding:10px;text-align:left}
.rubric-table td{border-bottom:1px solid #f0f2f5;padding:10px;vertical-align:top}
.muted{color:#9ca3af}
</style>';

echo '<script>
function toggleRubric(cmid){
  var row = document.getElementById("rubric-details-"+cmid);
  if(!row) return;
  row.style.display = (row.style.display === "none" || row.style.display === "") ? "table-row" : "none";
}
</script>';

echo $OUTPUT->footer();

